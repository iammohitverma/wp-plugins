(function() {
    tinymce.PluginManager.add('lf_tiny_mce', function( editor, url ) {
        editor.addButton( 'lf_tiny_mce', {
                 text: 'LaunchFlows',
                 icon: false,
                 type: 'listbox',

                      menu:[

/*
                                       {
                                        text: '[lf-account]',
                                        onclick: function() {
                                           editor.insertContent('[lf-account]');
                                                 }
                                       },
  */
                                       {
                                        text: '[lf-additional]',
                                        onclick: function() {
                                           editor.insertContent('[lf-additional]');
                                                 }
                                       },
                                       {
                                        text: '[lf-add-to-cart]',
                                        onclick: function() {
                                           editor.insertContent('[lf-add-to-cart]');
                                                 }
                                       },
                                       {
                                        text: '[lf-always-in]',
                                        onclick: function() {
                                           editor.insertContent('[lf-always-in product=]');
                                                 }
                                       },
                                      {
                                        text: '[lf-apply-tags]',
                                        onclick: function() {
                                           editor.insertContent('[lf-apply-tags tags=]');
                                                 }
                                       },  
                                       {
                                        text: '[lf-autoclick]',
                                        onclick: function() {
                                           editor.insertContent('[lf-autoclick]');
                                                 }
                                       },
                                       {
                                        text: '[lf-billing]',
                                        onclick: function() {
                                           editor.insertContent('[lf-billing]');
                                                  }
                                        },
                                       {
                                        text: '[lf-bump]',
                                        onclick: function() {
                                           editor.insertContent('[lf-bump product=]');
                                                  }
                                        },
                                       {
                                        text: '[lf-cart-discount]',
                                        onclick: function() {
                                           editor.insertContent('[lf-cart-discount]');
                                                  }
                                        },
                                       {
                                        text: '[lf-checkout-button]',
                                        onclick: function() {
                                           editor.insertContent('[lf-checkout-button]');
                                                 }
                                       },                                     
                                       {
                                        text: '[lf-donate]',
                                        onclick: function() {
                                           editor.insertContent('[lf-donate]');
                                                 }
                                       },
                                       {
                                        text: '[lf-donation]',
                                        onclick: function() {
                                           editor.insertContent('[lf-donation]');
                                                 }
                                       },                                                                                  
                                       {
                                        text: '[lf-emptycart]',
                                        onclick: function() {
                                           editor.insertContent('[lf-emptycart]');
                                                  }
                                       },                                       
                                       {
                                        text: '[lf-get-tags]',
                                        onclick: function() {
                                           editor.insertContent('[lf-get-tags tags=]');
                                                  }   
                                       },       
                                       {
                                        text: '[lf-hide-related]',
                                        onclick: function() {
                                           editor.insertContent('[lf-hide-related]');
                                                  }
                                        },    
                                       {
                                        text: '[lf-hide-wc-tabs]',
                                        onclick: function() {
                                           editor.insertContent('[lf-last-order]');
                                                  }
                                        },    
                                       {
                                        text: '[lf-last-order]',
                                        onclick: function() {
                                           editor.insertContent('[lf-last-order]');
                                                  }
                                        },                                       
                                       {
                                        text: '[lf-login]',
                                        onclick: function() {
                                           editor.insertContent('[lf-login]');
                                                  }
                                        },    
                                       {
                                        text: '[lf-loyalty]',
                                        onclick: function() {
                                           editor.insertContent('[lf-loyalty]');
                                                  }
                                        },    
                                       {
                                        text: '[lf-notices]',
                                        onclick: function() {
                                           editor.insertContent('[lf-notices]');
                                                 }
                                       },
                                       {
                                        text: '[lf-payment]',
                                        onclick: function() {
                                           editor.insertContent('[lf-payment]');
                                                 }
                                       },
                                       {
                                        text: '[lf-payment-methods]',
                                        onclick: function() {
                                           editor.insertContent('[lf-payment-methods]');
                                                  }
                                        },    
                                       {
                                        text: '[lf-product-link]',
                                        onclick: function() {
                                           editor.insertContent('[lf-product-link]');
                                                  }
                                        },    
                                       {
                                        text: '[lf-review]',
                                        onclick: function() {
                                           editor.insertContent('[lf-review]');
                                                 }
                                       },                                          
                                      {
                                        text: '[lf-remove-tags]',
                                        onclick: function() {
                                           editor.insertContent('[lf-remove-tags tags=]');
                                                 }
                                       },       
                                       {
                                        text: '[lf-return-checkout]',
                                        onclick: function() {
                                           editor.insertContent('[lf-return-checkout]');
                                                 }
                                       },  
                                       {
                                        text: '[lf-review]',
                                        onclick: function() {
                                           editor.insertContent('[lf-review]');
                                                 }
                                       },                                                                             
                                       {
                                        text: '[lf-save-stripe-cc]',
                                        onclick: function() {
                                           editor.insertContent('[lf-save-stripe-cc]');
                                                  }
                                       }, 
                                       {
                                        text: '[lf-save-square-cc]',
                                        onclick: function() {
                                           editor.insertContent('[lf-save-square-cc]');
                                                  }
                                       },  
                                       {
                                        text: '[lf-shipping]',
                                        onclick: function() {
                                           editor.insertContent('[lf-shipping]');
                                                 }
                                       },
                                       {
                                        text: '[lf-subtotal]',
                                        onclick: function() {
                                           editor.insertContent('[lf-subtotal]');
                                                 }
                                       },
                                       {
                                        text: '[lf-tax-total]',
                                        onclick: function() {
                                           editor.insertContent('[lf-tax-total]');
                                                 }
                                       },  
                                       {
                                        text: '[lf-thank-you]',
                                        onclick: function() {
                                           editor.insertContent('[lf-thank-you]');
                                                 }
                                       },       
                                       {
                                        text: '[lf-total]',
                                        onclick: function() {
                                           editor.insertContent('[lf-total]');
                                                 }
                                       },                                                                                                                      
                                       {
                                        text: '[lf-total-shipping]',
                                        onclick: function() {
                                           editor.insertContent('[lf-total-shipping]');
                                                 }
                                       },
                                       {
                                        text: '[lf-user-avatar]',
                                        onclick: function() {
                                           editor.insertContent('[lf-user-avatar]');
                                                 }
                                       },
                                       {
                                        text: '[lf-wccoupon]',
                                        onclick: function() {
                                           editor.insertContent('[lf-wccoupon]');
                                                 }
                                       },                                                                              
                                       {
                                        text: '[lf-upsell]',
                                        onclick: function() {
                                           editor.insertContent('[lf-upsell]');
                                                 }
                                       },  

                                       // product page shortcodes

                                       {
                                        text: '[lf-wcbreadcrumb]',
                                        onclick: function() {
                                           editor.insertContent('[lf-wcbreadcrumb]');
                                                 }
                                       }, 
                                       {
                                        text: '[lf-wccart]',
                                        onclick: function() {
                                           editor.insertContent('[lf-wccart]');
                                                 }
                                       }, 
                                       {
                                        text: '[lf-wcdescription]',
                                        onclick: function() {
                                           editor.insertContent('[lf-wcdescription]');
                                                 }
                                       },                                         
                                       {
                                        text: '[lf-wcfirstpayment]',
                                        onclick: function() {
                                           editor.insertContent('[lf-wcfirstpayment]');
                                                 }
                                       }, 
                                       {
                                        text: '[lf-wcgallery]',
                                        onclick: function() {
                                           editor.insertContent('[lf-wcgallery]');
                                                 }
                                       }, 
                                       {
                                        text: '[lf-wcmeta]',
                                        onclick: function() {
                                           editor.insertContent('[lf-wcmeta]');
                                                 }
                                       }, 
                                       {
                                        text: '[lf-wcprice]',
                                        onclick: function() {
                                           editor.insertContent('[lf-wcprice]');
                                                 }
                                       }, 
                                       {
                                        text: '[lf-wcrelated]',
                                        onclick: function() {
                                           editor.insertContent('[lf-wcrelated]');
                                                 }
                                       }, 
                                       {
                                        text: '[lf-wctabs]',
                                        onclick: function() {
                                           editor.insertContent('[lf-wctabs]');
                                                 }
                                       }, 
                                       {
                                        text: '[lf-wctitle]',
                                        onclick: function() {
                                           editor.insertContent('[lf-wctitle]');
                                                 }
                                       }, 
                       ]
              });
        });
})(jQuery); // need to keep elipses in place!