<?php

namespace LaunchFlowsElementor;

if (!defined('ABSPATH')) {
    exit;
}

class LF_Blocks
{
    public function __construct()
    {
        add_action('init', array($this, 'lf_block_register'));
        add_filter('block_categories_all', array($this, 'lf_block_categories'));
    }

    function lf_block_categories($categories)
    {
        $category_slugs = wp_list_pluck($categories, 'slug');
        return in_array('lf', $category_slugs, true) ? $categories : array_merge(
            $categories,
            array(
                array(
                    'slug'  => 'lf',
                    'title' => __('LaunchFlows', 'lf'),
                    'icon'  => null,
                ),
            )
        );
    }
    public function lf_block_register()
    {

        // Register our block script with WordPress
        wp_register_script(
            'lf-blocks',
            plugins_url('js/main.js', __FILE__),
            array('wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor')
        );



        // Enqueue the script in the editor
        register_block_type(
            'lf-block/blocks',
            array(
                'editor_script' => 'lf-blocks',
            )
        );
    }
}

new LF_Blocks();
