<?php

class LFSoloCheckout {

	/**
	 * Method to kickstart the code.
	 *
	 * @return void
	 */
	public static function start(){
		new LFSoloCheckout;
	}

	/**
	 * Adds all necessary action hooks
	 */
	private function __construct(){
		// The field
		add_action('woocommerce_process_product_meta', array($this, 'saveProductGeneralTabField'));

	}

	/**
	 * Saves the checkbox selection state ("yes" by default)
	 */
	public function saveProductGeneralTabField($id){
			update_post_meta($id, 'solocheckout_input', $_POST['solocheckout_input'] );
	}

}

/**
 * Finally, start the class
 */

LFSoloCheckout::start();