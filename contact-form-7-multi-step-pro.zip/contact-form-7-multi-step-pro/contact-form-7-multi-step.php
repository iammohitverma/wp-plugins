<?php
/**
Plugin Name: Contact Form 7 Multi Step Pro
Plugin URI: http://ninjateam.org
Description: Break your long form into user-friendly steps.
Version: 2.6.8
Author: NinjaTeam
Author URI: http://ninjateam.org
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// if (!defined('WPCF7_AUTOP')) {
// define('WPCF7_AUTOP', false);
// }
define( 'CF7MLS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CF7MLS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'CF7MLS_NTA_VERSION', '2.6.8' );

// load text domain
require_once CF7MLS_PLUGIN_DIR . '/inc/I18n.php';
// CF7DB
require_once CF7MLS_PLUGIN_DIR . '/inc/cf7db.php';
// backend
require_once CF7MLS_PLUGIN_DIR . '/inc/admin/init.php';
require_once CF7MLS_PLUGIN_DIR . '/inc/admin/settings.php';
require_once CF7MLS_PLUGIN_DIR . '/inc/admin/review.php';
// frontend
require_once CF7MLS_PLUGIN_DIR . '/inc/frontend/init.php';
require_once CF7MLS_PLUGIN_DIR . '/inc/frontend/validation.php';

