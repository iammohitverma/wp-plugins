<?php

class LFInstantLeadmagnet {

	/**
	 * Method to kickstart the code.
	 *
	 * @return void
	 */
	public static function start(){
		new LFInstantLeadmagnet;
	}

	/**
	 * Adds all necessary action hooks
	 */
	private function __construct(){
		add_action('woocommerce_process_product_meta', array($this, 'saveProductGeneralTabField')); 
	}

	/**
	 * Saves the checkbox selection state ("yes" by default)
	 */
	public function saveProductGeneralTabField($id){
			update_post_meta($id, 'leadmagnet_input', $_POST['leadmagnet_input'] );
	}

}

/**
 * Finally, start the class
 */

LFInstantLeadmagnet::start();