<?php
class LFCustomThankYouPage {

	/**
	 * Method to kickstart the code.
	 *
	 * @since 1.1.9
	 * @return void
	 */
	
	public static function start(){
		new LFCustomThankYouPage;
	}

	/**
	 * Adds all necessary action hooks
	 */

	private function __construct(){
		add_action('woocommerce_process_product_meta', array($this, 'saveProductGeneralTabField'));

		// Custom thank you page handling after checkout
		add_action('woocommerce_thankyou', array($this, 'redirect_thank_you_page'));

		// adds meta_box to wc general settings 
		add_filter( 'woocommerce_general_settings', array( $this, 'custom_thank_you_page' ) );

		// auto hinting functions
		add_action( 'admin_enqueue_scripts', array( $this, 'include_javascript' ) );
		add_action( 'wp_ajax_wc-thank-you-hint', array( $this, 'hint_thank_you_pages' ) );
	}


	/**
	 * Custom "thank you" page option (fallback if two products in checkout with different thank you pages)
	 * Setting can be found under "WooCommerce > Settings > Checkout".
	 *
	 * @param array $settings Stored settings.
	 */
	
	public function custom_thank_you_page( $settings ) {

		$updated_settings = array();

		foreach ( $settings as $section ) {

			// At the bottom of the General Options section.
			if ( isset( $section['id'] ) && 'general_options' === $section['id'] &&
			isset( $section['type'] ) && 'sectionend' === $section['type'] ) {

				$updated_settings[] = array(
					'title'    => __( 'LF - Thank You Page', 'woocommerce' ),
					'desc'     => __( 'Add a default, fallback thank you page to redirect to after the checkout process is complete.', 'woocommerce' ),
					'id'       => 'lf_woocommerce_custom_thankyou_page_id',
					'type'     => 'single_select_page',
					'default'  => '',
					'class'    => 'wc-enhanced-select-nostd',
					'css'      => 'min-width:300px;',
					'desc_tip' => true,
				);
			}

			$updated_settings[] = $section;
		}

		// Return the settings array.
		return $updated_settings;
	}


	/**
	 * Includes the thank you hinting JS file on single edit pages.
	 *
	 * @access public
	 * @param  string $hook Page hook.
	 */

	public function include_javascript( $hook ) {

		// bail if not on admin or our function doesnt exist.
		if ( ! is_admin() || ! function_exists( 'get_current_screen' ) ) {
			return;
		}

		// get my current screen.
		$screen = get_current_screen();

		// bail without.
		if ( empty( $screen ) || ! is_object( $screen ) ) {
			return;
		}

		// make sure we are on the wc single product editor
		if ( 'post' !== $screen->base || 'product' !== $screen->post_type ) {
			return;
		}

		// load the js file
		wp_enqueue_script( 'lf_wc_thank_you_redirect-hinting', LF_DIR_URL . "assets/js/thankyou-hint.js", array( 'jquery', 'jquery-ui-autocomplete' ), '1.0.5', true );
	}


	/**
	 * Prints out the page hints in JSON format.
	 */

	public function hint_thank_you_pages() {

		// Set our search param.
		$search = isset( $_REQUEST['search'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['search'] ) ) : '';

		// Set our query args.
		$query = new \WP_Query(
			array(
//				'post_type'      => array('page', 'post', 'sfwd-courses', 'sfwd-lessons', 'course', 'lesson'),
				'post_type'      => 'any', // any post type
				'posts_per_page' => 15,
				's'              => $search,
			)
		);

		// bail if we have no posts
		if ( is_wp_error( $query ) || empty( $query->posts ) ) {
			return false;
		}

		// set an empty for the result array.
		$result = array();

		// loop the results
		foreach ( $query->posts as $post ) {
			$result[] = array(
				'label' => $post->post_title,
				'value' => $post->ID,
			);
		}

		// return the results, JSON encoded
		echo wp_json_encode(
			array(
				'success' => true,
				'data'    => $result,
			)
		);

		// And die.
		die();
	}


	/**
	 * Saves the contents from the thank you page field
	 *
	 * @since 1.1.9
	 * @param int $id Post ID.
	 */

	public function saveProductGeneralTabField($post_id) {

		// Throw an error if the data wasn't saved.
		if ( ! isset( $_REQUEST['_lf_thankyoupage_field_id'] ) || ! isset( $_REQUEST['_lf_thankyoupage_field'] ) ) {
			new \WP_Error( 'Necessary field values are not present' );
			return;
		}

		// Set our page and label.
		$thank_you_page       = sanitize_text_field( wp_unslash( $_REQUEST['_lf_thankyoupage_field_id'] ) );
		$thank_you_page_label = trim( sanitize_text_field( wp_unslash( $_REQUEST['_lf_thankyoupage_field'] ) ) );

		if ( 0 === strpos( $thank_you_page_label, 'http' ) ) {
			update_post_meta( $post_id, '_lf_thankyoupage_field', $thank_you_page_label );
		} elseif ( ! empty( $thank_you_page ) ) {
			update_post_meta( $post_id, '_lf_thankyoupage_field', $thank_you_page );
		} else {
			update_post_meta( $post_id, '_lf_thankyoupage_field', '' );
		}
	}


/**
	 * Redirects to the selected thank you page, if one has been set.
	 *
	 * @param int $order_id Order ID.
	 */

	public function redirect_thank_you_page( $order_id ) {

		// get the wc order and items inside
		$order = wc_get_order( $order_id );
		$items = $order->get_items();

		// bail if no items (not likely)
		if ( empty( $items ) || 0 === count( $items ) ) {
			return;
		}

		// get our fallback global option
		$fallback = get_option( 'lf_woocommerce_custom_thankyou_page_id', false ); // fallback field id from above




		// check if any order item has "force thank you option"
		foreach( $order->get_items() as $item_id => $item ){

		    $product_id   = $item->get_product_id(); //Get the product ID

		    // for variable products get the parent id from product_id
		    $parent_id  = wp_get_post_parent_id( $product_id );
		         
		    // if there is no parent id, then product id is used instead
		    $product_id = $parent_id > 0 ? $parent_id : $product_id;

		    if ( get_post_meta( $product_id, 'forcethankyou_input', true) === 'yes') {

					// get the array keys to begin checking
					$keys = array_keys( $items );

					// check for the meta key for the thank you page field
					$meta = get_post_meta( $items[ $keys[0] ]['product_id'], '_lf_thankyoupage_field', true );

					// if no meta, and no fallback field was set, bail to default wc behavior
					if ( empty( $meta ) && empty( $fallback ) ) {
						return;
					}

					// otherwise, get the meta permalink or do the same for the fallback field
					$page = ! empty( $meta ) ? get_permalink( (int) $meta ) : get_permalink( (int) $fallback );

					// And redirect.
					wp_safe_redirect( $page ); // only page url

					exit;
			}
		}


		// if more than 1 item in the order
		if ( ! empty( $fallback ) && count( $items ) > 1 ) {

			// set page to redirect
			$page = get_permalink( (int) $fallback );

			// And redirect.
			wp_safe_redirect( $page ); // only page url
						
			exit;
		}

		// if only have 1 item in the order, check for a custom page
		if ( count( $items ) === 1 ) {

			// get the array keys to begin checking
			$keys = array_keys( $items );

			// check for the meta key for the thank you page field
			$meta = get_post_meta( $items[ $keys[0] ]['product_id'], '_lf_thankyoupage_field', true );

			// if no meta, and no fallback field was set, bail to default wc behavior
			if ( empty( $meta ) && empty( $fallback ) ) {
				return;
			}

			// otherwise, get the meta permalink or do the same for the fallback field
			$page = ! empty( $meta ) ? get_permalink( (int) $meta ) : get_permalink( (int) $fallback );

			// And redirect.
			wp_safe_redirect( $page ); // only page url

			exit;
		}

		// end redirection_thank_you_page
	}


} // end class wrapper

/**
 * Finally, start the class
 */

LFCustomThankYouPage::start();