jQuery(document).ready(function ($) {
    // see: gist.github.com/wplaunchify/58fbcc5a2335f89ab648b71ec9e9bc87
    // get the hash tag
    // hash exist
    setTimeout(function () {
        var current = window.location.href
        var current = current.split('#tab')
        if (current.length > 1) {
            showAndScrollToTab($, current)
        }
    }, 200);
    // change the browser url according to selected tab
    $('.elementor-tab-title[data-tab]').click(function () {
        var current_location = window.location.href;
        current_location = current_location.split('#')
        window.location = current_location[0] + '#tab' + $(this).attr('data-tab')
    })
    // activate tab also from anchor link in the same page   
    if($('#tab').length) { // check first if there are any #tab elements (1.1.6)
        $('a').on('click', function () {
            var anchorUrl = $(this).attr('href')
            var anchor = anchorUrl.split('#tab')
            if (anchor.length > 1) {
                showAndScrollToTab($, anchor)
            }
        })
    }
})

function showAndScrollToTab($, current) {
    $('.elementor-tab-title').removeClass('elementor-active')
    $('.elementor-tab-title[data-tab="' + current[1] + '"]').addClass('elementor-active')
    $('.elementor-tab-content').hide();
    $('.elementor-tab-content[data-tab="'+current[1]+'"]').show();
    // scroll to
    // var headerHeight = $('#header').height()  // put here your header id to get its height.
    $([document.documentElement, document.body]).animate({
    //    scrollTop: $('.elementor-tab-title[data-tab="' + current[1] + '"]').closest('.elementor-widget-wrap').offset().top - headerHeight
          scrollTop: $('.elementor-tab-title[data-tab="' + current[1] + '"]').closest('.elementor-widget-wrap')
    }, 2000)
}

// Target Triggers - Since 1.2
// stackoverflow.com/questions/51331884/how-to-trigger-the-click-event-of-a-jquery-tab-element
// Creates 5 unique remote triggers for Elementor tabs or accordians. 
// Add unique #id of target tab/accordian any button (clickable element) CSS ID then use "target1-5" as the CSS ID for the button widget under advanced.
jQuery(document).ready(function() {
    function clickTab(tab) {
        let click = new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            synthetic: true,
            view: window
        });
        tab.dispatchEvent(click);
    }

    jQuery( function() {
        jQuery("#lf-target1 a").click(function() {
            let target1 = jQuery("#lf-target1 a").attr("id"); //get id value for button link #lf-targetX button widget
            let tab = document.getElementById(target1);
                clickTab(tab);
        });
        jQuery("#lf-target2 a").click(function() {
            let target2 = jQuery("#lf-target2 a").attr("id");
            let tab = document.getElementById(target2);
                clickTab(tab);
        });   
        jQuery("#lf-target3 a").click(function() {
            let target3 = jQuery("#lf-target3 a").attr("id");
            let tab = document.getElementById(target3);
                clickTab(tab);
        });
        jQuery("#lf-target4 a").click(function() {
            let target4 = jQuery("#lf-target4 a").attr("id");
            let tab = document.getElementById(target4);
                clickTab(tab);
        });
        jQuery("#lf-target5 a").click(function() {
            let target5 = jQuery("#lf-target5 a").attr("id");
            let tab = document.getElementById(target5);
                clickTab(tab);
        });       
    });  
    
})