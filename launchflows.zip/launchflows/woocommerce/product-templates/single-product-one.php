<script src="//cdn.jsdelivr.net/npm/jquery.localscroll@2.0.0/jquery.localScroll.min.js"></script>

<?php // default colors

      $color            =  '#ffffff';

      $button_color     =  'transparent';

      $border_size      =  '2px solid';

      $border_color     =  '#ffffff';

      $border_radius    =  '5px';

     $r = rand(0,255);

?>
        <style>

html{scroll-behavior:smooth}

.lf-container {
    padding: 0 5%;
}

button.lf-scroll-to-checkout {
    margin-top: 10px;
}

          /* hides original product remaining items */
          #lf-original-product {
              display: none!important;
          }

          #lf-product-template-one-<?php echo $r ?> p {color:<?php echo $color; ?>!important}

           #lf-product-template-one-<?php echo $r ?> button {
            background-color:<?php echo $button_color; ?>!important; 
            color: <?php echo $color; ?>!important;
            border: <?php echo $border_size; ?>!important;
            border-color: <?php echo $border_color; ?>!important;
            border-radius: <?php echo $border_radius; ?>!important;
            padding: 8px 32px!important;
            }

          #lf-product-template-one-<?php echo $r ?> button#scroll-to-checkout-button {
              padding: 5px 10px!important;
          }
          h1.product_title.entry-title {
              text-align: center;
              font-family: fantasy;
              color: <?php echo $color; ?>!important;
              font-size: 2.5rem;
              text-transform: uppercase;
              padding-top: 5%!important;
          }

          .woocommerce div.product .product_title {
              margin: 0!important;
          }
          
          #lf-product-template-one-<?php echo $r ?> {
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(<?php the_post_thumbnail_url(); ?>);
            height: 100vh;
            background-size: cover;
          }
          .details {
          	  color:  <?php echo $color; ?>;
              margin: auto 15%;
          }     

          @media only screen and (min-width: 481px) {

            h1.product_title.entry-title {font-size: 6.5rem;}

          }

          @media only screen and (min-width: 768px) {

            h1.product_title.entry-title {font-size: 6.5rem;}

          }

          @media only screen and (min-width: 1025px) {

            h1.product_title.entry-title {font-size: 10rem;}

          }

        </style>

        <div id="lf-product-template-one-<?php echo $r ?>">
        
	        <?php // the product title
	        wc_get_template( 'single-product/title.php' );
	        ?>
        
		        <div class="details">

				<?php // the price
				wc_get_template( 'single-product/price.php' ); 
				?>


				<?php // adds appropriate add to cart for any product type
				    global $product;
				    do_action( 'woocommerce_' . $product->get_type() . '_add_to_cart' );
				   // woocommerce_template_loop_add_to_cart();
				    // wc_get_template( 'loop/add-to-cart.php', $args );
				// end add to cart
				?>
		        
		        <?php // short description
				wc_get_template( 'single-product/short-description.php' );
				
		        ?>
		        
				<?php // only show if instant checkout is available on product page
					if ( get_post_meta( get_the_ID() , '_lf_activate_checkout_checkbox', true) === 'true') {

					echo '<a href="#lf-form"><button class="lf-scroll-to-checkout">Scroll To Checkout</button></a>';

					}
				?>

		        </div>
        </div>

    			<div id="lf-content-block" <?php wc_product_class( '', $product ); ?> style="display:none; width:100%; overflow:hidden;">
    			<?php 

    			// adds content area
    			echo '<div id="lf-the-content">';
     			the_content(); 
				echo '</div><!-- /#lf-the-content -->';

				echo '</div>';			

// End Logic For Product Templates
?>