<?php

class CheckoutActivateClass {

/**
   * Constructor
   *
   * @since 4.1.2
   *
   * @return void
   */

public function __construct() {

// for custom shortcode metabox
    add_action( 'add_meta_boxes', array ($this, 'lf_add_metabox') );              
    add_action( 'save_post', array ($this, 'save') );
    add_action ('wp_head', array ($this, 'checkbox_value') );
  }


/**
   * Adds Custom Checkout Button Text Capability
   *
   * @since 3.5.3
   *
   * @return void
   */

public function lf_add_metabox($post_type) { 
      
      // post types to exclude
      $post_types = array('wccc');

      // limit meta box to certain post types
      if(!in_array($post_type, $post_types)) {
        $label = __( 'LaunchFlows Checkout Enable', 'lf' );
        add_meta_box(
          'lf-meta-activate-checkout', 
          $label, 
          array($this, 'lf_meta_box_function'), // triggers output function
          $post_type,
          'side', 
          'high');

      }
    }

/**
   * Adds Metabox Output
   *
   * @since 1.0.0
   *
   * @return void
   */

// Output For Metabox
public function lf_meta_box_function( $post ) {


    // Add an nonce field so we can check for it later.
    wp_nonce_field('lf_nonce_check', 'lf_nonce_check_value');

    // Use get_post_meta to retrieve an existing value from the database.
    $data =  get_post_meta($post->ID, '_lf_activate_checkout_checkbox' , true ) ;

    
                if($data == "")
                {
                    ?>
                        <input class="lf-checkbox" name="lf_activate_checkout_checkbox" type="checkbox" value="true">
                    <?php
                }
                else if($data == "true")
                {
                    ?>  
                        <input class="lf-checkbox" name="lf_activate_checkout_checkbox" type="checkbox" value="true" checked>
                    <?php
                }
                ?>            
                  <label style="font-size:12px;" for="lf_activate_checkout_checkbox"><?php _e('Add A Checkout To This Post','lf'); ?></label>
                  <style>input.lf-checkbox{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen-Sans,Ubuntu,Cantarell,Helvetica Neue,sans-serif;padding:6px 8px;box-shadow:0 0 0 transparent;transition:box-shadow .1s linear;font-size:16px;line-height:normal;border:1px solid #1e1e1e;transition:none;border-radius:2px;background:#fff;color:#1e1e1e;clear:none;cursor:pointer;display:inline-block;line-height:0;margin:0 4px 0 0;outline:0;padding:0!important;text-align:center;vertical-align:top;width:20px;height:20px;-webkit-appearance:none;appearance:none;transition:border-color .1s ease-in-out}input.lf-checkbox[type=checkbox]:checked::before{content:url(data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%2020%2020%27%3E%3Cpath%20d%3D%27M14.83%204.89l1.34.94-5.81%208.38H9.02L5.78%209.67l1.34-1.25%202.57%202.4z%27%20fill%3D%27%233582c4%27%2F%3E%3C%2Fsvg%3E);margin:-.1875rem 0 0 -.25rem;height:1.5125rem;width:1.5125rem}</style>
                <?php

    }


/**
   * Save Content In Metabox
   *
   * @since 1.0.0
   *
   * @return void
   */

public function save( $post_id ) { 
$data = '';

/*
     * We need to verify this came from the our screen and with 
     * proper authorization,
     * because save_post can be triggered at other times.
     */

    // Check if our nonce is set.
    if (!isset($_POST['lf_nonce_check_value']))
      return $post_id;

    $nonce = $_POST['lf_nonce_check_value'];

    // Verify that the nonce is valid.
    if (!wp_verify_nonce($nonce, 'lf_nonce_check'))
      return $post_id;

    // If this is an autosave, our form has not been submitted,
    //     so we don't want to do anything.
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
      return $post_id;

    // Check the user's permissions.
    if ('page' == $_POST['post_type']) {

      if (!current_user_can('edit_page', $post_id))
        return $post_id;

    } else {

      if (!current_user_can('edit_post', $post_id))
        return $post_id;
    }

    /* OK, its safe for us to save the data now. */

    // Sanitize the user input.
if (isset($_POST['lf_activate_checkout_checkbox']) ) {
    $data = sanitize_text_field($_POST['lf_activate_checkout_checkbox']);
}

    // Update the meta field.
    update_post_meta($post_id, '_lf_activate_checkout_checkbox', $data);
  }


/**
   * Add Checkout Components If Checkbox Checked
   *
   * @since 3.5.3
   *
   * @return void
   */

public function before_the_content($content) {

  $before_the_content = '[lf-checkout-form-start]';

  $fullcontent = $before_the_content.$content;

  return $fullcontent;
}


public function after_the_content($content) {

  $after_the_content = '[lf-checkout-form-end]';

  $fullcontent = $content.$after_the_content;

  return $fullcontent;
}




public function checkbox_value(){ 

global $post;

  if ( get_post_meta($post->ID, '_lf_activate_checkout_checkbox', true) == true) {
    // add checkout components before and after the content

    add_action ('the_content', array ($this, 'before_the_content') );
    add_action ('the_content', array ($this, 'after_the_content') );

  } 

}



} // leave in place
/**
 * Finally, instantiate the class
 */

new CheckoutActivateClass;