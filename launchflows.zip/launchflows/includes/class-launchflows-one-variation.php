<?php

class LFOneVariation {

	/**
	 * Method to kickstart the code.
	 *
	 * @return void
	 */
	public static function start(){
		new LFOneVariation;
	}

	/**
	 * Adds all necessary action hooks
	 */
	private function __construct(){
		add_action('woocommerce_process_product_meta', array($this, 'saveProductGeneralTabField'));

	}

	/**
	 * Saves the checkbox selection state ("yes" by default)
	 */
	public function saveProductGeneralTabField($id){
			update_post_meta($id, 'onevariation_input', $_POST['onevariation_input'] );
	}

}

/**
 * Finally, start the class
 */

LFOneVariation::start();