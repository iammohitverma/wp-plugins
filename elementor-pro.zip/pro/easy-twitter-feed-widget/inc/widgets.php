<?php
/**
 * Plugin Widgets
 */

// Twitter Widget
require DO_ETFW_DIR . '/inc/widget-twitter.php';
