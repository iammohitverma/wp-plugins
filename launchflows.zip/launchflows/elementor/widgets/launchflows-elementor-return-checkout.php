<?php
namespace LaunchFlowsElementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * LaunchFlows Elementor
 *
 * Elementor widget for LaunchFlows
 *
 * @since 1.0.0
 */
class LaunchFlowsElementorReturnCheckout extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'lf-return-checkout';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'LaunchFlows Return To Checkout', 'lf' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-exchange';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.2.2
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'launchflows'];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'lf' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 3.3.5
	 *
	 * @access protected
	 */

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'lf' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);


			$this->add_control(
				'content',
				[
					'label' => __( 'Select Component To Add:', 'lf' ),
					'type' => Controls_Manager::HIDDEN,
					'default' => '[lf-return-checkout]',
				]

			);		

			$this->add_control(
				'hr_hide_content',
				[
					'type' => \Elementor\Controls_Manager::DIVIDER,
				]
			);	

		$this->end_controls_section();


	} // end method



/**
	 * Render CSS Style
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */

   public function __construct($data = [], $args = null) {
      parent::__construct($data, $args);
      wp_register_style( 'lf-elementor', LF_DIR_URL . 'elementor/css/launchflows-elementor.css', false, '1.0.0');
   }

  public function get_style_depends() {
     return [ 'lf-elementor' ];
  }

/**
	 * Render shortcode widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 3.2.2
	 * @access protected
	 */

	protected function render() {

		$settings = $this->get_settings_for_display();


		$content = $this->get_settings( 'content' );


		// trim brackets from shortcode for css and string generation
		$css = trim($content, "[]");


		$content = '['.$css .' ]';

		// output shortcode string
		$shortcode = do_shortcode( shortcode_unautop( $content ) );
	
		// For Testing Shortcode Output
		//echo $content;	

		?>

				<div class="lf-shortcode" >
			
				<?php if(is_admin()) { ?>
	
					<div id="<?php echo $css; ?>" class="admin-only">
		
					<div></div>
		
					</div>

				<?php }	?>

				<?php echo $shortcode; ?>

				</div>

		<?php	
	    

	} // end render


} //end	widget