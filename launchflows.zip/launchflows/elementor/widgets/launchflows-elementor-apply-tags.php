<?php
namespace LaunchFlowsElementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * LaunchFlows Elementor
 *
 * Elementor widget for LaunchFlows
 *
 * @since 1.0.0
 */
class LaunchFlowsElementorApplyTags extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'lf-apply-tags';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'LaunchFlows Apply Tags/Ids', 'lf' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-plus-circle';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.2.2
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'launchflows'];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'lf' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 3.2.2
	 *
	 * @access protected
	 */

	protected function _register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'WPFusion - Apply Tags/Ids', 'lf-apply-tags' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'content',
			[
				'label' => __( 'Select Component To Add:', 'lf-apply-tags' ),
				'type' => Controls_Manager::HIDDEN,
				'default' => '[lf-apply-tags]',
			]

		);		
		$this->add_control(
			'product',
			[
				'label' => __( 'Tags or IDs: ', 'lf-apply-tags' ),
				'type' => Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'separate with comma', 'lf' ),	
			]
		);
		$this->add_control(
			'debug',
			[
				'label' => __( 'Debug Mode:', 'lf' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'On', 'lf' ),
				'label_off' => __( 'Off', 'lf' ),
				'return_value' => 'yes',
				'default' => 'no',			
			]
		);		
$this->end_controls_section();

// end
	}



/**
	 * Render CSS Style
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */

   public function __construct($data = [], $args = null) {
      parent::__construct($data, $args);
      wp_register_style( 'lf-elementor', LF_DIR_URL . 'elementor/css/launchflows-elementor.css', false, '1.0.0');
   }

  public function get_style_depends() {
     return [ 'lf-elementor' ];
  }

/**
	 * Render shortcode widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */

	protected function render() {

		$settings = $this->get_settings_for_display();

		// full shortcode
		$content = $this->get_settings( 'content' );
		
	    // product id from elementor field
		$product = $this->get_settings( 'product' );

		// debug from elementor field
		$debug = $this->get_settings( 'debug');

	    // form field text from elementor field
		$field_text = $this->get_settings( 'field_text' );

	    // button text from elementor field
		$button_text = $this->get_settings( 'button_text' );

		// trim brackets from shortcode for css and string generation
		$css = trim($content, "[]");

		// build shortcode
		if ($product !=='') {

			$content = '['.$css .' tags="'. $product.'" debug="'. $debug.'"]';

		}



		// displays shortcode syntax only in admin editor, not on front end
		if( is_admin() ) {  

			// output shortcode for testing
			//echo $content;

			?>
			
			<div id="<?php echo $css; ?>" class="admin-only">
				<!--?php echo $content; ?-->

				<span class="wpf-logo">

				<?php echo '<img class="wpf-logo" src="'.LF_DIR_URL.'/elementor/images/wpfusion.png"></img>'; ?>

				</span>				

				<span class="tag-label"><?php echo __('Apply', 'lf'); ?></span>

				<span class="wpf-tags"><strong><?php echo $product; ?></strong></span>

			</div> 

			<?php 

		} else {

		// output final string as new shortcode
		$shortcode = do_shortcode( shortcode_unautop( $content ) );

		// outputs shortcode to front
		?>
		<div class="lf-shortcode" >
		<?php echo $shortcode; ?>
		</div>
		<?php
		}


}

//end	
}