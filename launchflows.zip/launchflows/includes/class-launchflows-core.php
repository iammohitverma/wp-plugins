<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

/**
 * LaunchFlowsCore Class
 *
 *
 * @since 1.0.0
 */

class LaunchFlowsCore {


  /**
   * Constructor
   *
   * @since 3.3.5
   * @access public
   */

  public function __construct() {

    add_shortcode( 'lf-account',            array ($this, 'lf_layout_account_shortcode' ) );
    add_shortcode( 'lf-additional',         array ($this, 'lf_layout_additional_shortcode' ) );   
    add_shortcode( 'lf-always-in',          array ($this, 'lf_always_in_checkout' ) );
    add_shortcode( 'lf-autoclick',          array ($this, 'lf_layout_autoclick_shortcode' ) );
    add_shortcode( 'lf-billing',            array ($this, 'lf_layout_billing_shortcode' ) );
    add_shortcode( 'lf-bump',               array ($this, 'lf_bump' ));
    add_shortcode( 'lf-cart-discount',      array ($this, 'lf_layout_cart_discount_shortcode' ));
    add_shortcode( 'lf-checkout-button',    array ($this, 'lf_layout_checkout_button_shortcode' ) );
    add_shortcode( 'lf-donate',             array ($this, 'lf_layout_donate_shortcode' ) );
    add_shortcode( 'lf-donation',           array ($this, 'lf_layout_donation_shortcode' ) );
    add_shortcode( 'lf-emptycart',          array ($this, 'lf_layout_emptycart_shortcode' ) );
    add_shortcode( 'lf-hide-related',       array ($this, 'lf_layout_hide_related_products_shortcode' ) );
    add_shortcode( 'lf-hide-wc-tabs',       array ($this, 'lf_layout_hide_wc_tabs_shortcode' ) );
    add_shortcode( 'lf-last-order',         array ($this, 'lf_layout_last_order_shortcode' ) );
    add_shortcode( 'lf-login',              array ($this, 'lf_layout_login_shortcode' ) );
    add_shortcode( 'lf-loyalty',            array ($this, 'lf_loyalty') );
    add_shortcode( 'lf-notices',            array ($this, 'lf_layout_notices_shortcode' ) );
    add_shortcode( 'lf-payment',            array ($this, 'lf_layout_payment_shortcode' ) ); 
    add_shortcode( 'lf-payment-methods',    array ($this, 'lf_layout_display_payment_methods_shortcode' ) );
    add_shortcode( 'lf-product-link',       array ($this, 'lf_layout_product_link_shortcode' ) );
    add_shortcode( 'lf-review',             array ($this, 'lf_layout_review_shortcode' ) );
    add_shortcode( 'lf-return-checkout',    array ($this, 'lf_layout_return_checkout_shortcode' ) );
    add_shortcode( 'lf-save-stripe-cc',     array ($this, 'lf_layout_save_stripe_cc' ) );
    add_shortcode( 'lf-save-square-cc',     array ($this, 'lf_layout_save_square_cc' ) );
    add_shortcode( 'lf-scroll-to-checkout', array ($this, 'lf_layout_scroll_to_checkout_shortcode' ) );
    add_shortcode( 'lf-shipping',           array ($this, 'lf_layout_shipping_shortcode' ) );
    add_shortcode( 'lf-subtotal',           array ($this, 'lf_layout_subtotal_shortcode' ) );
    add_shortcode( 'lf-tax-total',          array ($this, 'lf_layout_tax_total_shortcode' ) ); 
    add_shortcode( 'lf-thank-you',          array ($this, 'lf_layout_last_order_shortcode' ) );
    add_shortcode( 'lf-total',              array ($this, 'lf_layout_total_shortcode' ) );
    add_shortcode( 'lf-total-shipping',     array ($this, 'lf_layout_total_shipping_shortcode' ) );
    add_shortcode( 'lf-user-avatar',        array ($this, 'lf_layout_user_avatar_shortcode') );
    add_shortcode( 'lf-wccoupon',           array ($this, 'lf_layout_wccoupon_shortcode' ) );
    add_shortcode( 'lf-upsell',             array ($this, 'lf_layout_upsell_shortcode' ) );

    // product page shortcodes
    add_shortcode( 'lf-product-breadcrumb' ,    array ($this, 'lf_layout_product_breadcrumb_shortcode' ) );
    add_shortcode( 'lf-product-add-to-cart' ,   array ($this, 'lf_layout_product_cart_shortcode' ) );
    add_shortcode( 'lf-product-description' ,   array ($this, 'lf_layout_product_description_shortcode' ) );
    add_shortcode( 'lf-product-firstpayment' ,  array ($this, 'lf_layout_product_firstpayment_shortcode' ) );
    add_shortcode( 'lf-product-images' ,        array ($this, 'lf_layout_product_images_shortcode' ) );
    add_shortcode( 'lf-product-meta' ,          array ($this, 'lf_layout_product_meta_shortcode' ) );
    add_shortcode( 'lf-product-price' ,         array ($this, 'lf_layout_product_price_shortcode' ) );
    add_shortcode( 'lf-product-related' ,       array ($this, 'lf_layout_product_related_shortcode' ) );
    add_shortcode( 'lf-product-tabs' ,          array ($this, 'lf_layout_product_tabs_shortcode' ) );
    add_shortcode( 'lf-product-title' ,         array ($this, 'lf_layout_product_title_shortcode' ) );   

    // kadence theme page shortcodes
    add_shortcode( 'lf-product-extras' ,        array ($this, 'lf_layout_product_extras_shortcode' ) );
    add_shortcode( 'lf-product-payments' ,      array ($this, 'lf_layout_product_payments_shortcode' ) );
    add_shortcode( 'lf-product-breadcrumbs' ,   array ($this, 'lf_layout_product_breadcrumbs_shortcode' ) );

    // single product blank template components
    add_shortcode( 'lf-product-template-one' ,  array ($this, 'lf_layout_product_template_one_shortcode' ) );
 
    // Custom Theme Builder Integration Of Checkout Components
    add_shortcode( 'lf-checkout-form-start',    array ($this, 'lf_checkout_form_start' ) );
    add_shortcode( 'lf-checkout-form-end',      array ($this, 'lf_checkout_form_end' ) );

    // full checkout form to be used in products page
    add_shortcode( 'lf-checkout-form',          array ($this, 'lf_checkout_form' ) );

    // redirection
    add_shortcode( 'lf-redirect', array ($this, 'lf_redirect_url') );

    // dynamic content hook
    add_shortcode( 'lf-dynamic', array ($this, 'lf_dynamic') );

    // force load LaunchFlows scripts
    add_shortcode( 'lf-scripts', array ($this, 'lf_scripts') );

    // for custom WC form-checkout template
    add_filter( 'woocommerce_locate_template',  array ($this,'lf_layout_wc_templates'), 9999, 3  );
  
    // for tinymce    
    add_action('admin_head', array ($this, 'lf_tiny_mce' ) );

    // for custom checkout.js
    add_action('wp_enqueue_scripts', array($this, 'lf_replace_checkout_js' ) );

    // remove cart notices from before checkout form hook so it can be used exclusively with shortcode
    add_action( 'init', array($this, 'lf_skyverge_remove_cart_notice_on_checkout' ) );

    // clear cart via url string before adding new product
    add_action( 'init', array($this, 'lf_clear_cart' ) ); 
  
  } // end construct

/**
* Force Load LF Scripts
* 
* @since 4.1.2
* @access public
*/
function lf_scripts(){
     
    ob_start();
    do_action('lf_scripts' );
    return ob_get_clean();
}


/**
* Dynamic Content Hook
* 
* @since 4.1.1
* @access public
*/
function lf_dynamic($atts){
    $atts = shortcode_atts(
        array(
            'hook' => '',
        ), $atts );

    if ( ! $atts['hook'] ) {
        return _e('No Hook Provided!', 'lf');
    }

    // if content block is active then apply redirection rule
      
    ob_start();
    do_action( $atts['hook'] );
//    echo $atts['hook'];
    return ob_get_clean();
}


/**
* Redirection
* 
* @since 4.1.1
* @access public
*/
function lf_redirect_url($atts){
    $atts = shortcode_atts(
        array(
            'url' => '',
            'sec' => '0'
        ), $atts );

    if ( ! $atts['url'] ) {
        return _e('No URL Provided!', 'lf');
    }

    ob_start();

//    echo $atts['id'];
      if($atts['url'] !='')
      {
      ?>
        <meta http-equiv="refresh" content="<?php echo $atts['sec']; ?>; url=<?php echo $atts['url']; ?>">
      <?php
      }
    return ob_get_clean();
}


/**
* Start Checkout Form
* 
* @since 4.0
* @access public
*/

// generates checkout form start for any theme or page builder
public function lf_checkout_form_start() {

if( ! is_admin() ) { // conditional check don't run on admin

       ob_start();
       global $wp; 

        echo '<div id="lf-form" class="lf-form" style="display:none;">';

        
        // for my-account/checkout/order-pay WC and post order redirect, WC uses custom templates       
        if ( !empty( $wp->query_vars['order-pay'] ) || isset( $wp->query_vars['order-received'] )) {
          
             echo do_shortcode('[woocommerce_checkout]');

            } else {

              // add launchflows scripts and css 
              do_action('lf_content');


              // include custom checkout-form
              // Show non-cart errors.
              do_action( 'woocommerce_before_checkout_form_cart_notices' );

              // Check cart has contents.

              if ( WC()->cart->is_empty() && ! is_customize_preview() && apply_filters( 'woocommerce_checkout_redirect_empty_cart', true ) ) {
                return;
              }
              
              // Check cart contents for errors.
              do_action( 'woocommerce_check_cart_items' );

              // Calc totals.
              WC()->cart->calculate_totals();

              // Get checkout object.
              $checkout = WC()->checkout();

                  if ( empty( $_POST ) && wc_notice_count( 'error' ) > 0 ) { // WPCS: input var ok, CSRF ok.

                    wc_get_template( 'checkout/cart-errors.php', array( 'checkout' => $checkout ) );

                    wc_clear_notices();

                  } else {

                    ?>
                    <div class="woocommerce">
                    <?php

                    $non_js_checkout = ! empty( $_POST['woocommerce_checkout_update_totals'] ); // WPCS: input var ok, CSRF ok.

                    if ( wc_notice_count( 'error' ) === 0 && $non_js_checkout ) {
                      wc_add_notice( __( 'The order totals have been updated. Please confirm your order by pressing the "Place order" button at the bottom of the page.', 'ecw-checkout-widget' ) );
                    }

                    do_action( 'woocommerce_before_checkout_form', $checkout );

                    // If checkout registration is disabled and not logged in, the user cannot checkout.
                    if ( ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in() ) {
                      echo esc_html( apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'You must be logged in to checkout.', 'ecw-checkout-widget' ) ) );
                      return;
                    }


                    // launchflows custom form-checkout proxy goes here
                    ?>
                    <form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data">
                    
                    <!-- disable any leftover instance of checkout shortcode from previous editing -->
                    <?php remove_shortcode('woocommerce_checkout'); ?>    

                      <?php if ( $checkout->get_checkout_fields() ) : ?>

                            <?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>

                      <?php endif; ?>
                      

                  <?php 
                  } // end empty post

        } // end check for empty cart

?>
<div id="lf-editor-content">
<!--?php the_content(); ?--> 
<?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;

   } // end admin check    
} // end function

/**
* End Checkout Form
* 
* @since 4.0
* @access public
*/

// generates checkout form end for any theme or page builder
public function lf_checkout_form_end() {
if( ! is_admin() ) { // conditional check don't run on admin

       ob_start();
?>


</div><!-- /#content-editor -->
<?php do_action( 'woocommerce_checkout_before_order_review_heading' ); ?>
 
<?php 
global $wp;

        // check that there is a value set for container width, otherwise use default
        $options = get_option( 'lf_settings' );

          if( isset($options['lf_text_field_20']) && !empty($options['lf_text_field_20']) ) {     

              $max_width = $options['lf_text_field_20']; // applies new text from plugin admin panel

          } else {

            $max_width = '100%';// set default to 1200 px

          }

        // now add container wrapper around default checkout components
        echo '<div class="lf-container" style="overflow:hidden; margin:0 auto; max-width:'.$max_width.'">'; 
?>
                            <div id='order_main_wrap'>

                              <?php do_action( 'woocommerce_checkout_billing' ); ?>

                              <?php do_action( 'woocommerce_checkout_shipping' ); ?>

                              <?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>

                            </div>                      

                            <div id="order_review_wrap"><!-- lf added to hold heading with rest -->

                              <h3 id="order_review_heading"><?php esc_html_e( 'Your order', 'woocommerce' ); ?></h3>
                              
                              <?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

                              <div id="order_review" class="woocommerce-checkout-review-order">

                                <?php do_action( 'woocommerce_checkout_order_review' ); ?>

                              </div>

                              <?php do_action( 'woocommerce_checkout_after_order_review' ); ?>

                            </div><!-- /lf --> 

<?php echo '</div>'; // end .lf-container ?>

       </form>

<?php if ( !empty( $_POST ) && wc_notice_count( 'error' ) < 1 ) { ?>
      


      <?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>

      </div>
      
      <?php }
        
        echo '</div>';
        
        do_action( 'lf_after_form' );

       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;

 } // end admin check
}

/**
* Product Checkout Page Shortcode
* 
* @since 3.5.3
* @access public
*/
// generates full checkout form
public function lf_checkout_form() {
if( ! is_admin() ) { // conditional check don't run on admin

  ob_start();

  global $wp;
       
    // output product wrapper around entire setup - required for some css to function properly
    if ( is_product() ){ // adds necessary style div for css to apply when moving components
    ?>
    <div id="product-<?php the_ID(); ?>" <?php wc_product_class( '', $product ); ?>>
    <?php
    }


      // wraps original checkout contents and hides until page fully loads
      echo '<div id="lf-form" class="lf-form" style="display:none;">';

        // for my-account/checkout/order-pay WC and post order redirect, WC uses custom templates       
        if ( !empty( $wp->query_vars['order-pay'] ) || isset( $wp->query_vars['order-received'] )) {
          
             echo do_shortcode('[woocommerce_checkout]');

          } else {

                    // add launchflows scripts and css 
                    do_action('lf_content');


                    // include custom checkout-form
                    // Show non-cart errors.
                    do_action( 'woocommerce_before_checkout_form_cart_notices' );

                    // Check cart has contents.

                    if ( WC()->cart->is_empty() && ! is_customize_preview() && apply_filters( 'woocommerce_checkout_redirect_empty_cart', true ) ) {
                      return;
                    }
                    
                    // Check cart contents for errors.
                    do_action( 'woocommerce_check_cart_items' );

                    // Calc totals.
                    WC()->cart->calculate_totals();

                    // Get checkout object.
                    $checkout = WC()->checkout();

                    // start conditional check loop 2
                    if ( empty( $_POST ) && wc_notice_count( 'error' ) > 0 ) { // WPCS: input var ok, CSRF ok.

                      wc_get_template( 'checkout/cart-errors.php', array( 'checkout' => $checkout ) );

                      wc_clear_notices();

                    } else {

                    echo '<div class="woocommerce">';


                          $non_js_checkout = ! empty( $_POST['woocommerce_checkout_update_totals'] ); // WPCS: input var ok, CSRF ok.

                          if ( wc_notice_count( 'error' ) === 0 && $non_js_checkout ) {
                            wc_add_notice( __( 'The order totals have been updated. Please confirm your order by pressing the "Place order" button at the bottom of the page.', 'ecw-checkout-widget' ) );
                          }

                          do_action( 'woocommerce_before_checkout_form', $checkout );

                          // If checkout registration is disabled and not logged in, the user cannot checkout.
                          if ( ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in() ) {
                            echo esc_html( apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'You must be logged in to checkout.', 'lf' ) ) );
                            return;
                          }

                          // start launchflows custom checkout form
                          ?>
                          <form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data">
                                  
                             <?php 
                             
                            // output the new components from content editor above checkout
                            // adds content area
                            echo '<div id="lf-the-content">';
                            the_content(); 
                            echo '</div><!-- /#lf-the-content -->';
                             
                             // remove if [woocommerce_checkout] remains in the_content
                             remove_shortcode('woocommerce_checkout');     

                            // check for user set value for inner container, otherwise use default
                            $options = get_option( 'lf_settings' );

                            if( isset($options['lf_text_field_20']) && !empty($options['lf_text_field_20']) ) {     
                                // applies new text from plugin admin panel
                                $max_width = $options['lf_text_field_20']; 
                                } else {
                                $max_width = '100%';// set default to 1200 px
                              } 

                            // allows inner container to be sized instead of full width     
                            echo '<div class="lf-container" style="margin:0 auto; max-width:'.$max_width.'">';

                                  // check if any checkout fields
                                  if ( $checkout->get_checkout_fields() ) :

                                      do_action( 'woocommerce_checkout_before_customer_details' );         

                                            echo '<div id="order_main_wrap">';

                                              do_action( 'woocommerce_checkout_billing' );

                                              do_action( 'woocommerce_checkout_shipping' );

                                              do_action( 'woocommerce_checkout_after_customer_details' );

                                            echo'</div>'; 

                                  endif; 
                                          
                                      do_action( 'woocommerce_checkout_before_order_review_heading' );

              
                                                        
                                            echo '<div id="order_review_wrap">';

                                                  echo '<h3 id="order_review_heading">'. esc_html_e( "Your order", "woocommerce" ) .'</h3>';
                                                  
                                                  do_action( 'woocommerce_checkout_before_order_review' );

                                                    echo'<div id="order_review" class="woocommerce-checkout-review-order">';

                                                      do_action( 'woocommerce_checkout_order_review' );

                                                    echo '</div>';

                                                  do_action( 'woocommerce_checkout_after_order_review' );

                                            echo '</div>';
                            
                            // .lf-container             
                            echo '</div>'; 


                    } // end conditional check loop 2 
            
          } // end conditional check loop 1


                      // check form is not empty and has no errors
                      if ( !empty( $_POST ) && wc_notice_count( 'error' ) < 1 ) { 
                            
                        do_action( 'woocommerce_after_checkout_form', $checkout );
                      
                      } // end check form

                  // end launchflows checkout form
                  echo '</form>'; 

            // end #lf-form wrapper   
            echo '</div>'; 
  
      // hook for post form actions              
      do_action( 'lf_after_form' );

    // end product wrapper
    if ( is_product() ){ // adds necessary style div for css to apply when moving components 
    echo '</div>';
    }

  $output = ob_get_contents();   
  ob_end_clean();   
  return $output;  
  } // end admin check  
}

/**
* Return To Checkout After Reloading (ie: after order bump, upsell, etc)
*
* @since 3.3.5
* @access public
*/

function lf_layout_return_checkout_shortcode() {
if( ! is_admin() ) { // conditional check don't run on admin
ob_start();
        ?>
          <script type="text/javascript">
          // set scrollpos before reloading
          window.onbeforeunload = function(e) {

              // set scroll position (string) to a cookie
              Cookies.set('scrollpos', window.pageYOffset); 
              
          };

          // trigger scroll after DOM content has loaded        
          document.addEventListener('DOMContentLoaded', function(event) { 

              // check for ios and mobile             
              if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)){
                          
                  // longer delay required for mobile browsers
                  setTimeout(scrollToCheckout, 2000);

              } else {
              
                  // shorter delay for regular browsers
                  setTimeout(scrollToCheckout, 500);
                  
              }


              function scrollToCheckout() {

                  // set variable to cookie value
                  var scrollpos = Cookies.get('scrollpos');
                      
                      // iOS and mobile scroll to #checkout after short delay   
                      if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)){

                          jQuery('html, body').animate({scrollTop:jQuery('#checkout').position().top}, 100);            

                      } else {
                          
                      // desktop scroll to position after short delay
                      jQuery('html, body').animate({ scrollTop:scrollpos }, 100); 
                          
                      }
              
              }
              
          });
          </script>
        <?php

$output = ob_get_contents();   

ob_end_clean();   

return $output;
  }// end check
}




 /**
   * Clear Cart URL String (used to clear before adding new product in upsell)
   *
   * @since 3.2.2
   * @access public
   */

public function lf_clear_cart() {
// add &accept on to end of any ?add-to-cart
  if ( isset( $_GET['clearcart'] ) ) {
    WC()->cart->empty_cart();
  }
}

 /**
   * Product Upsell Shortcode
   *
   * @since 3.5.3
   * @access public
   */

public function lf_layout_upsell_shortcode($atts) {
if( ! is_admin() ) { // conditional check don't run on admin

//stackoverflow.com/questions/48705589/woocommerce-button-to-clear-cart-add-one-item-and-go-to-checkout


  $a = shortcode_atts( array(
  
    'product'   => '' ,

    'next'      => '' ,

    'accept'    => __( 'YES, I WANT IT!', 'lf' ), 

    'accept_tags' => '', 

    'decline'   => __( 'No Thanks, I\'ll pass.', 'lf' ),

    'decline_tags' => '',

    'image'     => 'yes', // default is yes

    'title'     => 'yes', // default is yes

    'price'     => 'yes', // default is yes

    ), $atts, 'lf-upsell' );

// make sure there is a value available for product id, and product exists, otherwise end

if ( !isset($atts['product']) || !get_post_status ( esc_attr($a['product']) ) ) { 

echo '<ul class="woocommerce-error" role="alert"><li>';

esc_html_e( '*Admin: Please set a valid ID for the upsell product.', 'lf' );

echo '</li></ul>';

return;

}

$product_id     =  esc_attr($a['product']); 

$next           =  esc_attr($a['next']); 

$accept         =  esc_attr($a['accept']);

$accept_tags    =  esc_attr($a['accept_tags']);

$decline        =  esc_attr($a['decline']); 

$decline_tags   =  esc_attr($a['decline_tags']);

$image          =  esc_attr($a['image']);

$title          =  esc_attr($a['title']);

$product        =  wc_get_product( $product_id );

$price          =  esc_attr($a['price']);


// get the parent id from product_id if available
$parent_id  = wp_get_post_parent_id( $product_id );

// if parent id exists, set $product_string to include it, otherwise just use product_id
if ($parent_id > 0) {$product_string = get_site_url().'/?add-to-cart='.$parent_id.'&variation_id='.$product_id.'&quantity=1&clearcart';} else {$product_string = get_site_url().'/?add-to-cart='.$product_id.'&clearcart';}

$accept = '<a class="upsell-accept button" data-apply-tags="'.$accept_tags.'" href='.$product_string.'>'.$accept.'</a>';

if ($next) {$next = get_permalink($next);} else {$next = wc_get_checkout_url();}

$decline= '<a class="upsell-decline" data-apply-tags="'.$decline_tags.'" href="'. $next .'">'. $decline.'</a>';

if ($image =='yes') {$image = '<img class="upsell-image" width="500px" src="'.get_the_post_thumbnail_url( $product_id ).'" /></img>';} else {$image = '<img class="upsell-image"></img>';}

if ($title =='yes') { $title = '<div class="upsell-title">'.get_the_title( $product_id ).'</div>';} else {$title = '<div class="upsell-title"></div>';}

if ($price =='yes') { $price = '<div class="upsell-price">'.wc_price($product->get_price()).'</div>';} else {$price ='<div class="upsell-price"></div>';}

ob_start();
?>

<div id="lf-upsell">

  <div class="lf-upsell _<?php echo $product_id; ?>">

    <?php echo $image; ?>

    <?php echo $title; ?>

    <?php echo $price; ?>

    <?php echo $accept; ?>

    <?php echo $decline; ?>

  </div>
  
</div>

<style>

#lf-upsell {
flex-direction: column;
text-align: center;
display:flex;
}

.lf-upsell {
display: contents;
}

.lf-upsell-form {
margin: 10px auto;
}

.upsell-image {
margin: 0 auto;
}

.upsell-title {
font-weight: 600;
font-size: 1.5rem;
}

.upsell-price {
font-size: 2rem;
font-weight: 900;
}

.upsell-title,
a.upsell-accept.button,
.upsell-decline {
margin-top: 20px;
margin-left:auto!important;
margin-right:auto!important;
}

.upsell-decline {
  color:inherit;
}

</style>


<?php


// if upsell button is set, empty the cart and add the new product, then redirect to checkout
if ( isset($_POST['lf_upsell']) ){

WC()->cart->empty_cart();

WC()->cart->add_to_cart( $product_id );

wp_redirect( wc_get_checkout_url() );

exit();

}


$output = ob_get_contents();   

ob_end_clean();   

return $output;

  } // end admin check
} // end function



 /**
   * Remove default display on before checkout form for skyverge cart notices plugin adds to lf-notices shortcode instead
   *
   * @since 1.1.2
   * @access public
   */
public function lf_skyverge_remove_cart_notice_on_checkout() {
   if ( function_exists( 'wc_cart_notices' ) ) {
      remove_action( 'woocommerce_before_checkout_form', array( wc_cart_notices(), 'add_cart_notice' ) );
   }
}


 /**
   * Replaces WC checkout.js so we can modify layouts even after ajax refresh
   *
   * @since 4.0.3
   * @access public
   */

public function lf_replace_checkout_js() {
global $post;

  // only replace checkout.js script if the option to add checkout is enabled for this post
  if ( get_post_meta($post->ID, '_lf_activate_checkout_checkbox', true) == true) {

      wp_deregister_script('wc-checkout');
      wp_enqueue_script('wc-checkout', plugin_dir_url( __FILE__ ) . '../assets/js/checkout.js', array('jquery', 'woocommerce', 'wc-country-select', 'wc-address-i18n'), null, true);
  }
} 


/**
   * Dynamic Order Bump Shortcode
   *
   * @since 3.3.6
   * @access public
   */

public function lf_bump($atts) {
if( ! is_admin() ) { // conditional check don't run on admin
//stackoverflow.com/questions/50150953/check-if-a-product-variation-is-in-cart-in-woocommerce *answer2

// first make sure there is a value available for product id, otherwise end
if(!isset($atts['product'])) { 

echo '<ul class="woocommerce-error" role="alert"><li>';

esc_html_e( '*Admin: Please set a valid ID for the dynamic bump product.', 'lf' );

echo '</li></ul>';

} else { // carry on

  $a = shortcode_atts( array(

    'product' => '',

    'style'   => '',

    'image'     => 'yes', // default is yes

    'title'     => 'yes', // default is yes

    'price'     => 'yes', // default is yes    

    'shortdesc' => 'yes', // default is yes

  ), $atts, 'lf-bump' );

if (ctype_digit(esc_attr($a['product']))) {

  $product_id     =  esc_attr($a['product']); // first get product_id from shortcode $atts

} else {

echo '<ul class="woocommerce-error" role="alert"><li>';

esc_html_e( '*Admin: Please set a valid ID for the dynamic bump product.', 'lf' );

echo '</li></ul>';

return;

}

$price          =  esc_attr($a['price']); // get the checkbox style from shortcode $atts

$checkbox_style =  esc_attr($a['style']); // get the checkbox style from shortcode $atts

$image          =  esc_attr($a['image']);

$title          =  esc_attr($a['title']);

$product        =  wc_get_product( $product_id );

$price          =  esc_attr($a['price']);

$short_desc     =  esc_attr($a['shortdesc']);



if ($image =='yes') { $image = '<img class="bump-image" src="'.get_the_post_thumbnail_url( $product_id ).'" /></img>';} else {$image = '<img class="bump-image" style="width:0; margin:0; padding:0;"></img>';}

if ($title =='yes') { $title = '<span class="bump-title">'.get_the_title( $product_id ).'</span>';} else {$title = '<span class="bump-title"></span>';}

if ($price =='yes') { $price = '<span class="bump-price">'.wc_price($product->get_price()).'</span>';} else {$price ='<span class="bump-price"></span>';}

if ($short_desc =='yes') { $short_desc = '<span class="bump-short-description">'.$product->get_short_description().'</span>';} else {$short_desc ='<span class="bump-short-description"></span>';}

// now get all the assets

      // we must load cart on admin side with these includes and conditional to avoid cart object being "null"
      // coderoad.ru/63077103/WooCommerce-get_cart-%D0%BD%D0%B0-null
      include_once WC_ABSPATH . 'includes/wc-cart-functions.php';
      include_once WC_ABSPATH . 'includes/class-wc-cart.php';

      if ( is_null( WC()->cart ) ) {
        wc_load_cart();
      }

if( ! is_admin() ) { // conditional check don't run on admin

foreach( WC()->cart->get_cart() as $cart_item_key => $cart_item ){    // check each item in cart


  $cart_item_remove_url = wc_get_cart_remove_url( $cart_item_key );   // build remove cart url
  
  $product_cart_id = WC()->cart->generate_cart_id( $product_id );   // get cart id from product

  // for variable products get the parent id from product_id
  $parent_id  = wp_get_post_parent_id( $product_id );

  
    // if product is in the cart, use the remove cart url
    if ( ($cart_item['product_id'] == $product_id) || ($cart_item['data']->get_id() == $product_id) ) {

ob_start();  

        echo '<span class="lf-shortcode">';

        echo '<span id="lf-bump">';
    
        echo '<span class="lf-bump _'.$product_id.'">';

        echo '<a href="' . $cart_item_remove_url . '"><span id="checkbox_style" class="pretty p-default '.$checkbox_style.'"><input class="switch" type="checkbox" checked="checked" data-target="'.$cart_item_remove_url.'"><span class="state"><label></label></span></input></span></a>';
        
        echo $image;
        
        echo $title;

        echo $price; 

        echo '</span>';

        // product short description

        echo $short_desc;
    
        echo '</span>';
    
        echo '</span>';


$output = ob_get_contents();   

ob_end_clean();   

return $output;

    } 
  }// end admin check  

}   // done searching for products in the cart


// if product is not in the cart

  // first get the parent id from product_id if available
  $parent_id  = wp_get_post_parent_id( $product_id );

    // if parent id exists, set $product_string to include it, otherwise just use product_id
    if ($parent_id > 0) {

      $product_string = get_site_url().'/?add-to-cart='.$parent_id.'&variation_id='.$product_id.'&quantity=1';

    } else {

      $product_string = get_site_url().'/?add-to-cart='.$product_id;

    }

    // since we already know product is not in the cart, display the add-to-cart url instead of remove

ob_start();

        echo '<span class="lf-shortcode">';

        echo '<span id="lf-bump">';

        echo '<span class="lf-bump _'.$product_id.'">';

        echo '<a class="add" href="'.$product_string.'"><span id="checkbox_style" class="pretty p-default '.$checkbox_style.'"><input class="switch" type="checkbox" data-target="'.$product_string.'"><span class="state"><label></label></span></input></span></a>';
        
        echo $image;

        echo $title;
        
        echo $price;

        echo '</span>';

        // product short description

        echo $short_desc;

        echo '</span>';

        echo '</span>';


$output = ob_get_contents();   

ob_end_clean();   

return $output;

  } // end check for product
 } // end admin
} // end lf-bump

 /**
   * Always In Checkout Shortcode
   * 
   * 
   *
   * @since 3.5.3
   * @access public
   */

public function lf_always_in_checkout($atts, $cart_check, $link) {
if( ! is_admin() ) { // conditional check don't run on admin

// make sure there is a value available for product id, otherwise end
if(!isset($atts['product'])) { 

echo '<ul class="woocommerce-error" role="alert"><li>';

esc_html_e( '*Admin: Please set an ID for the always in checkout product.', 'lf' );

echo '</li></ul>';


} else { // carry on


  $a = shortcode_atts( array(

    'product' => '',

    'style'   => '',

    'icon'     => 'yes', // default is yes

    'image'     => 'yes', // default is yes

    'title'     => 'yes', // default is yes

    'price'     => 'yes', // default is yes    

    'shortdesc' => 'yes', // default is yes

  ), $atts, 'lf-always-in' );


// check if the product post exists before assigning the attr value to $product_id
if (ctype_digit(esc_attr($a['product'])) && get_post_status ( esc_attr($a['product']) )) {

  $product_id     =  esc_attr($a['product']); // first get product_id from shortcode $atts

} else {

echo '<ul class="woocommerce-error" role="alert"><li>';

esc_html_e( '*Admin: Please set a valid ID for the always in checkout product.', 'lf' );

echo '</li></ul>';

return;

}

$price          =  esc_attr($a['price']); // get the checkbox style from shortcode $atts

$checkbox_style =  esc_attr($a['style']); // get the checkbox style from shortcode $atts

$icon           =  esc_attr($a['icon']);

$image          =  esc_attr($a['image']);

$title          =  esc_attr($a['title']);

$product        =  wc_get_product( $product_id );

$price          =  esc_attr($a['price']);

$short_desc     =  esc_attr($a['shortdesc']);



if ($icon =='yes') { $icon = '<span id="checkbox_style" class="pretty p-icon p-toggle p-plain"><input><span class="state"><label></label></span></input></span>';} else {$icon = '<img class="always-in-icon"></img>';}

if ($image =='yes') { $image = '<img class="always-in-image" width="50px" src="'.get_the_post_thumbnail_url( $product_id ).'" /></img>';} else {$image = '<img class="always-in-image" style="width:0; margin:0; padding:0;"></img>';}

if ($title =='yes') { $title = '<span class="always-in-title">'.get_the_title( $product_id ).'</span>';} else {$title = '<span class="always-in-title"></span>';}

if ($price =='yes') { $price = '<span class="always-in-price">'.wc_price($product->get_price()).'</span>';} else {$price ='<span class="always-in-price"></span>';}

if ($short_desc =='yes') { $short_desc = '<span class="always-in-short-description">'.$product->get_short_description().'</span>';} else {$short_desc ='<span class="always-in-short-description"></span>';}


// now get all the assets
if( ! is_admin() ) { // conditional check don't run on admin

// we must load cart on admin side with these includes and conditional to avoid cart object being "null"
      // coderoad.ru/63077103/WooCommerce-get_cart-%D0%BD%D0%B0-null
      include_once WC_ABSPATH . 'includes/wc-cart-functions.php';
      include_once WC_ABSPATH . 'includes/class-wc-cart.php';

      if ( is_null( WC()->cart ) ) {
        wc_load_cart();
      }

      // set our flag to be false until we find a product in cart
      $cart_check = false;

      foreach( WC()->cart->get_cart() as $cart_item_key => $cart_item ){    // check each item in cart

      $product = $cart_item['data'];


          // if product is in the cart
          // //stackoverflow.com/questions/50150953/check-if-a-product-variation-is-in-cart-in-woocommerce *answer2
          if ( $cart_item['data']->get_id() == $product_id ) {

          // change flag to true
          $cart_check = true;       
    
          //testing echo '<h1>'.$product_string.'</h1>';

          break; // stop now if in cart
          
          } 
      } 

      if ( $cart_check == false ) {
        // add to cart if product is not already there

      $product_string = get_site_url().'/?add-to-cart='.$product_id;        

          ?>
          <script>  
          jQuery(document).ready(function(){  
          window.location.href=<?php echo json_encode($product_string) ?>;      // sends add/remove link to the browser
          });
          </script> 
          <?php  

      }

  }   // end admin check

ob_start();

        echo '<span class="lf-shortcode">';

        echo '<span id="lf-always-in">';

        echo '<span class="lf-always-in _'.$product_id.'">';

        echo $icon;

        echo $image;

        echo $title;
        
        echo $price;

        echo '</span>';

        // product short description

        echo $short_desc;
        
        echo '</span>';

        echo '</span>';

$output = ob_get_contents();   

ob_end_clean();   

return $output;

    } // end check for product
  } // end admin check
} // end function


 /**
   * Adds Name Your Donation / Name Your Price Form for SHORTCODE ONLY
   *
   * @since 3.5.3
   * @access public
   */


public function lf_layout_donate_shortcode($atts) {
if( ! is_admin() ) { // conditional check don't run on admin

// outputs donation or instant payment via shortcode

ob_start();

// first make sure there is a value available for product id, otherwise end
if(!isset($atts['product'])) { 

echo '<ul class="woocommerce-error" role="alert"><li>';

esc_html_e( '*Admin: Please set a valid ID for the woocommerce product.', 'lf' );

echo '</li></ul>';

} else { // carry on

  $a = shortcode_atts( array(

    'product'   => '',

    'button'    => __( 'Click To Update', 'lf' ),

    'field'     => __( 'Donation Amount', 'lf' ), 
 

  ), $atts, 'lf-donate' );


if (ctype_digit(esc_attr($a['product']))) {

  $product_id     =  esc_attr($a['product']); // first get product_id from shortcode $atts

} else {

echo '<ul class="woocommerce-error" role="alert"><li>';

esc_html_e( '*Admin: Please set a valid ID for the product.', 'lf' );

echo '</li></ul>';

return;

}


$button         =  esc_attr($a['button']); 

$field          =  esc_attr($a['field']); 


    // output markup
    ?>

        <span class="lf-all">

          <span id="lf-donate">
          
            <span class="lf-donate">
            
        
              <input size="1" type="hidden" name="<?php echo $product_id; ?>" id="lf-form-field-product" class="" value="<?php echo $product_id; ?>">


                  <span class="lf-donate-form-fields-wrapper">

                    <span class="lf-donate-column lf-donate-col-50">
                                
                      <input type="text" name="<?php echo $product; ?>" id="lf-form-field-donate" placeholder="<?php echo $field; ?>" value="">       
                    
                    </span>

                    <span class="lf-donate-column lf-donate-col-50">
                    
                      <button type="submit" class="lf-donate-button" id="lf-donate-button">
                
                        <span class="lf-donate-button-content-wrapper">
                         
                          <span class="lf-donate-button-icon donate-button-icon lf-donate-align-icon-left"></span>

                          <span class="lf-donate-button-text lf-donate-button"><?php echo $button; ?></span>

                        </span>

                      </button>
                  
                    </span>

                  </span>

            </span>

            <style>#lf-form-field-donate{width:100%}.lf-donate-form-fields-wrapper{display:-webkit-box;display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap}.lf-donate-col-50{width:50%}.lf-donate-field-group{-ms-flex-wrap:wrap;flex-wrap:wrap;-webkit-box-align:center;-ms-flex-align:center;align-items:center}.lf-donate-column{position:relative;display:-webkit-box;display:-ms-flexbox;display:flex;min-height:1px}</style>       

            <script type="text/javascript">
            // custom donation form creation
            jQuery("#lf-donate-button").click(function(){ // click button with id #lf-donate-button
            event.preventDefault(); // stop regular form
            jQuery("#lf-donate").val(function() { // get product attribute for value inside form #lf-donate
            var product = jQuery("#lf-form-field-product").val(); // use hidden form field for product id
            var amount = jQuery("#lf-form-field-donate").val(); // number inside form field with id #donate
            window.location = "?add-to-cart=" + product + "&donation=" + amount;  // build url string and send to browser
            });
            });
            </script>
            

          </span>
        
        </span>
    <?php
    // end markup

  } // end product check


$output = ob_get_contents();   

ob_end_clean();   

return $output;
 } // end admin check
} // end function


 /**
   * Adds Name Your Donation / Name Your Price Form for ELEMENTOR ONLY
   *
   * @since 3.4.8
   * @access public
   */

public function lf_layout_donation_shortcode($product) {
      ob_start();
      echo '<span id="lf-donation">';
      echo '<span class="lf-donation">';
      echo '<span class="field-warning">'.__('*Please set donation button and field text!').'</span>';
      echo '</span>';
      echo '</span>';      
      $output = ob_get_contents();   
      ob_end_clean();   
      return $output;
}


 /**
   * Shows Preformatted Empty Cart Button In Layout (if not done via url directly. See clas-launchflows-functions.php)
   *
   * @since 3.4.8
   * @access public
   */

public function lf_layout_emptycart_shortcode() {
      ob_start();
      echo '<span id="lf-emptycart">';
      echo '<span class="lf-emptycart">';
      echo '<a id="lf-emptycart" href="' . esc_url( add_query_arg( 'emptycart', 'yes' ) ) . '" class="button" title="' . esc_attr( 'Empty Cart', 'lf' ) . '">' . esc_html( 'Empty Cart', 'lf' ) . "</a>";
      echo '</span>';
      echo '</span>';      
      $output = ob_get_contents();   
      ob_end_clean();   
      return $output;
}

 /**
   * Shows Preformatted Scroll To Checkout Button (if not done with adding class .lf-scroll-to-checkout to any clickable element instead)
   *
   * @since 3.5.3
   * @access public
   */

public function lf_layout_scroll_to_checkout_shortcode($atts) {
      ob_start();
      $a = shortcode_atts( array(

          'style'   => '', // output link by default or use "button"
      
        ), $atts, 'lf-scroll-to-checkout' );

      $style          =  esc_attr($a['style']); // get the link style from shortcode $atts


      echo '<a class="lf-scroll-to-checkout '.$style.'" href="#">Scroll To Checkout</a>';
      $output = ob_get_contents();   
      ob_end_clean();   
      return $output;
}



 /**
   * Shows Logged-in User's Last Order Details In Shortcode
   *
   * @since 3.4.8
   * @access public
   */

public function lf_layout_last_order_shortcode() {
  // stackoverflow.com/questions/57603232/how-to-get-the-last-order-of-a-customer-in-woocommerce
      ob_start();
        // For logged in users only
          if ( is_user_logged_in()) { // see if any conflict with Elementor even on admin now 

            $user_id         = get_current_user_id(); // The current user ID

            // Get the WC_Customer instance Object for the current user
            $customer        = new WC_Customer( $user_id );

            $last_order      = $customer->get_last_order();
            if ( ! $last_order ) { // check if there is a last order, otherwise post notice and stop
              echo '<ul class="woocommerce-error" role="alert"><li>';
              esc_html_e( 'There are no last orders for this user.', 'lf' );
              echo '</li></ul>';
              return false;
            }

            // Get the last WC_Order Object instance from current customer
            $order_id        = $last_order->get_order_number(); // Get the order id (*different method)
            $order_data      = $last_order->get_data(); // Get the order unprotected data in an array
            $order_status    = $last_order->get_status(); // Get the order status
            $payment_method  = $last_order->get_payment_method(); // Get the payment method
            $order_total     = $last_order->get_total(); // Get the order total
            // reserved for later use
            $order_user_id   = $last_order->get_user_id();
            $current_user_id = get_current_user_id();
            $order_email     = $last_order->get_billing_email();
            $order_date      = esc_attr( wc_format_datetime( $last_order->get_date_created() ) );
         ?>
        <span id="lf-last-order"> 
        <span class="lf-last-order">
            <span class="order-details"><?php esc_html_e( 'Order #:', 'lf' ); ?> <?php echo $order_id; ?> - <?php esc_html_e( 'Status:', 'lf' ); ?> <?php echo ucfirst($order_status); ?> (<?php echo ucfirst($payment_method); ?>)</span><br/>
            <hr>
            <?php foreach ( $last_order->get_items() as $order_item ) : ?>
              <span class="lf-last-order-item">
                <?php 
                  $product_image  = apply_filters( 'woocommerce_order_item_product', 
                  $order_item->get_product(), $order_item ); 
                  // adds the featured image for product purchased 
                ?>
                <span class="product-image"><?php echo $product_image->get_image(); ?></span>
                
                <span class="order-item"><?php echo $order_item->get_name() . '<strong> &times; </strong>' . $order_item->get_quantity(); ?></span>&nbsp;&nbsp;<?php echo wc_price($order_item->get_total()); ?><br/>
              
                <?php // purchase note (if exists)
                  $product = $order_item->get_product();
                  $purchase_note = $product->get_purchase_note();
                  if (!empty($purchase_note)) {
                    echo '<span class="purchase-note">';
                    echo do_shortcode( wp_kses_post( $purchase_note ) );
                    echo '</span>';
                  }
                ?>
              </span>
            <?php endforeach; ?>
            
            <hr>
            
              <span class="last-order-total"><?php esc_html_e( 'Total:', 'lf' ); ?>  <?php echo wc_price($order_total);?></span>
            <br/>
        </span>
        </span>
        <?php 
        } //end if

      $output = ob_get_contents();   
      ob_end_clean();   
      return $output;
}

 /**
   * Outputs Product LF Checkout Link URL Via ShortCode (for use in Dynamic Buttons)
   *
   * @since 1.2.2
   * @access public
   */

public function lf_layout_product_link_shortcode() {
      ob_start();
      
     global $post;

        // check for the meta key for the checkout page field
        $meta = get_post_meta( $post->ID, '_lf_checkout_field', true );

        // if no meta, bail to default wc behavior
        if ( empty( $meta ) ) {
        
        // use default wc checkout url instead of custom 
        $checkout_url = get_permalink( wc_get_page_id( 'checkout' ) ); 

        } else {

        // otherwise, get the meta permalink
        $checkout_url = get_permalink( (int) $meta );
        }

      if ( ! empty ( $checkout_url ) ) {  // output link to custom checkout page
      echo $checkout_url . '?add-to-cart=' . $post->ID;
      }         
      
      $output = ob_get_contents();   
      ob_end_clean();   
      return $output;
}


 /**
   * Hides Related Products Block In Any Layout Or Widget When Used
   *
   * @since 1.1.3
   * @access public
   */

public function lf_layout_hide_related_products_shortcode() {
      ob_start();
      echo '<style>section.related.products {display: none!important;}</style>';
      $output = ob_get_contents();   
      ob_end_clean();   
      return $output;
}

/**
   * Hides WooCommerce Product Tabs Wrapper In Any Layout Or Widget When Used
   *
   * @since 3.4.8
   * @access public
   */

public function lf_layout_hide_wc_tabs_shortcode() {
      ob_start();
      echo '<span id="lf-hide-wc-tabs">';
      echo '<style>.wc-tabs-wrapper {display: none!important;}</style>';
      echo '</span>';
      $output = ob_get_contents();   
      ob_end_clean();   
      return $output;
}

 /**
   * User Avatar Shortcode (pulls specific logged in user or default if not logged in)
   *
   * @since 3.4.8
   * @access public
   */

public function lf_layout_user_avatar_shortcode() {
      if(!is_admin()) {
      ob_start();
      $user = wp_get_current_user();
      if ( $user ) {
        $avatar = get_avatar_url($user->ID, ['size' => '600']); // spits out 600px square since user can scale smaller with page builder
        echo '<span class="lf-user-avatar"><img src="'. esc_url( $avatar) . '"></img></span>';
        $output = ob_get_contents();   
        ob_end_clean();   
        return $output;
      } 
  }
}



/**
   * Create Shortcode To Locate Automatic Click Of WooCommerce Checkout Button With Ajax Waiting Message
   *
   * @since 3.2
   *
   * @return void
   */

public function lf_layout_autoclick_shortcode() {

    add_action   ( 'lf_after_form',       array ($this, 'lf_output_autoclick_shortcode') );  

} 


/**
   * Outputs The Automatic Click Of WooCommerce Checkout Button With Ajax Waiting Message
   *
   * @since 3.2
   *
   * @return void
   */


public function lf_output_autoclick_shortcode() {
     ?>
<section id="lf-autoclick">
  <div id="lf-autoclick">
    <div class="lf-autoclick-waiting">
      <span class="lf-autoclick-title"><?php _e( 'One Moment While Your Order Is Processed', 'lf' ); ?></span>
      <div class="blobs-container">
          <div class="blob red"></div>
          <div class="blob orange"></div>
          <div class="blob yellow"></div>
          <div class="blob blue"></div>
          <div class="blob green"></div>
          <div class="blob purple"></div>
          <div class="blob"></div>
      </div>
    </div>
  </div>
</section>

      <script>
    jQuery("document").ready(function() {
        // first hide main form content
        jQuery('.woocommerce').hide();
        // wait two seconds then trigger checkout button
        setTimeout(function() {
            jQuery("#place_order").trigger('click');
        },2000);
        // after 5 seconds, if not directed to thank you, hide autoclick section again to view notices
        setTimeout(function() {
          jQuery('.woocommerce').show();
          jQuery('section#lf-autoclick').hide();
        },5000);
    });      
      </script>

      <?php
}


// since 1.1.4
// adds script to lf_content hook on custom WC template to checkout WC with a button with #lf-checkout-button associated
public function lf_layout_checkout_button_shortcode() {
    ob_start();
      ?>
      <style>button#place_order{display:none!important;}#lf-checkout-button {cursor: pointer;}#payment div.form-row {padding: 0!important;}</style>
      <script>
      jQuery(window).load(function() {  
        jQuery("#lf-checkout-button").click(function(){
        jQuery("#place_order").submit(); 
        });
      });
      </script>
      <?php
      $output = ob_get_contents();   
      ob_end_clean();   
      return $output;
}

// since 3.4.8
// generates order subtotal shortcode (auto updates with ajax)
public function lf_layout_subtotal_shortcode() {
      ob_start();
      ?>
      <style>tfoot .cart-subtotal{display:none!important;}</style>
      <span id="lf-subtotal"></span>
      <?php
      $output = ob_get_contents();   
      ob_end_clean();   
      return $output;
}

// since 3.4.8
// generates order total shortcode (auto updates with ajax)
public function lf_layout_total_shortcode() {
      ob_start();
      ?>
      <style>tfoot .order-total{display:none!important;}</style>
      <span id="lf-total"></span>
      <?php
      $output = ob_get_contents();   
      ob_end_clean();   
      return $output;
}

// since 3.4.8
// generates account field shortcode
public function lf_layout_account_shortcode() {
       ob_start();
       ?>
       <span id="lf-account"></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}

// since 3.4.8
// generates billing field shortcode
public function lf_layout_billing_shortcode() {
       ob_start();
       ?>
       <span id="lf-billing"></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}


// since 3.4.8
// generates shipping fields shortcode
public function lf_layout_shipping_shortcode() {
      ob_start();
       ?>
        <span id="lf-shipping"></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}


// since 3.4.8
// generates additional field shortcode
public function lf_layout_additional_shortcode() {
      ob_start();
       ?>
        <span id="lf-additional"></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}

// since 3.4.8
// generates total order review body shortcode (line items)
public function lf_layout_review_shortcode() {
      ob_start();
       ?>
        <span id="lf-review"></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}

// since 3.4.8
// generates WC coupon shortcode with wrapper (1.0.15)
public function lf_layout_wccoupon_shortcode() {
      ob_start();
       ?>
        <span id="lf-wccoupon"></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}

// since 3.4.8
// generates WC notices shortcode with wrapper
// adds new location for cart errors since we redirect carts to checkout pages (since 3.0.0)
public function lf_layout_notices_shortcode() {
  if( ! is_admin() ) { // 1.1.16 do not run on admin side
      ob_start();
       ?>
        <span id="lf-notices"><?php if ( function_exists( 'wc_print_notices ' ) ) { do_action('lf_notices'); } ?></span>
        <span id="lf-cart-errors"><?php do_action( 'woocommerce_cart_has_errors' ); ?></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
  }// end conditional check
}

// since 3.4.8
// generates WC checkout page login notice toggle shortcode with wrapper
public function lf_layout_login_shortcode($checkout) {
      ob_start();
       ?>
        <span id="lf-login"></span>
       <?php
       $output = ob_get_contents();
       ob_end_clean();
       return $output;
}

// since 3.4.8
// generates payment shortcode
public function lf_layout_payment_shortcode() {
      ob_start();
       ?>
        <span id="lf-payment"></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}

// sinc 3.4.8
// generates total shipping shortcode
public function lf_layout_total_shipping_shortcode() {
      ob_start();
      ?>
      <style>tfoot .woocommerce-shipping-totals{display:none!important;}</style>
      <span id="lf-total-shipping"></span>
      <?php
      $output = ob_get_contents();   
      ob_end_clean();   
      return $output;
}

// since 3.4.8
// generates tax total shortcode (3.1)
public function lf_layout_tax_total_shortcode() {
      ob_start();
      ?>
      <span id="lf-tax-total"></span>
      <?php
      $output = ob_get_contents();   
      ob_end_clean();   
      return $output;
}

// since 3.4.8
// generates cart discount shortcode (1.1.15)
public function lf_layout_cart_discount_shortcode() {
      ob_start();
      ?>
      <span id="lf-cart-discount"></span>
      <?php
      $output = ob_get_contents();   
      ob_end_clean();   
      return $output;
}

// since 3.4.8
// save stripe css info at WC checkout and hides option box (2.1.8)
public function lf_layout_save_stripe_cc() {
      ob_start();
      ?>
      <style>p.form-row.woocommerce-SavedPaymentMethods-saveNew {display: none!important;}</style>
      <script>
      jQuery( document ).ready(function() {
          jQuery('#wc-stripe-new-payment-method').prop('checked', true);
      });
      </script>
      <span id="lf-save-stripe-cc"></span>
      <?php
      $output = ob_get_contents();   
      ob_end_clean();   
      return $output;
}

// since 3.5.1
// save square css info at WC checkout and hides option box (3.2.9)
public function lf_layout_save_square_cc() {
      ob_start();
      ?>
      <style>#wc-square-credit-card-tokenize-payment-method,label[for=wc-square-credit-card-tokenize-payment-method]{display: none!important;}</style>
      <script>
      jQuery( document ).ready(function() {
          jQuery('#wc-square-credit-card-tokenize-payment-method').prop('checked', true);
      });
      </script>
      <span id="lf-save-square-cc"></span>
      <?php
      $output = ob_get_contents();   
      ob_end_clean();   
      return $output;
}

// since 3.5.3
// generates WC product meta shortcode with wrapper
public function lf_layout_product_meta_shortcode() {
      ob_start();
       ?>
        <span id="lf-product-meta"></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}

// since 3.5.3
// generates WC product first payment shortcode with wrapper
public function lf_layout_product_firstpayment_shortcode() {
      ob_start();
       ?>
        <span id="lf-product-firstpayment"></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}


// since 3.5.3
// generates WC product related products shortcode with wrapper
public function lf_layout_product_related_shortcode() {
      ob_start();
       ?>
        <span id="lf-product-related"></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}

// since 3.5.3
// generates WC product short description shortcode with wrapper
public function lf_layout_product_description_shortcode() {
      ob_start();
       ?>
        <span id="lf-product-description"></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}

// since 3.5.3
// generates WC product price shortcode with wrapper
public function lf_layout_product_price_shortcode() {
      ob_start();
       ?>
        <span id="lf-product-price"></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}

// since 3.5.3
// generates WC product title shortcode with wrapper
public function lf_layout_product_title_shortcode() {
      ob_start();
       ?>
        <span id="lf-product-title"></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}

// since 3.5.3
// generates WC product meta shortcode with wrapper
public function lf_layout_product_breadcrumb_shortcode() {
      ob_start();
       ?>
        <span id="lf-product-breadcrumb"></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}

// since 3.5.3
// generates WC product tabs shortcode with wrapper
public function lf_layout_product_tabs_shortcode() {
      ob_start();
       ?>
        <span id="lf-product-tabs"></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}

// since 3.5.3
// generates WC product images shortcode with wrapper
public function lf_layout_product_images_shortcode() {
      ob_start();
       ?>
         <div id="lf-product-images"></div>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}

// since 3.5.3
// generates WC product add to cart form shortcode with wrapper
public function lf_layout_product_cart_shortcode() {
      ob_start();
       ?>
        <span id="lf-product-add-to-cart"></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}

// kadence theme only
// since 3.5.3
// generates WC product extras shortcode (Kadence theme) with wrapper
public function lf_layout_product_extras_shortcode() {
      ob_start();
       ?>
        <span id="lf-product-extras"></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}

// kadence theme only
// since 3.5.3
// generates WC product payments shortcode (Kadence theme) with wrapper
public function lf_layout_product_payments_shortcode() {
      ob_start();
       ?>
        <span id="lf-product-payments"></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}

// kadence theme only
// since 3.5.3
// generates WC product breadcrumbs shortcode (Kadence theme) with wrapper
public function lf_layout_product_breadcrumbs_shortcode() {
      ob_start();
       ?>
        <span id="lf-product-breadcrumbs"></span>
       <?php
       $output = ob_get_contents();   
       ob_end_clean();   
       return $output;
}


/**
   * Introduces customer loyalty message for 5 purchases (translatable)
   *
   * @since 3.4.8
   *
   * @return void
   */

public function lf_loyalty($atts) {
      ob_start();
      ?>
      <span id="lf-loyalty"></span>
      <?php
    // Get all customer orders
    $customer_orders = get_posts( array(
        'numberposts' => -1,
        'meta_key'    => '_customer_user',
        'meta_value'  => get_current_user_id(),
        'post_type'   => wc_get_order_types(),
        'post_status' => array_keys( wc_get_order_statuses() ),
    ) );
    
    $customer = wp_get_current_user();
    
    // Order count for a "loyal" customer (set to 5 by default)
    $loyal_count = 5;
    
    // Text for our "thanks for loyalty" message
    $notice_text = sprintf( 'Hey %1$s &#x1f600; You\'ve completed more than %2$s checkouts. Thanks for your loyalty!', $customer->display_name, $loyal_count );
    
    // Display our notice if the customer has at least 5 orders
    if ( count( $customer_orders ) >= $loyal_count ) {
        //wc_print_notice( $notice_text, 'notice' );
        echo __('<span class="lf-loyalty">'.$notice_text.'</span>', 'notice' );
    }

      $output = ob_get_contents();   
      ob_end_clean();   
      return $output;
}

/**
   * Introduces Custom WooCommerce Checkout Template To Add Necessary Hooks and Wrappers
   *
   * @since 1.0.11
   *
   * @return void
   */

// **Takes priority over cf-custom-templates plugin for any WC templates
public function lf_layout_wc_templates( $template, $template_name, $template_path ) {
  $template_directory = trailingslashit( plugin_dir_path( __FILE__ ) ) . '../woocommerce/';
  $path = $template_directory . $template_name;
  return file_exists( $path ) ? $path : $template;
}



/**
   * Adds LaunchFlows Shortcode Listbox To TinyMCE Editor (in WP and Elementor)
   *
   * @since 1.0.14
   *
   * @return void
   */

public function lf_tiny_mce() {
    global $typenow;
    // check user permissions
    if ( !current_user_can('edit_posts') || !current_user_can('edit_pages') ) {
    return;
    }
    // verify the post type
    if( ! in_array( $typenow, array( 'post', 'page', 'product', 'cartflows_step', 'et_pb_layout' ) ) )
        return;
    // check if WYSIWYG is enabled
    if ( get_user_option('rich_editing') == 'true') {
        add_filter('mce_external_plugins', array($this, 'lf_add_tinymce_plugin'), 999 ); //999 priority to override Elementor Filter
        add_filter('mce_buttons', array($this, 'lf_register_my_tc_button'), 999 ); //999 priority to override Elementor Filter
    }
}

public function lf_add_tinymce_plugin($plugin_array) {
    $plugin_array['lf_tiny_mce'] = plugin_dir_url( __FILE__ ) . '../assets/js/lf_tiny_mce.js'; // tiny_mce custom shortcode plugin
    return $plugin_array;
}

public function lf_register_my_tc_button($buttons) {
   array_push($buttons, 'lf_tiny_mce');
   return $buttons;
}



 /**
   * Force payment methods to be displayed even for free checkouts when shortcode or widget applied
   * //stackoverflow.com/questions/57963173/disable-cart-needs-payment-for-a-specific-coupon-code-in-woocommerce
   * @since 2.1.2
   * @access public
   */

public function lf_layout_display_payment_methods_shortcode() {
  ob_start();

  add_filter( 'woocommerce_cart_needs_payment', '__return_true' );

  $output = ob_get_contents();   
  ob_end_clean();   
  return $output;
}




// save
} // instantiates class
new LaunchFlowsCore;