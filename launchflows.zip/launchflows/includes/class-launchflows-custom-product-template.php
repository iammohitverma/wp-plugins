<?php

class LFProductTemplate {

	/**
	 * Method to kickstart the code.
	 *
	 * @return void
	 */
	public static function start(){
		new LFProductTemplate;
	}

	/**
	 * Adds all necessary action hooks
	 */
	private function __construct(){
		add_action('woocommerce_process_product_meta', array($this, 'saveProductGeneralTabField'));
	}

	/**
	 * Saves the checkbox selection state ("yes" by default)
	 */
	public function saveProductGeneralTabField( $id ){

    // Saving "Conditions" field key/value
    $posted_field_value = $_POST['_lf_custom_product_template_field'];
    if( ! empty( $posted_field_value ) ) {
  
        update_post_meta( $id, '_lf_custom_product_template_field', esc_attr( $posted_field_value ) );

     }
	}


} // end class wrapper

/**
 * Finally, start the class
 */

LFProductTemplate::start();