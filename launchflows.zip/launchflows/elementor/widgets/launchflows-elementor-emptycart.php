<?php
namespace LaunchFlowsElementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * LaunchFlows Elementor
 *
 * Elementor widget for LaunchFlows
 *
 * @since 1.0.0
 */
class LaunchFlowsElementorEmptycart extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'lf-emptycart';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'LaunchFlows Emptycart', 'lf' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-redo';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.2.2
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'launchflows'];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'lf' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 3.2.2
	 *
	 * @access protected
	 */

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'lf' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);


			$this->add_control(
				'content',
				[
					'label' => __( 'Select Component To Add:', 'lf' ),
					'type' => Controls_Manager::HIDDEN,
					'default' => '[lf-emptycart]',
				]

			);		


			$this->add_control(
				'new_title',
				[
					'label' => __( 'Add New Title:', 'lf' ),
					'type' => Controls_Manager::TEXT,
					'input_type' => 'text',
					'placeholder' => __( 'My Custom Title', 'lf' ),	
				]
			);

		$this->end_controls_section();


		// title style
		$this->start_controls_section(
				'title',
				[
					'label' => __( 'New Title', 'lf' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				]
			);


			$this->start_controls_tabs(
					'style_tabs_title'
				);

				// normal tab
				$this->start_controls_tab(
						'style_normal_tab_title',
						[
							'label' => __( 'Normal', 'lf' ),
						]
					);

					// title - normal tab
					$this->add_group_control(
						\Elementor\Group_Control_Typography::get_type(),
						[
							'name'					=> 'title_typography',
							'label'					=> __( 'Typography', 'lf' ),
							'selector'				=> '{{WRAPPER}} .new-title'
						]
					);
					$this->add_control(
						'title_text_color',
						[
							'label' => __( 'Text Color', 'lf' ),
							'type' => Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .new-title' => 'color: {{VALUE}}',
							],
						]
					);
					$this->add_control(
						'title_background_color',
						[
							'label' => __( 'Background Color', 'lf' ),
							'type' => Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .new-title' => 'background-color: {{VALUE}};',
								'{{WRAPPER}} .new-title::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
							],
						]
					);

					$this->add_responsive_control(
						'title_margin',
						[
							'label' => __( 'Margin', 'lf' ),
							'type' => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'allowed_dimensions' => 'vertical',
							'selectors' => [
								'{{WRAPPER}} .new-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_responsive_control(
						'title_padding',
						[
							'label' => __( 'Padding', 'lf' ),
							'type' => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors' => [
								'{{WRAPPER}} .new-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_control(
						'hr_title_normal',
						[
							'type' => \Elementor\Controls_Manager::DIVIDER,
						]
					);	
					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'title_border',
							'label' => __( 'Border', 'lf' ),
							'selector' => '{{WRAPPER}} .new-title',
						]
					);
					$this->add_responsive_control(
						'title_border_radius',
						[
							'label' => __( 'Border Radius', 'lf' ),
							'type' => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%' ],
							'selectors' => [
								'{{WRAPPER}} .new-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);	

					$this->add_control(
						'hr_title_normal_after_border',
						[
							'type' => \Elementor\Controls_Manager::DIVIDER,
						]
					);	

				// end normal
				$this->end_controls_tab();


				// hover tab
				$this->start_controls_tab(
					'style_hover_tab_title',
					[
						'label' => __( 'Hover', 'lf' ),
					]
				);

					$this->add_group_control(
						Group_Control_Typography::get_type(),
						[
							'name'					=> 'title_typography_hover',
							'label'					=> __( 'Typography', 'lf' ),
							'selector'				=> '{{WRAPPER}} .lf-emptycart h3.new-title'
						]
					);
					
					$this->add_control(
						'title_text_color_hover',
						[
							'label' => __( 'Text Color', 'lf' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .new-title:hover' => 'color: {{VALUE}}',
							],
						]
					);
					$this->add_control(
						'title_background_color_hover',
						[
							'label' => __( 'Background Color', 'lf' ),
							'type' => Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .new-title:hover' => 'background-color: {{VALUE}};',
								'{{WRAPPER}} .new-title:hover::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
							],
						]
					);
					$this->add_control(
						'hr_title_hover',
						[
							'type' => \Elementor\Controls_Manager::DIVIDER,
						]
					);					
					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'title_border_hover',
							'label' => __( 'Border', 'lf' ),
							'selector' => '{{WRAPPER}} .new-title:hover',
						]
					);

					$this->add_responsive_control(
						'title_border_radius_hover',
						[
							'label' => __( 'Border Radius', 'lf' ),
							'type' => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%' ],
							'selectors' => [
								'{{WRAPPER}} .new-title:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);	
		
				// end hover
				$this->end_controls_tab();

			// end tabs
			$this->end_controls_tabs();

		// end title section
		$this->end_controls_section();

		// button
		$this->start_controls_section(
					'emptycart_button',
					[
						'label' => __( 'Button', 'lf' ),
						'tab'   => Controls_Manager::TAB_STYLE,
					]
				);


			$this->start_controls_tabs(
					'style_tabs_emptycart'
				);

				$this->start_controls_tab(
					'style_normal_tab_emptycart',
					[
						'label' => __( 'Normal', 'lf' ),
					]
				);

						// emptycart - normal tab
						$this->add_group_control(
							\Elementor\Group_Control_Typography::get_type(),
							[
								'name'					=> 'emptycart_typography',
								'label'					=> __( 'Typography', 'lf' ),
								'selector'				=> '{{WRAPPER}} .lf-emptycart .button'
							]
						);
						$this->add_control(
							'emptycart_text_color',
							[
								'label' => __( 'Text Color', 'lf' ),
								'type' => Controls_Manager::COLOR,
								'selectors' => [
									'{{WRAPPER}} .lf-emptycart .button' => 'color: {{VALUE}}',
								],
							]
						);
						$this->add_control(
							'emptycart_background_color',
							[
								'label' => __( 'Background Color', 'lf' ),
								'type' => Controls_Manager::COLOR,
								'selectors' => [
									'{{WRAPPER}} .lf-emptycart .button' => 'background-color: {{VALUE}};',
									'{{WRAPPER}} .lf-emptycart .button::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
								],
							]
						);
						$this->add_responsive_control(
							'align',
							[
								'label' => __( 'Alignment', 'lf' ),
								'type' => Controls_Manager::CHOOSE,
								'options' => [
									'left'    => [
										'title' => __( 'Left', 'lf' ),
										'icon' => 'fa fa-align-left',
									],
									'center' => [
										'title' => __( 'Center', 'lf' ),
										'icon' => 'fa fa-align-center',
									],
									'right' => [
										'title' => __( 'Right', 'lf' ),
										'icon' => 'fa fa-align-right',
									],
								],
								'prefix_class' => 'lf-emptycart-widget%s-align-',
								'default' => 'center',
								'selectors' => [
									'{{WRAPPER}} #lf-emptycart' => 'text-align: {{VALUE}}',
									'{{WRAPPER}} #lf-emptycart .lf-emptycart .button' => 'text-align: center',

								],
							]
						);
						$this->add_responsive_control(
							'emptycart_margin',
							[
								'label' => __( 'Margin', 'lf' ),
								'type' => Controls_Manager::DIMENSIONS,
								'size_units' => [ 'px', '%', 'em' ],
								'selectors' => [
									'{{WRAPPER}} .lf-emptycart .button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
								],
							]
						);
						$this->add_responsive_control(
							'emptycart_padding',
							[
								'label' => __( 'Padding', 'lf' ),
								'type' => Controls_Manager::DIMENSIONS,
								'size_units' => [ 'px', '%', 'em' ],
								'selectors' => [
									'{{WRAPPER}} .lf-emptycart .button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
								],
							]
						);

						$this->add_responsive_control(
							'emptycart_max_width',
							[
								'label' => __( 'Max Width', 'lf' ),
								'type' => Controls_Manager::SLIDER,
								'size_units' => [ 'px', '%' ],
								'range' => [
									'px' => [
										'min' => 0,
										'max' => 1400,
										'step' => 5,
									],
									'%' => [
										'min' => 0,
										'max' => 100,
									],
								],
								'default' => [
									'unit' => 'px',
									'size' => 200,
								],
								'selectors' => [
									'{{WRAPPER}} .lf-emptycart .button' => 'width: {{SIZE}}{{UNIT}};',
								],
							]
						);

						$this->add_control(
							'hr_emptycart_normal',
							[
								'type' => \Elementor\Controls_Manager::DIVIDER,
							]
						);	
						$this->add_group_control(
							\Elementor\Group_Control_Border::get_type(),
							[
								'name' => 'emptycart_border',
								'label' => __( 'Border', 'lf' ),
								'selector' => '{{WRAPPER}} .lf-emptycart .button',
							]
						);
						$this->add_responsive_control(
							'emptycart_border_radius',
							[
								'label' => __( 'Border Radius', 'lf' ),
								'type' => Controls_Manager::DIMENSIONS,
								'size_units' => [ 'px', '%' ],
								'selectors' => [
									'{{WRAPPER}} .lf-emptycart .button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
								],
							]
						);	

						$this->add_control(
							'hr_emptycart_normal_after_radius',
							[
								'type' => \Elementor\Controls_Manager::DIVIDER,
							]
						);	

				$this->end_controls_tab();


				// emptycart - hover tab
				$this->start_controls_tab(
					'style_hover_tab_emptycart',
					[
						'label' => __( 'Hover', 'lf' ),
					]
				);

						$this->add_group_control(
							Group_Control_Typography::get_type(),
							[
								'name'					=> 'emptycart_typography_hover',
								'label'					=> __( 'Typography', 'lf' ),
								'selector'				=> '{{WRAPPER}} .lf-emptycart .button'
							]
						);
						
						$this->add_control(
							'emptycart_text_color_hover',
							[
								'label' => __( 'Text Color', 'lf' ),
								'type' => \Elementor\Controls_Manager::COLOR,
								'selectors' => [
									'{{WRAPPER}} .lf-emptycart .button:hover' => 'color: {{VALUE}}',
								],
							]
						);
						$this->add_control(
							'emptycart_background_color_hover',
							[
								'label' => __( 'Background Color', 'lf' ),
								'type' => Controls_Manager::COLOR,
								'selectors' => [
									'{{WRAPPER}} .lf-emptycart .button:hover' => 'background-color: {{VALUE}};',
									'{{WRAPPER}} .lf-emptycart .button:hover::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
								],
							]
						);
						$this->add_control(
							'hr_emptycart_hover',
							[
								'type' => \Elementor\Controls_Manager::DIVIDER,
							]
						);					
						$this->add_group_control(
							\Elementor\Group_Control_Border::get_type(),
							[
								'name' => 'emptycart_border_hover',
								'label' => __( 'Border', 'lf' ),
								'selector' => '{{WRAPPER}} .lf-emptycart .button:hover',
							]
						);

						$this->add_responsive_control(
							'emptycart_border_radius_hover',
							[
								'label' => __( 'Border Radius', 'lf' ),
								'type' => Controls_Manager::DIMENSIONS,
								'size_units' => [ 'px', '%' ],
								'selectors' => [
									'{{WRAPPER}} .lf-emptycart .button:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
								],
							]
						);	


				$this->end_controls_tab();

			$this->end_controls_tabs();

		$this->end_controls_section();
		/* emptycart end */


	} // end method



/**
	 * Render CSS Style
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */

   public function __construct($data = [], $args = null) {
      parent::__construct($data, $args);
      wp_register_style( 'lf-elementor', LF_DIR_URL . 'elementor/css/launchflows-elementor.css', false, '1.0.0');
   }

  public function get_style_depends() {
     return [ 'lf-elementor' ];
  }

/**
	 * Render shortcode widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 3.2.2
	 * @access protected
	 */

	protected function render() {

		$settings = $this->get_settings_for_display();


		$content = $this->get_settings( 'content' );


		$hide_content = $this->get_settings( 'hide_content' );
	

		$new_title = $this->get_settings( 'new_title' );

		// trim brackets from shortcode for css and string generation
		$css = trim($content, "[]");


		// new title
		if ( $new_title !=='' ) {
		
			$new_title = '<h3 class="new-title">'. $settings['new_title'] . '</h3>';
		
		} else {

			$new_title = '';

		}	

		$content = '['.$css .' ]';

		// output shortcode string
		$shortcode = do_shortcode( shortcode_unautop( $content ) );
	
		// For Testing Shortcode Output
		//echo $content;	

		// hide content
		if ('yes' === $hide_content ) {

			if(is_admin()) {

			echo '<div class="content-hidden">';

			echo '<center><h3>'. __('HIDDEN ON FRONT','lf').'</h3></center>';

			echo $shortcode;

			echo '</div>';
			
			?>
			<!--- disable button click on admin --->
			<script>jQuery('#lf-emptycart').prop('disabled', true);</script>
			<?php 

			} // end admin check

			// display then hide on front
			echo '<div class="lf-hide">';
			echo $shortcode;
			echo '</div>';

		} else {

		?>

				<div class="lf-shortcode" >

				<style><?php echo $hide_title; ?></style>

				<?php echo $new_title; ?>

				<?php echo $shortcode; ?>

				</div>

		<?php	

		} // end hide content check
	    

	} // end render


} //end	widget