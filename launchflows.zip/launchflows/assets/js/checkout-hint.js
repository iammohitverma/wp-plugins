(function($, w){
	/**
	 * The object that encapsulates all plugin related data and functions
	 *
	 * @type {{textInputID: string, hiddenInputID: string}}
	 */
	var LFCustomCheckoutPage = {
		textInputID: '#_lf_checkout_field',
		hiddenInputID: '#_lf_checkout_field_id',

		autoCompleteOptions: {
			autoFocus: true,
			minLength: 2,

			/**
			 * Performs the AJAX request to the WP ajax endpoint to get the hints
			 *
			 * @param request
			 * @param response
			 */
			source: function(request, response){
				$.ajax({
					url: 'admin-ajax.php',
					data: {
						action: 'wc-checkout-hint',
						search: request.term
					},
					method: "post",
			        dataType: "json",
					success: function(data){
						if(typeof data.success !== "undefined"){
							response(data.data);
						} else {
							response({});
						}
					},
					error: function(){
						response({});
					}
		        });
			},

			/**
			 * Select callback for setting the value into the right input field (the hidden one)
			 *
			 * @param event
			 * @param ui
			 */
			select: function(event, ui){
				var item = ui.item;

				// The display field
				$(LFCustomCheckoutPage.textInputID).val(item.label);

				// The hidden field
				$(LFCustomCheckoutPage.hiddenInputID).val(item.value);

				event.preventDefault();
			},

			/**
			 * Select callback for setting the value into the right input field (the hidden one)
			 *
			 * @param event
			 * @param ui
			 */
			focus: function(event, ui){
				event.preventDefault();
			}
		}
	};

	/**
	 * Empties the value of the hidden input field (that is only filled when used with autocomplete)
	 */
	LFCustomCheckoutPage.emptyHiddenOnChange = function(){
		var trimmedLabelFieldValue = $(LFCustomCheckoutPage.textInputID).val().trim();

		if(trimmedLabelFieldValue.indexOf('http') === 0 || trimmedLabelFieldValue === ""){
			$(LFCustomCheckoutPage.hiddenInputID).val('');
		}
	};

	/**
	 * Function that sets up all necessary hooks
	 */
	LFCustomCheckoutPage.init = function(){
		$(LFCustomCheckoutPage.textInputID)
			.change(LFCustomCheckoutPage.emptyHiddenOnChange)
			.autocomplete(LFCustomCheckoutPage.autoCompleteOptions);
	};

	// Init onload
	$(function(){
		LFCustomCheckoutPage.init();
	});
})(window.jQuery, window);