<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

/**
   * Sets the plugin as location for WooCommerce template files as required
   *
   * @since 3.5.3
   *
   * @return void
   */

// Load Any WC Template Or Template Part From Active Theme Or Plugin Folder
// wordpress.org/support/topic/filter-to-add-a-child-plugin-to-change-the-plugins-template-files-2/

function lf_load_wc_template_file( $template_name ) {
    // Check theme folder first - e.g. wp-content/themes/your-theme/woocommerce.
    $file = get_stylesheet_directory() . '/woocommerce/' . $template_name;
    if ( @file_exists( $file ) ) {
        return $file;
    }

    // Now check plugin folder - e.g. wp-content/plugins/launchflows/woocommerce.
    //$file = 'wp-content/plugins/launchflows' . '/woocommerce/' . $template_name;
    $file = trailingslashit( plugin_dir_path( __DIR__ ) ) . '/woocommerce/' . $template_name;
    if ( @file_exists( $file ) ) {
        return $file;
    }
}

add_filter( 'woocommerce_template_loader_files', function( $templates, $template_name ){
    // Capture/cache the $template_name which is a file name like single-product.php
    wp_cache_set( 'lf_wc_main_template', $template_name ); // cache the template name
    return $templates;
}, 10, 2 );

add_filter( 'template_include', function( $template ){
    if ( $template_name = wp_cache_get( 'lf_wc_main_template' ) ) {
        wp_cache_delete( 'lf_wc_main_template' ); // delete the cache
        if ( $file = lf_load_wc_template_file( $template_name ) ) {
            return $file;
        }
    }
    return $template;
}, 11 );

add_filter( 'wc_get_template_part', function( $template, $slug, $name ){
    $file = lf_load_wc_template_file( "{$slug}-{$name}.php" );
    return $file ? $file : $template;
}, 10, 3 );

add_filter( 'woocommerce_locate_template', function( $template, $template_name ){
    $file = lf_load_wc_template_file( $template_name );
    return $file ? $file : $template;
}, 10, 2 );

add_filter( 'wc_get_template', function( $template, $template_name ){
    $file = lf_load_wc_template_file( $template_name );
    return $file ? $file : $template;
}, 10, 2 );



/**
   * Sets the correct wc variables required for lf checkout pages
   *
   * @since 3.2.1
   *
   * @return void
   * //powderkegwebdesign.com/woocommerce-custom-single-page-checkout/
   */

add_action('wp', 'lf_wc_is_checkout');

function lf_wc_is_checkout() {

  if ( is_page_template( array( 'launchflows-checkout', 'launchflows-canvas' ) ) ) { 
       
        // woocommerce cart (if we want to add variables for cart use later)       
        //if(!defined('woocommerce_cart')) { define('woocommerce_cart', true); } 
       
        // woocommerce checkout
        add_filter('woocommerce_is_checkout', '__return_true');
  
  }

}


/**
   * Temporary fix to suppress Gutenberg false notices
   *
   * @since 3.2
   *
   * @return void
   */

add_action('admin_head', 'lf_suppress_gutenberg');
function lf_suppress_gutenberg() {
  echo '<style>
 /* Suppress dismissible errors from Gutenberg */
.block-editor-page .components-notice.is-error {
    display: none!important;
}
  </style>';
}


/**
   * Filter Single Product Add To Cart Text
   * //metorik.com/blog/change-the-add-to-cart-text-in-woocommerce
   *
   * @since 4.0.8
   *
   * @return void
   */

  add_filter( 'woocommerce_product_single_add_to_cart_text', 'lf_single_product_add_to_cart_message' ); 

  function lf_single_product_add_to_cart_message($default) {

      // if no custom button text per page, use global, and if no global, default to "Place Order"
      $options = get_option( 'lf_settings' );

      if( isset($options['lf_text_field_2']) && !empty($options['lf_text_field_2']) ) {     

      return $options['lf_text_field_2']; // applies new text from plugin admin panel

      } // else

      return $default; // default button text to use on all other product

      }

/**
   * Filter All Other Than Single Product Add To Cart Text
   * //metorik.com/blog/change-the-add-to-cart-text-in-woocommerce
   *
   * @since 4.0.8
   *
   * @return void
   */

  add_filter( 'woocommerce_product_add_to_cart_text', 'lf_other_product_add_to_cart_message' ); 

  function lf_other_product_add_to_cart_message($default) {

      // if no custom button text per page, use global, and if no global, default to "Place Order"
      $options = get_option( 'lf_settings' );

      if( isset($options['lf_text_field_3']) && !empty($options['lf_text_field_3']) ) {     

      return $options['lf_text_field_3']; // applies new text from plugin admin panel

      } // else

      return $default; // default button text to use on all other product

      }


/**
     * Hides the "product added to cart" message from all checkouts
     *
     * @since 1.0.0
     *
     * @return void
     */

function lf_woo_custom_add_to_cart( $cart_item_data ) {
    global $woocommerce;
    $woocommerce->cart->empty_cart();

    // Do nothing with the data and return
    return $cart_item_data;
}


/**
     * Disable Customer Order Emails For Free Orders
     *
     * @since 1.0.14
     *
     * @return void
     */

function lf_disable_free_order_email( $recipient, $order ) {

    // Bail on WC settings pages since the order object isn't yet set yet
    $page = $_GET['page'] = isset( $_GET['page'] ) ? $_GET['page'] : '';
    if ( 'wc-settings' === $page ) {
        return $recipient; 
    }
    
    // just in case it's a custom order
    if ( ! $order instanceof WC_Order ) {
        return $recipient; 
    }

    if( $order->get_total() == 0 ) $recipient = '';
    return $recipient;
}



/**
     * Hides Free Orders From My Account Endpoint
     *
     * @since 1.0.0
     *
     * @return void
     */

function lf_hide_free_orders_my_account( $array ) { 
    // make filter magic happen here... 
  $array = array(
    'customer' => get_current_user_id(),
    'paginate' => true,
    'meta_key' => '_order_total',                  
    'meta_value' => '0.00', // amount is zero
    'meta_compare' => '>', // show if greater than 
  );
    // then return the array for display
    return $array; 
} 


/**
     * Hides Free Orders Admin In Edit Orders Page
     *
     * @since 1.0.4
     *
     * @return void
     */


    function lf_restrict_orders() {
    if ( is_admin() ) {
        global $typenow;
        if ( 'shop_order' != $typenow ) {
            return;
        }
        ?>
        <select name='lf_order_view' id='dropdown_lf_order_view'>
            <option <?php
                if ( isset( $_GET['lf_order_view'] ) && $_GET['lf_order_view'] ) {
                    selected( 'all', $_GET['lf_order_view'] );
                }
            ?> value="all"><?php esc_html_e( 'Show Free Orders', 'lf-hide-zero-orders' ); ?></option>
            <option <?php
                    if ( isset( $_GET['lf_order_view'] ) && $_GET['lf_order_view'] ) {
                        selected( 'non-zero', $_GET['lf_order_view'] );
                }
            ?>value="non-zero"><?php esc_html_e( 'Hide Free Orders', 'lf-hide-zero-orders' ); ?></option>
        </select>
        <?php
    }
}


    function lf_orders_by_restrict_option( $vars ) {
        global $typenow;
        $key = 'post__not_in';
        if ( 'shop_order' == $typenow && isset( $_GET['lf_order_view'] ) ) {
            if ( 'non-zero' == $_GET['lf_order_view'] ) {
                if ( ! empty( $key ) ) {
                    $vars[ $key ] = get_posts( array(
                        'posts_per_page' => -1,
                        'post_type'      => 'shop_order',
                        'post_status'    => 'any',
                        'fields'         => 'ids',
                        'orderby'        => 'date',
                        'order'          => 'DESC',
                        'meta_query'     => array(
                            array(
                                'key'     => '_order_total',
                                'value'   => '0.00',
                                'compare' => '=',
                            ),
                        ),
                    ) );
                }
            }
        }
        return $vars;
    }

/**
     * Solo Variations For lf-bump Widget
     *
     * @since 3.3.8
     *
     * @return void
     */
add_filter( 'woocommerce_add_to_cart_validation', 'lf_solo_variations', 10, 3 );

function lf_solo_variations( $passed, $product_id, $quantity) {

if (! is_admin() ) {    
global $woocommerce;

        // Iterating through each cart item
        foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item ){

          // for variable products get the parent id from product_id
          $parent_id  = wp_get_post_parent_id( $product_id );
         
          // if there is no parent id, then product id is used instead
          $product_id = $parent_id > 0 ? $parent_id : $product_id;

            if ( $cart_item['product_id'] === $product_id ) {

                // only remove cart item if product has one variation option selected
                if ( get_post_meta( $product_id, 'onevariation_input', true) === 'yes') {

                    // Removing the cart item
                    WC()->cart->remove_cart_item($cart_item_key);

                    // We stop the loop
                    break;

                }

            }
        }
        return $passed;

 } // end admin check     
}



/**
     * Solo Checkout - Removes All Products From Checkout If Certain Product Is Added
     *
     * @since 1.0.20
     *
     * @return void
     */

add_filter( 'woocommerce_add_to_cart_validation', 'lf_solocheckout', 10, 2 ); 
function lf_solocheckout( $cart_item_data, $product_id ) {
if (! is_admin() ) {    
global $woocommerce;

// if a solo product is sent to cart
if ( get_post_meta( $product_id, 'solocheckout_input', true) === 'yes') {
    // the solo product pushes out any other products in cart
    $woocommerce->cart->empty_cart(); // dump whatever is in cart
    return $cart_item_data; // return solo product to cart

} 
    // otherwise we know a non-solo product is being sent to cart
    // so check what is in cart to see if there are solo products to be pushed out
    $solocheckout_check = false;
    // flag is set to false before we loop through cart contents looking for solo
    foreach( WC()->cart->get_cart() as $cart_item ){
            $product_id = $cart_item['product_id'];

                if ( get_post_meta( $product_id, 'solocheckout_input', true) === 'yes') {
                    // if we find a solo product, change flag true
                        $solocheckout_check = true;
                        // then break because we only need one "true" to matter here
                        break;
                }
        }

    if ( $solocheckout_check ) {
        // now let's dump the solo product in the checkout            
        $woocommerce->cart->empty_cart();
        // and add in the new product(s)
        return $cart_item_data;

        } else {
        // if no solo was found, just add new product(s) to what was already in cart
        return $cart_item_data;
    }
  } // end admin check  
} // end function

/**
     * Hides any #checkout-offer sections if solo checkout product is in cart
     *
     * @since 2.0.6
     *
     * @return void
     */
add_action( 'woocommerce_before_checkout_form', 'lf_hide_checkout_offer', 10, 2 ); 
function lf_hide_checkout_offer() {
if (! is_admin() ) {    
global $woocommerce;
    // check what is in cart to see if there are solo products to be pushed out
    $solocheckout_check = false;
    // flag is set to false before we loop through cart contents looking for solo
    foreach( WC()->cart->get_cart() as $cart_item ){

            $product_id = $cart_item['product_id'];

                if ( get_post_meta( $product_id, 'solocheckout_input', true) === 'yes') {
        
                    // if we find a solo product, change flag true
                                $solocheckout_check = true;
        
                        // then break because we only need one "true" to matter here
                        break;
                }
        }

    if ( $solocheckout_check ) {
        // hide the #checkout-offer
        echo '<style>#checkout-offer{display:none!important};</style>';             
    }
  } // end admin check
} // end function



/**
     * Remove Related Products - Hides Related Products Panel On Any Single Product Page
     *
     * @since 3.0.2
     *
     * @return void
     */

function lf_removerelated($product_id) {
    global $product;
    $id = $product->get_id();
    if ( get_post_meta( $id, 'removerelated_input', true) === 'yes') {
        remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
    }
}
add_action( 'woocommerce_after_single_product_summary', 'lf_removerelated' );


function removing_product_tabs($product_id){
    global $product;
    $id = $product->get_id();
    if ( get_post_meta( $id, 'removerelated_input', true) === 'yes') {
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );
    ?>
    <style>
      .product .wc-tabs {display: none!important;} 
      .product div#content { padding-top: 1%;}
      .product .woocommerce-tabs.wc-tabs-wrapper {display: none!important;}        
    </style>
    <?php

    }
}
add_action( 'woocommerce_after_single_product_summary', 'removing_product_tabs', 2 );

function removing_product_meta($product_id){
    global $product;
    $id = $product->get_id();
    if ( get_post_meta( $id, 'removerelated_input', true) === 'yes') {
    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
    ?>
    <style>.woocommerce-breadcrumb{display:none;}</style>
    <?php
    }
}
add_action( 'woocommerce_single_product_summary', 'removing_product_meta', 2 );


/**
     * Unset all error notices so they can be captured with lf-notices shortcode. 
     * Note: works with the custom checkout.js file for additional wrappers, adds notices back to lf_notices
     *
     * @since 2.0.1
     * @return void
     * //calebburks.com/conditionally-showhide-woocommerce-checkout-fields/
     *      
     */

add_action( 'init', 'lf_relocate_wc_notices' );
function lf_relocate_wc_notices(){
// first we remove all action locations for error notices

//  * below is list of available action locations for future development idea reference *
//  remove_action( 'woocommerce_cart_is_empty', 'woocommerce_output_all_notices', 5 );
//  remove_action( 'woocommerce_shortcode_before_product_cat_loop', 'woocommerce_output_all_notices', 10 );
//  remove_action( 'woocommerce_before_shop_loop', 'woocommerce_output_all_notices', 10 );
//  remove_action( 'woocommerce_before_single_product', 'woocommerce_output_all_notices', 10 );
//  remove_action( 'woocommerce_before_cart', 'woocommerce_output_all_notices', 10 );
//  remove_action( 'woocommerce_account_content', 'woocommerce_output_all_notices', 5 );
//  remove_action( 'woocommerce_before_customer_login_form', 'woocommerce_output_all_notices', 10 );
//  remove_action( 'woocommerce_before_lost_password_form', 'woocommerce_output_all_notices', 10 );
//  remove_action( 'woocommerce_before_reset_password_form', 'woocommerce_output_all_notices', 10 );
//  remove_action( 'before_woocommerce_pay', 'woocommerce_output_all_notices', 10 );


// remove notices actions from relevant hooks
    remove_action( 'woocommerce_before_checkout_form', 'woocommerce_output_all_notices', 10 );

// this is what works on checkout page    
    remove_action( 'woocommerce_before_checkout_form_cart_notices', 'woocommerce_output_all_notices', 10 ); 

// re-add the notices function on the checkout template to our custo hook lf_notices
    add_action( 'lf_notices', 'woocommerce_output_all_notices', 10 );

// hides all View cart notices (after product is added)
 // (3.5.3) moved to lf options page  add_filter( 'wc_add_to_cart_message_html', '__return_null' );

}


/**
     * Instant Product Checkout - Sets Up Product Page To Function As Checkout Page
     *
     * @since 3.5.3
     * @return void
     *      
     */

// (1) Add Checkout Flag (true) For Stripe Gateway To Activate on Product or if metabox checked
function lf_custom_checkout_wp() {
    global $post;
    if ( is_product() || get_post_meta($post->ID, '_lf_activate_checkout_checkbox', true) == true ) { 
    add_filter('woocommerce_is_checkout', '__return_true');
    }
}
add_action('wp', 'lf_custom_checkout_wp');



// (2) Enable Use Of Gutenberg With WC Product
function lf_activate_gutenberg_product( $can_edit, $post_type ) {
 if ( $post_type == 'product' ) {
        $can_edit = true;
    }
    return $can_edit;
}
add_filter( 'use_block_editor_for_post_type', 'lf_activate_gutenberg_product', 10, 2 );


// (3) Enable Gutenberg Taxonomy Fields For WooCommerce With Gutenberg
function lf_enable_taxonomy_rest( $args ) {
    $args['show_in_rest'] = true;
    return $args;
}
add_filter( 'woocommerce_taxonomy_args_product_cat', 'lf_enable_taxonomy_rest' );
add_filter( 'woocommerce_taxonomy_args_product_tag', 'lf_enable_taxonomy_rest' );


// (4) Remove Description Tab From Product So Content Is In Clear Content Below Product Div
function lf_remove_product_tabs( $tabs ) {
    global $post;
        if (get_post_meta( $post->ID, '_lf_custom_product_template_field', true ) != 'original') {
            unset( $tabs['description'] );      // Remove the Description tab because it outputs content from LF           
            }

        return $tabs;
}
add_filter( 'woocommerce_product_tabs', 'lf_remove_product_tabs', 98 );

// (5) Add Metabox And Product Catalogue Visibility Controls To Gutenberg Editor
function lf_register_catalog_meta_boxes() {
    global $current_screen;
    // Make sure Gutenberg is loaded before adding the metabox
    if ( method_exists( $current_screen, 'is_block_editor' ) && $current_screen->is_block_editor() ) {
        add_meta_box( 'catalog-visibility', __( 'Catalog visibility', 'textdomain' ), 'lf_product_data_visibility', 'product', 'side' );
    }
}
add_action( 'add_meta_boxes', 'lf_register_catalog_meta_boxes' );


function lf_product_data_visibility( $post ) {

    $thepostid          = $post->ID;
    $product_object     = $thepostid ? wc_get_product( $thepostid ) : new WC_Product();
    $current_visibility = $product_object->get_catalog_visibility();
    $current_featured   = wc_bool_to_string( $product_object->get_featured() );
    $visibility_options = wc_get_product_visibility_options();
    ?>
<div class="misc-pub-section" id="catalog-visibility">
    <?php esc_html_e( 'Catalog visibility:', 'woocommerce' ); ?>
    <strong id="catalog-visibility-display">
        <?php

        echo isset( $visibility_options[ $current_visibility ] ) ? esc_html( $visibility_options[ $current_visibility ] ) : esc_html( $current_visibility );

        if ( 'yes' === $current_featured ) {
            echo ', ' . esc_html__( 'Featured', 'woocommerce' );
        }
        ?>
    </strong>

    <a href="#catalog-visibility"
       class="edit-catalog-visibility hide-if-no-js"><?php esc_html_e( 'Edit', 'woocommerce' ); ?></a>

    <div id="catalog-visibility-select" class="hide-if-js">

        <input type="hidden" name="current_visibility" id="current_visibility"
               value="<?php echo esc_attr( $current_visibility ); ?>" />
        <input type="hidden" name="current_featured" id="current_featured"
               value="<?php echo esc_attr( $current_featured ); ?>" />

        <?php
        echo '<p>' . esc_html__( 'This setting determines which shop pages products will be listed on.', 'woocommerce' ) . '</p>';

        foreach ( $visibility_options as $name => $label ) {
            echo '<input type="radio" name="_visibility" id="_visibility_' . esc_attr( $name ) . '" value="' . esc_attr( $name ) . '" ' . checked( $current_visibility, $name, false ) . ' data-label="' . esc_attr( $label ) . '" /> <label for="_visibility_' . esc_attr( $name ) . '" class="selectit">' . esc_html( $label ) . '</label><br />';
        }

        echo '<br /><input type="checkbox" name="_featured" id="_featured" ' . checked( $current_featured, 'yes', false ) . ' /> <label for="_featured">' . esc_html__( 'This is a featured product', 'woocommerce' ) . '</label><br />';
        ?>
        <p>
            <a href="#catalog-visibility"
               class="save-post-visibility hide-if-no-js button"><?php esc_html_e( 'OK', 'woocommerce' ); ?></a>
            <a href="#catalog-visibility"
               class="cancel-post-visibility hide-if-no-js"><?php esc_html_e( 'Cancel', 'woocommerce' ); ?></a>
        </p>
    </div>
</div>
<?php
}

/**
     * Instant LeadMagnet - Hides All Extra Fields IF Any LeadMagnet Product In Checkout
     *
     * @since 1.1.15
     * @return void
     * //calebburks.com/conditionally-showhide-woocommerce-checkout-fields/
     *      
     */
function lf_leadmagnet_is_in_the_cart() {

    // set our flag to be false until we find a product that has the leadmagnet meta_box checked
    $leadmagnet_check = false;
            
        // check each cart item for our category to see if any product has "leadmagnet" option selected
        if( ! is_admin() ) { //conditional check so operation does not run on admin side

                // we must load cart on admin side with these includes and conditional to avoid cart object being "null"
                // coderoad.ru/63077103/WooCommerce-get_cart-%D0%BD%D0%B0-null
                include_once WC_ABSPATH . 'includes/wc-cart-functions.php';
                include_once WC_ABSPATH . 'includes/class-wc-cart.php';

                if ( is_null( WC()->cart ) ) {
                wc_load_cart();
                }


            foreach( WC()->cart->get_cart() as $cart_item ){
                    $product_id = $cart_item['product_id'];
                    // Gets the status of the checkbox for the current item (product)
                    $leadmagnet_input = get_post_meta( $product_id, 'leadmagnet_input', true );

                    // if a cart item is found with leadmagnet option checkbox set flag to true   
                    if ( get_post_meta( $product_id, 'leadmagnet_input', true) === 'yes') {
                        $leadmagnet_check = true;
                        // break because we only need one "true" to matter here
                        break;
                    }

            } // end foreach
        }
        
        // if a product in the cart has the leadmagnet checkbox 
        if ( $leadmagnet_check ) {
        
            // if cart needs payment, bail out and show regular checkout style
            if ( WC()->cart && WC()->cart->needs_payment() ) {
                return;
            } 

            // otherwise set flag for checkout field filter functions below
            return true;

        }
    
} // end lf_leadmagnet_is_in_the_cart


// adds inline style for leadmagnet
add_action('woocommerce_before_checkout_form', 'lf_leadmagnet_style');
if (! function_exists ('lf_leadmagnet_style') ) { // make pluggable
    function lf_leadmagnet_style() {
            if ( lf_leadmagnet_is_in_the_cart() ) { // check if leadmagnet in cart
        ?>
            <style id="lf-leadmagnet">
            .woocommerce-billing-fields h3 {
                display: none;
            }
            .woocommerce-shipping-fields {
                display: none;
            }
            .woocommerce-additional-fields {
                display: none;
            }
            #order_review {
                border-width: 0!important;
                width: 100%;
                float: none;
                margin-right: 0;
                padding: 0!important;
                clear: none;
            }
            #order_review table {
                display: none;
            }
            #order_review_heading {
                display: none;
            }
            #customer_details {
                width: 100%!important;
            }            
            #lf-form {
                margin: 5% auto;
                max-width: 800px;
                border: 2px solid #e2e2e2;
                padding: 0 2%;
                background: #fff;
                width: 90%;
            }

            #order_main_wrap {
                width: 100%!important;
                float: none!important;
            }

            #order_review_wrap {
                width: 100%!important;
                float: none!important;
            }
            .woocommerce form .form-row-first, 
            .woocommerce form .form-row-last, 
            .woocommerce-page form .form-row-first, 
            .woocommerce-page form .form-row-last {
                width: 49%!important;
            }
            p.form-row.validate-required.woocommerce-invalid.woocommerce-invalid-required-field {
                margin-left: 5px;
            }
            .woocommerce-privacy-policy-text p {
                margin-top: 0!important;
            }
            .woocommerce-terms-and-conditions-wrapper {
                margin-top: 0!important;
            }
            button#place_order {
                margin-top: 0!important;
            }                        
            </style>
        <?php
        } // end check for leadmagnet in cart
    } // end lf_leadmagnet_style
} // end pluggable


// hides coupon field and aditional info order notes
add_action( 'woocommerce_before_checkout_form', 'remove_checkout_coupon_form', 9 );
function remove_checkout_coupon_form(){
    if ( lf_leadmagnet_is_in_the_cart() ) {

            remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_coupon_form', 10 );

            // remove the "Additional Info" order notes
            add_filter( 'woocommerce_enable_order_notes_field', '__return_false' );    
    }
}

// unset billing fields
add_filter( 'woocommerce_checkout_fields' , 'lf_remove_checkout_fields' );
if (! function_exists ('lf_remove_checkout_fields') ) { // make pluggable
    function lf_remove_checkout_fields( $fields ) {
        if ( lf_leadmagnet_is_in_the_cart() ) {
            unset( $fields['billing']['billing_company'] );
            unset( $fields['billing']['billing_state'] );
            unset( $fields['billing']['billing_address_1'] );
            unset( $fields['billing']['billing_address_2'] );
            unset( $fields['billing']['billing_city'] );
            unset( $fields['billing']['billing_postcode'] );
            unset( $fields['billing']['billing_country'] );

            // remove shipping fields 
            unset($fields['shipping']['shipping_first_name']);    
            unset($fields['shipping']['shipping_last_name']);  
            unset($fields['shipping']['shipping_company']);
            unset($fields['shipping']['shipping_address_1']);
            unset($fields['shipping']['shipping_address_2']);
            unset($fields['shipping']['shipping_city']);
            unset($fields['shipping']['shipping_postcode']);
            unset($fields['shipping']['shipping_country']);
            unset($fields['shipping']['shipping_state']);
            
            // remove order comment fields
            unset($fields['order']['order_comments']);
            }

        return $fields;
    } // end lf_remove_checkout_fields
} // end pluggable


// non-required, reorder, add class
add_filter( 'woocommerce_billing_fields' , 'lf_remove_billing_fields' );
if (! function_exists ('lf_remove_billing_fields') ) { // make pluggable

    function lf_remove_billing_fields( $fields ) {
    
        if ( lf_leadmagnet_is_in_the_cart() ) {

            // reorder
            $fields['billing_company']['required'] = false;
            $fields['billing_phone']['required'] = false;
            $fields['billing_state']['required'] = false;
            $fields['billing_address_1']['required'] = false;
            $fields['billing_address_2']['required'] = false;
            $fields['billing_city']['required'] = false;
            $fields['billing_postcode']['required'] = false;
            $fields['billing_country']['required'] = false;

            // reorder
            $fields['billing_first_name']['priority'] = 9;
            $fields['billing_last_name']['priority'] = 9;
            $fields['billing_email']['priority'] = 10;
            $fields['billing_phone']['priority'] = 11;

            // class
            $fields['billing_email']['class'] = array('form-row-first');
            $fields['billing_phone']['class'] = array('form-row-last');

        }

        return $fields;
    } // end lf_remove_billing_fields
} // end pluggable


/**
     * Global Allow Only One Product In Cart At A Time
     *
     * @since 1.0.0
     *
     * @return void
     */
  
function lf_only_one_product_in_cart( $passed, $added_product_id ) {
   wc_empty_cart();
   return $passed;
}



/**
     * Name Your Price By Adding &donation=xxxx in url string of any ?add-to-cart product
     * Ref: //stackoverflow.com/questions/24731118/woocommerce-change-price-while-add-to-cart
     *
     * @since 2.0.1
     *
     * @return void
     */

    function lf_set_woo_prices( $woo_data ) {
      if ( ! isset( $_GET['donation'] ) || empty ( $_GET['donation'] ) ) { return $woo_data; }
      $woo_data['data']->set_price( $_GET['donation'] );
      $woo_data['my_price'] = $_GET['donation'];
      return $woo_data;
    }

    function  lf_set_session_prices ( $woo_data , $values , $key ) {
        if ( ! isset( $woo_data['my_price'] ) || empty ( $woo_data['my_price'] ) ) { return $woo_data; }
        $woo_data['data']->set_price( $woo_data['my_price'] );
        return $woo_data;
    }


/**
     * Pre-fills WC Checkout Fields For Email, First Name And Last Name From URL Parameters (email, fname, lname)
     * example: yourdomain.com/checkout/?email=bob@smith.com&fname=bob&lname=smith 
     *
     * @since 2.1.4
     *
     * @return void
     */

add_action( 'woocommerce_after_checkout_form', 'lf_prefill_billing_fields_logged_out', 10 );
function lf_prefill_billing_fields_logged_out() {
   
   if ( !is_user_logged_in() ): 
   // only runs if user is not logged in since wc already has autofill for logged-in user
   
        ?>
        
        <script type="text/javascript">
        
        jQuery(window).on('load', function(){

        // check whether any matching string for email exists, otherwise do not run function
        // encodedna.com/javascript/check-if-url-contains-a-given-string-using-javascript.htm

        if (window.location.href.indexOf('email=') > 0) {

            // https://www.sitepoint.com/url-parameters-jquery/
            jQuery.urlParam = function (name) {

            var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.search);

                if ( results == null){

                   return null;
                
                }
                
                else {
                
                   return results[1] || 0;
                
                }

            }


            var str = jQuery.urlParam('email'); 

            var res = str.replace("%40", "@");

            console.log(res); //email

            console.log(jQuery.urlParam('fname')); //first name

            console.log(jQuery.urlParam('lname')); //lname name

            jQuery('input[name="billing_email"]').val(res);

            jQuery('input[name="billing_first_name"]').val(jQuery.urlParam('fname'));

            jQuery('input[name="billing_last_name"]').val(jQuery.urlParam('lname'));

         } // end check for string

         
        }); // end on load

        </script>
        
        <?php

  endif;

}


/**
     * Adds An Empty WC Cartsyntax to be used on any url (see also shortcode button in class-launchflows-core)
     * example: ?emptycart=yes will empty any url (use in Elementor with any button design)
     *
     * @since 1.1.14
     *
     * @return void
     */

add_action( 'init', 'lf_empty_cart_action', 20 );
function lf_empty_cart_action() { // applies on any page where string is present ?emptycart=yes
  if (! is_admin() ) {
    if ( isset( $_GET['emptycart'] ) && 'yes' === esc_html( $_GET['emptycart']  ) ) {
        WC()->cart->empty_cart(true);
        $referer  = wp_get_referer() ? esc_url( remove_query_arg( 'emptycart' ) ) : wc_get_cart_url();
        wp_safe_redirect( $referer );
    }
  } // end admin check  
}


/**
     * Adds A WooCommerce Coupon Code To URL
     * example: ?lfcoupon=123456 will apply coupon via URL string
     *
     * @since 3.2.9
     *
     * @return void
     */
// see: stackoverflow.com/a/48225502/11187993
add_action('init', 'lf_get_custom_coupon_code_to_session');
function lf_get_custom_coupon_code_to_session(){
    if( isset($_GET['lfcoupon']) ){
        // Ensure that customer session is started
        if( !WC()->session->has_session() )
            WC()->session->set_customer_session_cookie(true);

        // Check and register coupon code in a custom session variable
        $coupon_code = WC()->session->get('lfcoupon');
        if(empty($coupon_code)){
            $coupon_code = esc_attr( $_GET['lfcoupon'] );
            WC()->session->set( 'lfcoupon', $coupon_code ); // Set the coupon code in session
        }
    }
}

add_action( 'woocommerce_before_checkout_form', 'lf_add_discout_to_checkout', 10, 0 );
function lf_add_discout_to_checkout( ) {

  // not on admin
  if ( !is_admin() ) {	
    // Set coupon code
    $coupon_code = WC()->session->get('lfcoupon');
    if ( ! empty( $coupon_code ) && ! WC()->cart->has_discount( $coupon_code ) ){
        WC()->cart->add_discount( $coupon_code ); // apply the coupon discount
        WC()->session->__unset('lfcoupon'); // remove coupon code from session
    }
  } 
}


/**
     * Auto saves billing fields for logged-out users while they are being typed, unless email= data is in url string already
     *
     * @since 4.0.9
     *
     * @return void
     */

//add_action('woocommerce_after_checkout_form', 'lf_persistent_data');
add_action('lf_after_form', 'lf_persistent_data');
function lf_persistent_data( ){ 

// only if user not logged-in
if ( !is_user_logged_in() ) {     
 
     ?> 

     <script type="text/javascript">

    (function($){

        var lf_check_is_local_storage = function(){ 
            var test = 'test';
            try {
                localStorage.setItem(test, test);
                localStorage.removeItem(test);
                return true;
            } catch(e) {
                return false;
            }
        }

        var lf_persistent_data = function(){
            
            if ( false === lf_check_is_local_storage() ) {
                return;
            }

            var lf_checkout_cust_form   = 'form.woocommerce-checkout .woocommerce-billing-fields';
            
            var lf_form_data = {
                set : function (){
                    
                    var checkout_data   = [];
                    var checkout_form   = $('form.woocommerce-checkout .woocommerce-billing-fields');
                    
                    localStorage.removeItem('lf_checkout_form');

                    checkout_form.find('input[type=text], select, input[type=email], input[type=tel]').each(function(){
                        checkout_data.push({ name: this.name, value: this.value});
                    });

                    lf_checkout_form = JSON.stringify(checkout_data);
                    localStorage.setItem('lf_checkout_form', lf_checkout_form);
                },
                get : function (){
                    
            
                    if ( localStorage.getItem('lf_checkout_form') != null ){
                        
                        checkout_data = JSON.parse( localStorage.getItem('lf_checkout_form') );
                        
                        for (var i = 0; i < checkout_data.length; i++) {

                            if ($('form.woocommerce-checkout [name='+checkout_data[i].name+']').hasClass('select2-hidden-accessible'))
                            
                            {
                            
                                $('form.woocommerce-checkout [name='+checkout_data[i].name+']').selectWoo("val", [checkout_data[i].value]);
                            
                            } else {
                            
                                $('form.woocommerce-checkout [name='+checkout_data[i].name+']').val(checkout_data[i].value);
                            
                            }
                            
                        }
                    }
                }
            }
            
            lf_form_data.get();
            
            $( lf_checkout_cust_form + " input, " + lf_checkout_cust_form + " select").change( function() {
                lf_form_data.set();
            });
        }


        $(document).ready(function($) {

            lf_persistent_data();


        });

    })(jQuery);
    </script>

    <?php

     }

    }


/**
 * Add multiple simple products to any LF Checkout Link for a "quick bundle"
 *
 *
 * @since 1.2.2
 * @access public
 */

// stackoverflow.com/questions/42570982/adding-multiple-items-to-woocommerce-cart-at-once
function lf_add_multiple_simple_products_to_cart() {

// make sure WC is installed, and add-to-cart qauery arg exists, and contains at least one comma.
if ( ! class_exists( 'WC_Form_Handler' ) || empty( $_REQUEST['add-to-cart'] ) || false === strpos( $_REQUEST['add-to-cart'], ',' ) ) {
    return;
}

// remove WooCommerce's hook, as it's useless (doesn't handle multiple products).
remove_action( 'wp_loaded', array( 'WC_Form_Handler', 'add_to_cart_action' ), 20 );

$product_ids = explode( ',', $_REQUEST['add-to-cart'] );
$count       = count( $product_ids );
$number      = 0;

foreach ( $product_ids as $product_id ) {
    if ( ++$number === $count ) {
        // Ok, final item, let's send it back to woocommerce's add_to_cart_action method for handling.
        $_REQUEST['add-to-cart'] = $product_id;

        return WC_Form_Handler::add_to_cart_action();
    }

    $product_id        = apply_filters( 'woocommerce_add_to_cart_product_id', absint( $product_id ) );
    $was_added_to_cart = false;
    $adding_to_cart    = wc_get_product( $product_id );

    if ( ! $adding_to_cart ) {
        continue;
    }

    $add_to_cart_handler = apply_filters( 'woocommerce_add_to_cart_handler', $adding_to_cart->product_type, $adding_to_cart );

  // works only with simple products add_to_cart_handler
    if ( 'simple' !== $add_to_cart_handler ) {
        continue;
    }

    // sets default quantity of all products to 1
    $quantity          = empty( $_REQUEST['quantity'] ) ? 1 : wc_stock_amount( $_REQUEST['quantity'] );
    $passed_validation = apply_filters( 'woocommerce_add_to_cart_validation', true, $product_id, $quantity );

    if ( $passed_validation && false !== WC()->cart->add_to_cart( $product_id, $quantity ) ) {
        wc_add_to_cart_message( array( $product_id => $quantity ), true );
    }
  }
}

 // fire before the WC_Form_Handler::add_to_cart_action callback.
 add_action( 'wp_loaded', 'lf_add_multiple_simple_products_to_cart', 15 );


 /**
   * WC Subscriptions - Strip the HTML tags of the custom price string fields
   *
   * @since 2.1.7
   *
   * @return void
   */

remove_filter( 'wcs_custom_price_string_value', 'strip_tags_of_custom_price_value', 10, 1 );


/**
     * Name Your Price By Adding donation=xxxx to url string
     * see: stackoverflow.com/questions/24731118/woocommerce-change-price-while-a-to-cart
     * see: stackoverflow.com/questions/57505646/woocommerce-custom-cart-item-price-on-add-to-cart-via-the-url
     * adds donation on top of any product price & may be repeated for any product added to cart
     *
     * @since 1.1.17
     *
     * @return void
     */

add_filter( 'woocommerce_add_cart_item_data', 'lf_catch_and_save_submited_donation', 10, 2 );
function lf_catch_and_save_submited_donation( $cart_item_data, $product_id ){
    if( isset($_REQUEST['donation']) ) {
        // Get the WC_Product Object
        $product = wc_get_product( $product_id );

        // Get and set the product active price
        $cart_item_data['active_price'] = (float) $product->get_price();

        // Get the donation amount and set it
        $cart_item_data['donation'] = (float) esc_attr( $_REQUEST['donation'] );
        $cart_item_data['unique_key'] = md5( microtime().rand() ); // Make each item unique
    }
    return $cart_item_data;
}



add_action( 'woocommerce_before_calculate_totals', 'lf_add_donation_to_item_price', 10, 1);
function lf_add_donation_to_item_price( $cart ) {
    if ( is_admin() && ! defined( 'DOING_AJAX' ) )
        return;

    // Avoiding hook repetition (when using price calculations for example)
    if ( did_action( 'woocommerce_before_calculate_totals' ) >= 2 )
        return;

    // Loop through cart items
    foreach ( $cart->get_cart() as $item ) {
        // Use either the donation, if set and at least 1, or the product price (set it to minimum required)
        if ( isset( $item['donation']) && ( $item['donation'] >= 1 ) && isset( $item['active_price']) ) {
            $item['data']->set_price( $item['donation'] ); // if donation is set, price equals donation
        } else {
            $item = false;
            if(isset($item['active_price'])){ // conditional check that active_price is set and not a null value
            $item['data']->set_price( $item['active_price'] ); // otherwise, price equals active price
            }
        }

    }
}