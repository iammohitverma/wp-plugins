jQuery(document).ready(function($) {

    //init jquery-ui-tooltip
    $(function() {
        $( '.help-icon' ).tooltip({show: false, hide: false});
    });

});