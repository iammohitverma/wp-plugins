(function ($) {
    $.fn.everestLightbox = function (options) {


    };


})(jQuery);