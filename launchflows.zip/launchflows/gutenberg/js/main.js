/**
 * Registers a new block provided a unique name and an object defining its behavior.
 * @see https://github.com/WordPress/gutenberg/tree/master/blocks#api
 */
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks
const { createElement } = wp.element;
const { PlainText, useBlockProps } = wp.blockEditor;
const { useInstanceId } = wp.compose;
const { Icon } = wp.components;

/**
 * Every block starts by registering a new block type definition.
 * @see https://wordpress.org/gutenberg/handbook/block-api/
 */
const createCustomBlocks = (props) => {
    registerBlockType(`launchflows/${props.slug}`, {
        /**
         * This is the display title for your block, which can be translated with `i18n` functions.
         * The block inserter will show this name.
         */
        title: __(props.name),
        icon: createElement("svg", {
            height: 30,
            width: 30,
            children: createElement("path", {
                d: props.svg || "M19 8h-1V6h-5v2h-2V6H6v2H5c-1.1 0-2 .9-2 2v8c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2v-8c0-1.1-.9-2-2-2zm.5 10c0 .3-.2.5-.5.5H5c-.3 0-.5-.2-.5-.5v-8c0-.3.2-.5.5-.5h14c.3 0 .5.2.5.5v8z",
                fill: props.color || '#e8007e'
            })
        }),
        attributes: {
            content: {
                type: 'string',
                //  source: 'html',
                //  selector: 'p',
                default: __(props.shortcode)
            },
        },
        /**
         * Blocks are grouped into categories to help users browse and discover them.
         * The categories provided by core are `common`, `embed`, `formatting`, `layout` and `widgets`.
         */
        category: 'lf',
        /**
         * Optional block extended support features.
         */
        supports: {
            // Removes support for an HTML mode.
            html: false,
        },
        keywords: [
            'launchflows',
            'woocommerce',
            'lf',
            props.slug
        ],
        /**
         * The edit function describes the structure of your block in the context of the editor.
         * This represents what the editor will render when the block is used.
         * @see https://wordpress.org/gutenberg/handbook/block-edit-save/#edit
         *
         * @param {Object} [props] Properties passed from the editor.
         * @return {Element}       Element to render.
         */
        edit: function (p) {
            const instanceId = useInstanceId(createCustomBlocks);
            const inputId = `blocks-shortcode-input-${instanceId}`;

            return createElement("div", {
                ...useBlockProps({
                    className: "lf components-placeholder",
                    style: { minHeight: 'inherit' }

                }),
                children: [
                    createElement("label", {
                        htmlFor: inputId,
                        className: "components-placeholder__label",
                        children: [
                            createElement(Icon, {
                                icon: createElement("svg", {
                                    height: 30,
                                    width: 30,
                                    children: createElement("path", {
                                        // set svg default for individual block label
                                        d: props.svg || "M19 8h-1V6h-5v2h-2V6H6v2H5c-1.1 0-2 .9-2 2v8c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2v-8c0-1.1-.9-2-2-2zm.5 10c0 .3-.2.5-.5.5H5c-.3 0-.5-.2-.5-.5v-8c0-.3.2-.5.5-.5h14c.3 0 .5.2.5.5v8z",
                                        fill: props.color || '#e8007e'
                                    })
                                }),
                            }),
                            __(`LaunchFlows ${props.name}`)
                        ]
                    }),
                    createElement(PlainText, {
                        className: "blocks-shortcode__textarea",
                        id: inputId,
                        value: p.attributes.content,
                        "aria-label": __("Shortcode text"),
                        placeholder: __(p.attributes.content),
                        onChange: (content) =>
                            p.setAttributes({
                                content: __(content)
                            })
                    })
                ]
            });
        },

        /**
         * The save function defines the way in which the different attributes should be combined
         * into the final markup, which is then serialized by Gutenberg into `post_content`.
         * @see https://wordpress.org/gutenberg/handbook/block-edit-save/#save
         *
         * @return {Element}       Element to render.
         */
        save: function (props) {
            var blockProps = useBlockProps.save();
            return createElement('div', Object.assign(blockProps, {
                children: props.attributes.content // Saves <h2>Content added in the editor...</h2> to the database for frontend display
            }));
        },
    });

}

/* block attributes
name:
slub:
shortcode:
svg:
color:
*/


createCustomBlocks({
    name: "LaunchFlows Account",
    slug: 'account',
    shortcode: '[lf-account]'
});

createCustomBlocks({
    name: "LaunchFlows Additional",
    slug: 'additional',
    shortcode: '[lf-additional]'
});

createCustomBlocks({
    name: "LaunchFlows Always In",
    slug: 'always-in',
    shortcode: '[lf-always-in product="1234" icon="yes" title="yes" price="yes" shortdesc="yes"]'
});

createCustomBlocks({
    name: "LaunchFlows Billing",
    slug: 'billing',
    shortcode: '[lf-billing]'
});

createCustomBlocks({
    name: "LaunchFlows Apply Tags",
    slug: 'apply-tags',
    shortcode: '[lf-apply-tags tags="123,567” debug="yes"]'
});

createCustomBlocks({
    name: "LaunchFlows Auto Click Checkout",
    slug: 'autoclick',
    shortcode: '[lf-autoclick]'
});

createCustomBlocks({
    name: "LaunchFlows Order Bump",
    slug: 'bump',
    shortcode: '[lf-bump product="1234" image="yes" title="yes" price="yes" style="p-round" shortdesc="yes"]'
});

createCustomBlocks({
    name: "LaunchFlows Donate",
    slug: 'donate',
    shortcode: '[lf-donate product="1234" field="Donate Big!" button="Do It Now!!"]'
});

createCustomBlocks({
    name: "LaunchFlows Checkout Button",
    slug: 'checkout-button',
    shortcode: '[lf-checkout-button]'
});

createCustomBlocks({
    name: "LaunchFlows Empty Cart Button",
    slug: 'emptycart',
    shortcode: '[lf-emptycart]'
});

createCustomBlocks({
    name: "LaunchFlows Login",
    slug: 'login',
    shortcode: '[lf-login]'
});

createCustomBlocks({
    name: "LaunchFlows Notices",
    slug: 'notices',
    shortcode: '[lf-notices]'
});

createCustomBlocks({
    name: "LaunchFlows Payment",
    slug: 'payment',
    shortcode: '[lf-payment]'
});

createCustomBlocks({
    name: "LaunchFlows Remove Tags",
    slug: 'remove-tags',
    shortcode: '[lf-remove-tags tags="123,567” debug="false"]'
});

createCustomBlocks({
    name: "LaunchFlows Review Order",
    slug: 'review',
    shortcode: '[lf-review]'
});

createCustomBlocks({
    name: "LaunchFlows Return To Checkout",
    slug: 'lf-return-checkout',
    shortcode: '[lf-return-checkout]'
});

createCustomBlocks({
    name: "LaunchFlows Save Stripe Credit Card",
    slug: 'save-stripe-cc',
    shortcode: '[lf-save-stripe-cc]'
});

createCustomBlocks({
    name: "LaunchFlows Save Square Credit Card",
    slug: 'save-square-cc',
    shortcode: '[lf-save-square-cc]'
});

createCustomBlocks({
    name: "LaunchFlows Shipping Fields",
    slug: 'shipping',
    shortcode: '[lf-shipping]'
});

createCustomBlocks({
    name: "LaunchFlows Thank you",
    slug: 'thank-you',
    shortcode: '[lf-thank-you]'
});

createCustomBlocks({
    name: "LaunchFlows Woocommerce Coupon",
    slug: 'wccoupon',
    shortcode: '[lf-wccoupon]'
});

createCustomBlocks({
    name: "LaunchFlows Upsell",
    slug: 'upsell',
    shortcode: '[lf-upsell product="1234" next="5678" accept="Yes, I Want It!" accept_tags="123,456" decline="No Thanks..." image="yes" title="yes" price="yes"]'
});

// Product Blocks

createCustomBlocks({
    name: "Product Add To Cart",
    slug: 'productaddtocart',
    shortcode: '[lf-product-add-to-cart]',
    color: 'purple'
});

createCustomBlocks({
    name: "Product Breadcrumb",
    slug: 'productbreadcrumb',
    shortcode: '[lf-product-breadcrumb]',
    color: 'purple'
});

createCustomBlocks({
    name: "Product Description",
    slug: 'productdescription',
    shortcode: '[lf-product-description]',
    color: 'purple'
});
createCustomBlocks({
    name: "Product First Payment",
    slug: 'productfirstpayment',
    shortcode: '[lf-product-firstpayment]',
    color: 'purple'
});
createCustomBlocks({
    name: "Product Images",
    slug: 'productimages',
    shortcode: '[lf-product-images]',
    color: 'purple'
});
createCustomBlocks({
    name: "Product Meta",
    slug: 'productmeta',
    shortcode: '[lf-product-meta]',
    color: 'purple'
});
createCustomBlocks({
    name: "Product Related",
    slug: 'productrelated',
    shortcode: '[lf-product-related]',
    color: 'purple'
});
createCustomBlocks({
    name: "Product Tabs",
    slug: 'producttabs',
    shortcode: '[lf-product-tabs]',
    color: 'purple'
});
createCustomBlocks({
    name: "Product Title",
    slug: 'producttitle',
    shortcode: '[lf-product-title]',
    color: 'purple'
});
createCustomBlocks({
    name: "Product Price",
    slug: 'productprice',
    shortcode: '[lf-product-price]',
    color: 'purple'
});
createCustomBlocks({
    name: "Product Link",
    slug: 'productlink',
    shortcode: '[lf-product-link]',
    color: 'purple'
});
createCustomBlocks({
    name: "Product Payments (Kadence)",
    slug: 'productpayments',
    shortcode: '[lf-product-payments]',
    color: 'purple'
});
createCustomBlocks({
    name: "Product Extras (Kadence)",
    slug: 'productextras',
    shortcode: '[lf-product-extras]',
    color: 'purple'
});
createCustomBlocks({
    name: "Product Breadcrumbs (Kadence)",
    slug: 'productbreadcrumbs',
    shortcode: '[lf-product-breadcrumbs]',
    color: 'purple'
});
