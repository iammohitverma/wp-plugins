<?php
require_once IHC_PATH . 'admin/extensions_plus/inc/init.php';
