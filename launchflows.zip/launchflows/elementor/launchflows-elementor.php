<?php
namespace LaunchFlowsElementor;

/**
 * Elementor Plugin Class For Custom Widget
 *
 * @since 1.0.0
 *
 */
class Plugin {

	/**
	 * Instance
	 *
	 * @since 1.2.0
	 * @access private
	 * @static
	 *
	 * @var Plugin The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return Plugin An instance of the class.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}


	/**
	 * widget_scripts
	 *
	 * Load required plugin core files.
	 *
	 * @since 1.0.0
	 * @access public
	 */

	public function widget_scripts() {
		wp_register_script( 'launchflows-elementor', plugins_url( '/js/launchflows-elementor.js', __FILE__ ), [ 'jquery' ], false, true );
	}

	/**
	 * Include Widgets files
	 *
	 * Load widgets files
	 *
	 * @since 3.2.2
	 * @access private
	 */
	private function include_widgets_files() {
		require_once( __DIR__ . '/widgets/launchflows-elementor-upsell.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-bump.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-donation.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-billing.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-shipping.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-additional.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-review.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-payment.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-thankyou.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-coupon.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-login.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-notices.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-always-in.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-autoclick.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-emptycart.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-checkout-button.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-account.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-return-checkout.php' );

		// products
		require_once( __DIR__ . '/widgets/launchflows-elementor-product-add-to-cart.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-product-breadcrumb.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-product-breadcrumbs.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-product-extras.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-product-payments.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-product-price.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-product-title.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-product-tabs.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-product-related.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-product-meta.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-product-images.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-product-firstpayment.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-product-description.php' );


		// to be deprecated
		require_once( __DIR__ . '/widgets/launchflows-elementor.php' );
		require_once( __DIR__ . '/widgets/launchflows-elementor-style-manager.php' );

		// check for WPFusion installed and activated
		if (class_exists('WP_Fusion')) {
			require_once( __DIR__ . '/widgets/launchflows-elementor-apply-tags.php' );
			require_once( __DIR__ . '/widgets/launchflows-elementor-remove-tags.php' );

		}

	}

	/**
	 * Register Widgets
	 *
	 * Register new Elementor widgets.
	 *
	 * @since 4.0.8
	 * @access public
	 */
	public function register_widgets() {
		// Its is now safe to include Widgets files
		$this->include_widgets_files();

		// Register Widgets
		
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorBilling() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorReview() );
		

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorShipping() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorPayment() );

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorAdditional() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorCheckoutButton() );

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorEmptycart() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorCoupon() );

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorLogin() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorNotices() );

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorDonation() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorThankyou() );

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorBump() );		
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorAlwaysIn() );

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorUpsell() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorAutoclick() );

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorProductAddToCart() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorProductBreadcrumb() );	

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorProductBreadcrumbs() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorProductExtras() );	

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorProductPayments() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorProductPrice() );	

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorProductTitle() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorProductTabs() );	

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorProductRelated() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorProductMeta() );	
		
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorProductImages() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorProductFirstpayment() );	

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorProductDescription() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorReturnCheckout() );	


		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorAccount() );	


		// check for WPFusion installed and activated
		if (class_exists('WP_Fusion')) {
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorApplyTags() );
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorRemoveTags() );	
		}

		// to be deprecated
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementor() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\LaunchFlowsElementorStyleManager() );

		
	}


	/**
	 * Register Custom Categories
	 *
	 * Register new Elementor widget categories
	 *
	 * @since 1.2.2
	 * @access public
	 */
	public function add_elementor_widget_categories( $elements_manager ) {

	$elements_manager->add_category(
		'launchflows',
		[
			'title' => __( 'LaunchFlows', 'lf' ),
			'icon' => 'fa fa-plug',
		]
	);
}

	/**
	 *  Plugin class constructor
	 *
	 * Register plugin action hooks and filters
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {

		// Register widget scripts
		add_action( 'elementor/frontend/after_register_scripts', [ $this, 'widget_scripts' ] );

		// Register widgets
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );

		// Register categories
		add_action( 'elementor/elements/categories_registered', [ $this, 'add_elementor_widget_categories' ] );
	}
}

// Instantiate Plugin Class
Plugin::instance();