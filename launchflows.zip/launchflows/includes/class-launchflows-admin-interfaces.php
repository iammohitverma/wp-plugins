<?php 
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class LF_Admin_Interfaces {

	/**
	 * Admin interfaces for LaunchFlows
	 *
	 * @since 1.2.2
	 */


	public function __construct() {


		// Add Shortcode To Insert Template
		add_shortcode('elementor-template', array( $this, 'lf_insert_elementor') );

      // for adding content to WC form-checkout template
      add_action ('lf_content', array ($this, 'apply_custom_template' ) );

      // add LF to all sidebars in most themes
      add_action ('get_sidebar', array ($this, 'apply_custom_template'));

	}


/**
    * Add elementor-template shortcode
    *
    * @since 1.2.2
    * @return void
	*/ 

	public function lf_insert_elementor($atts){

	    if(!isset($atts['id']) || empty($atts['id'])){

	        return '';
	    
	    }

	    $post_id = $atts['id'];

	    $response = Plugin::instance()->frontend->get_builder_content_for_display($post_id);

	    return $response;
	}

/**
   * Enqueues all js and css for launchflows checkout pages (public js and css in launchflows.php)
   *
   * @since 4.0.8
   *
   * @return void
   */

  	public function apply_custom_template($content) {

	// 4.0.8 moved all other scripts moved to launchflows.php
  		
  		// launchflows layout script loads here so it can load conditionally via shortcode
		wp_register_script('launchflows.js',  plugin_dir_url( __FILE__ ) . '../assets/js/launchflows.js', false, null, true);

		wp_enqueue_script('launchflows.js'); 



	} // end function


// end
}
/**
 * Finally, instantiate the class
 */

new LF_Admin_Interfaces;