<?php

class LFProductDataTab {

	/**
	 * Method to kickstart the code.
	 *
	 * @since 4.0.8
	 *
	 * @return void
	 */

	public static function start(){
		new LFProductDataTab;
	}


	public function __construct() {

		add_filter( 'woocommerce_product_data_tabs', array( $this, 'add_product_data_tab' ) );
		add_action( 'woocommerce_product_data_panels', array( $this, 'add_product_data_tab_target' ) );
	}

	/**
	 *	Adds the tab to the meta box
	 *
	 *	@param array $tabs - Default tabs
	 *	@return array $tabs - New tabs
	 *
	 * @since 2.0.0
	 *
	 * @return void
	 */

	public function add_product_data_tab( $tabs ) {

		$tabs['launchflows'] = array(
			'label'  => __( 'LaunchFlows', 'woocommerce-launchflows' ),
			'target' => 'launchflows_tab',
			'class'  => array( 'add_to_cart_redirect' ),
		);

		return $tabs;
	}

	/**
	 *	Render output for tab target
	 */
	public function add_product_data_tab_target() {

?>
<style>
	#woocommerce-product-data ul.wc-tabs li.add_to_cart_redirect a::before {
		font-family: Dashicons;
		content: '\f124';
	}

	#launchflows_tab input[type="text"]::placeholder {
		color: #fff;
	}

	#launchflows_tab input[type="text"]:focus::placeholder {
		color: inherit;
	}

	#launchflows_tab {
		width: 90%;
	}
</style>

<div id="launchflows_tab" class="panel woocommerce_options_panel" style="display: block;">

	<div class="options_group">

		<?php // sets up checkout field (**fallback to here**)
				global $post;
				$label_field_value = '';
				$id_field_value    = '';
				$meta_value = get_post_meta($post->ID, '_lf_checkout_field', true);

				if ( ! empty( $meta_value ) ) {
					if ( 0 !== (int) $meta_value ) {
						$id_field_value    = $meta_value;
						$label_field_value = get_the_title( (int) $meta_value );
					} else {
						$label_field_value = $meta_value;
					}
				}					

				echo "<div class=\"lf_custom_checkout\">";
				woocommerce_wp_text_input(
					array(
						'id' 			=> '_lf_checkout_field', 
						'class' 		=> 'wc_input_lf_checkout_field short',
						'label' 		=> __('Select Next Step Page', 'lf'), 
						'placeholder' 	=> __('Type to find your next step page.', 'lf'), 
						'description' 	=> __('Product will be added to cart and then buyer redirected to this location. Eg: A Checkout or Additional Product Offer.', 'lf'),
						'desc_tip' 		=> true,
						'type' 			=> 'text',
						'value'	        => $label_field_value,
					)
				);
				woocommerce_wp_hidden_input(
					array(
						'id'    => '_lf_checkout_field_id',
						'value' => $id_field_value,
					)
				);				
				echo "</div>";	
		?>

		<?php // sets up thank you page field from drop down selections
				global $post;
				$label_field_value = '';
				$id_field_value    = '';
				$meta_value = get_post_meta($post->ID, '_lf_thankyoupage_field', true);

				if ( ! empty( $meta_value ) ) {
					if ( 0 !== (int) $meta_value ) {
						$id_field_value    = $meta_value;
						$label_field_value = get_the_title( (int) $meta_value );
					} else {
						$label_field_value = $meta_value;
					}
				}		

				echo "<div class=\"lf_custom_thankyou\">";
				woocommerce_wp_text_input( 
					array(
						'id' 			=> '_lf_thankyoupage_field', 
						'class'			=> 'wc_input_lf_thankyoupage_field short',
						'label' 		=> __('Select Post Checkout Page', 'lf'), 
						'placeholder' 	=> __('Type to find your post checkout page.', 'lf'), 
						'description' 	=> __('Buyer will be sent to this location after checkout is completed. Eg: A Thank You or Post Checkout Upsell.', 'lf'),
						'desc_tip' 		=> true,
						'type' 			=> 'text',
						'value'         => $label_field_value,
					)
				);
				woocommerce_wp_hidden_input(
					array(
						'id'    => '_lf_thankyoupage_field_id',
						'value' => $id_field_value,
					)
				);

				echo "</div>";
		?>
	</div>
	<div class="options_group">
		<?php // sets up next step page field from drop down selections
				global $post;
				$label_field_value = '';
				$id_field_value    = '';
				$meta_value = get_post_meta($post->ID, '_lf_nextstep_field', true);

				if ( ! empty( $meta_value ) ) {
					if ( 0 !== (int) $meta_value ) {
						$id_field_value    = $meta_value;
						$label_field_value = get_the_title( (int) $meta_value );
					} else {
						$label_field_value = $meta_value;
					}
				}		

				echo "<div class=\"lf_custom_nextstep\">";
				woocommerce_wp_text_input( 
					array(
						'id' 			=> '_lf_nextstep_field', 
						'class'			=> 'wc_input_lf_nextstep_field short',
						'label' 		=> __('Select Next Step Link', 'lf'), 
						'placeholder' 	=> __('Type to find your next step page.', 'lf'), 
						'description' 	=> __('Use [lf-next-step-link] shortcode to output this link url.', 'lf'),
						'desc_tip' 		=> false,
						'type' 			=> 'text',
						'value'         => $label_field_value,
					)
				);
				woocommerce_wp_hidden_input(
					array(
						'id'    => '_lf_nextstep_field_id',
						'value' => $id_field_value,
					)
				);

				echo "</div>";

		?>

	</div>

	<div class="options_group">
		<?php // sets up next step page field from drop down selections
				global $post;
				$label_field_value = '';
				$id_field_value    = '';
				$meta_value = get_post_meta($post->ID, 'lf_custom_product_template_field', true);

				if ( ! empty( $meta_value ) ) {
					if ( 0 !== (int) $meta_value ) {
						$id_field_value    = $meta_value;
						$label_field_value = get_the_title( (int) $meta_value );
					} else {
						$label_field_value = $meta_value;
					}
				}		

				echo "<div class=\"lf_custom_product_template\">";

				woocommerce_wp_select( array( // Text Field type
						'id' 			=> '_lf_custom_product_template_field', 
						'class'			=> 'wc_input_lf_custom_product_template_field short',
						'label' 		=> __('Select Product Template', 'lf'), 
						'placeholder' 	=> __('Type to find your product template.', 'lf'), 
						'description' 	=> __('Choose the template you would like to use for this product.', 'lf'),
						'desc_tip'    => true,
						'options'     => array(
						'original'    	=> __('Original Template', 'lf' ),
						'default'       => __('LF Default Template', 'lf' ),
						'blank'    		=> __('LF Blank Template', 'lf' ),
						'one'    		=> __('LF Template One', 'lf' ),
						'two'    		=> __('LF Template Two', 'lf' ),
						)
				) );

				echo "</div>";
			/*	
			// inline css to change style of blocks if certain template is used
			$template_choice = get_post_meta( $post->ID, '_lf_custom_product_template_field', true );
			if ($template_choice == 'blank'){
			echo '<style>.block-editor-page .wp-block.lf {background: repeating-linear-gradient( 45deg, #fefefe, #fefefe 10px, #efefef 10px, #efefef 20px )}</style>';
			} 
			*/
		?>

	</div>
	<div class="options_group">
		<?php
				echo "<div class=\"lf_leadmagnet\">";
				woocommerce_wp_checkbox(
					array(
						'id' => 'leadmagnet_input', 
						'label' => __('Instant Registration','lf'), 
						'value' => get_post_meta( get_the_ID(), 'leadmagnet_input', true),
						'desc_tip' => true,
						'description' => __('Instantly displays a clean form with grey border whenever this product and checkout values are set to FREE.','lf'),
					)
				);
			    echo "</div>";	
		?>
		<?php
				echo "<div class=\"lf_solocheckout\">";
				woocommerce_wp_checkbox(
					array(
						'id' => 'solocheckout_input', 
						'label' => __('Solo Checkout','lf'), 
						'value' => get_post_meta( get_the_ID(), 'solocheckout_input', true),
						'description' => __('*Not for use with grouped products. When checked, all other products will be removed from checkout when this product is added.','lf'),
						'desc_tip' => true,
					)
				);
			    echo "</div>";
		?>
		<?php
				echo "<div class=\"lf_removerelated\">";
				woocommerce_wp_checkbox(
					array(
						'id' => 'removerelated_input', 
						'label' => __('Instant Clean Sales Page','lf'), 
						'value' => get_post_meta( get_the_ID(), 'removerelated_input', true),
						'desc_tip' => true,
						'description' => __('Hides display of breadcrumbs, related products, meta data and tabs from this product on ALL Product templates.','lf'),
					)
				);
			    echo "</div>";
		?>
		<?php
		/*
				echo "<div class=\"lf_productcheckout\">";
				woocommerce_wp_checkbox(
					array(
						'id' => 'productcheckout_input', 
						'label' => __('Instant Checkout Page','lf'), 
						'value' => get_post_meta( get_the_ID(), 'productcheckout_input', true),
						'desc_tip' => true,
						'description' => __('Adds a checkout to this product\'s default display page that you can further customize with shortcodes or widgets.','lf'),
					)
				);
			    echo "</div>";
		*/
		?>

		<?php
				echo "<div class=\"lf_instant_branding\">";
				woocommerce_wp_checkbox(
					array(
						'id' => 'instantbranding_input', 
						'label' => __('Instant Branding','lf'), 
						'value' => get_post_meta( get_the_ID(), 'instantbranding_input', true),
						'desc_tip' => true,
						'description' => __('Will hide this product from the order review so it can display branding data for any checkout.','lf'),
					)
				);
			    echo "</div>";
		?>

		<?php
				echo "<div class=\"lf_hide_free_price\">";
				woocommerce_wp_checkbox(
					array(
						'id' => 'hidefreeprice_input', 
						'label' => __('Hide Free Price','lf'), 
						'value' => get_post_meta( get_the_ID(), 'hidefreeprice_input', true),
						'desc_tip' => true,
						'description' => __('Will hide the price of this product from the order review. Useful when adding products to bundles at no cost.','lf'),
					)
				);
			    echo "</div>";
		?>		

		<?php
				echo "<div class=\"lf_one_variation\">";
				woocommerce_wp_checkbox(
					array(
						'id' => 'onevariation_input', 
						'label' => __('Only One Variation', 'lf'), 
						'value' => get_post_meta( get_the_ID(), 'onevariation_input', true),
						'desc_tip' => true,
						'description' => __('Enable this to allow only one variation (from this product) to be purchased at a time.','lf'),
					)
				);
			    echo "</div>";
		?>	

		<?php
				echo "<div class=\"lf_force_thankyou\">";
				woocommerce_wp_checkbox(
					array(
						'id' => 'forcethankyou_input', 
						'label' => __('Force Thank You', 'lf'), 
						'value' => get_post_meta( get_the_ID(), 'forcethankyou_input', true),
						'desc_tip' => true,
						'description' => __('Force this product thank you page to override default. *Use on only ONE product!.','lf'),
					)
				);
			    echo "</div>";
		?>	

	</div>

</div>


<?php
	}

} // end class wrapper

/**
 * Finally, start the class
 */

LFProductDataTab::start();