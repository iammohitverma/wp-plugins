<?php
/**
 * Plugin Name:	LaunchFlows
 * Plugin URI:	https://launchflows.com
 * Description:	Create Custom Checkout Experiences With WooCommerce & Elementor!
 * Version:		4.1.2
 * Author:		1WD LLC
 * Author URI:	https://launchflows.com
 * License:		GPL-2.0+
 * License URI:	http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: lf
 * WC requires at least: 3.0
 * WC tested up to: 5.7.1
 *
 * @package LaunchFlows
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


	/**
	 * LaunchFlows Class
	 *
	 *
	 * @since 1.0.16
	 */

class LaunchFlows {

	/**
	 * Plugin Version
	 *
	 * @since 1.0.0
	 * @var string The plugin version.
	 */
	const VERSION = '4.1.2';

	/**
	 * Minimum Elementor Version
	 *
	 * @since 1.0.0
	 * @var string Minimum Elementor version required to run the plugin.
	 */
	const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

	/**
	 * Minimum PHP Version
	 *
	 * @since 1.0.0
	 * @var string Minimum PHP version required to run the plugin.
	 */
	const MINIMUM_PHP_VERSION = '7.0';



	/**
	 * Constructor
	 *
	 * @since 1.0.16
	 * @access public
	 */

	public function __construct() {


		// Load textdomain for translation
		add_action( 'init', array( $this, 'lf' ) );

		// Load constants and includes
		add_action( 'init', array($this, 'setup_constants' ));

		// Initialize the Plugin init method
		add_action( 'plugins_loaded', array( $this, 'init' ) );

		add_action( 'plugins_loaded', array($this, 'includes' ));

		// Adds Admin Panel and Content
		add_action( 'admin_menu', array( $this, 'lf_add_admin_menu' ));
		
		add_action( 'admin_init', array ($this , 'lf_settings_init' ));

		// Apply Settings
		add_action( 'init', array( $this, 'lf_apply_settings' ) );

		// Apply Public Style
		add_action('wp_enqueue_scripts', array($this, 'lf_add_public_style' ), 999); // loads last with high priority

		// Apply Admin Style
		add_action( 'admin_enqueue_scripts', array( $this, 'lf_add_script_to_menu_page' ) );

		// Add Appsero
      	add_action ( 'init', array( $this, 'appsero_init_tracker_launchflows') );


	}

	/**
	 * Load Textdomain
	 *
	 * Load plugin localization files.
	 * Fired by `init` action hook.
	 *
	 * @since 1.0.0
	 * @access public
	 */

	public function lf() {
		load_plugin_textdomain( 'lf' );
	}

	/**
	 * Initialize LaunchFlows Plugin
	 *
	 * Validates that Woocommerce already loaded.
	 *
	 * Fired by `plugins_loaded` action hook.
	 *
	 * @since 3.3.8
	 * @access public
	 */

	public function init() {

        // Check if WooCommerce is installed and activated
        if ( ! function_exists( 'WC' ) ) {
			add_action( 'admin_notices', array( $this, 'woocommerce_fails_to_load' ) ); // error, offer to install
		}

		// Once we get here, We have passed the WooCommerce validation check so we can safely include our core features

		require_once( 'includes/class-launchflows-core.php' );		// core plugin logic
		require_once( 'includes/class-launchflows-functions.php'); 	// primary functions
		require_once( 'includes/class-launchflows-admin-interfaces.php'); 	// metabox and template controls
		require_once( 'includes/class-launchflows-featured-product.php' );	// featured product shortcodes & logic
		require_once( 'includes/class-launchflows-checkout-button.php' ); // custom metabox for checkout buttons
		require_once( 'includes/class-launchflows-thankyou.php' ); // custom thank you pages per WC product
		require_once( 'includes/class-launchflows-nextstep.php' ); // custom nextstep link per WC product
		require_once( 'includes/class-launchflows-leadmagnet.php' ); // custom leadmagnets from any WC product
		require_once( 'includes/class-launchflows-quantity.php' ); // custom ajax update of quantity for any WC product
	    require_once( 'includes/class-launchflows-solocheckout.php' ); // custom product upon for solo checkout
	    require_once( 'includes/class-launchflows-removerelated.php' ); // custom remove related products from single product pages
	    require_once( 'includes/class-launchflows-product-data-tab.php' ); // custom controls tab added to woocommerce single products
	    require_once( 'includes/class-launchflows-custom-checkout.php' ); // custom checkout url field for woocommerce single products
	    require_once( 'includes/class-launchflows-product-type.php' ); // filters out simple products for use with the checkout link generator
	    require_once( 'includes/class-launchflows-instant-branding.php' ); // custom remove related products from single product pages
	    require_once( 'includes/class-launchflows-hide-free-price.php' ); // hides any product price from order review
	    require_once( 'includes/class-launchflows-one-variation.php' ); // custom choose one variation or any
	    require_once( 'includes/class-launchflows-force-thankyou.php' ); // force product thank you page option to be default
	    require_once( 'includes/class-launchflows-product-checkout.php' ); // adds custom checkout capability to product pages
	    require_once( 'includes/class-launchflows-custom-product-template.php' ); // adds custom template capability to product pages
	    require_once( 'includes/class-launchflows-checkout-meta.php' ); // custom metabox to enable LF on any post

	    //This is the main class to enqueue the blocks js.
	    require_once('gutenberg/class-launch-blocks.php');

  	    // This adds the gutenberg block pattern category and patterns
  	    require_once( 'includes/class-launchflows-block-patterns.php' ); 

		// Once we get here, We have passed all Elementor validation checks so we can safely include our Elementor features
		require_once( 'elementor/launchflows-elementor.php' );

		// Then check if WPFusion is installed and activated
		if (class_exists('WP_Fusion')) {
		require_once( 'includes/class-launchflows-wpf.php' );
		}	

      // adds custom body classes
	   add_filter( 'body_class', array($this, 'lf_body_class') );
	}


/**
   * Adds Body Class To LF Pages Only
   *
   * @since 3.5.3
   *
   * @return void
   */

 public function lf_body_class( $classes ) {
 global $post;

$template_choice = get_post_meta( $post->ID, '_lf_custom_product_template_field', true );       

  if ( is_product() && get_post_meta($post->ID, '_lf_activate_checkout_checkbox', true) == true || is_product() && $template_choice !='original')  {

	    $classes[] = 'launchflows lf-product-template-'. $template_choice;
	
	} else if ( is_product() && get_post_meta($post->ID, '_lf_activate_checkout_checkbox', true) == true || is_product() && $template_choice ='original')  {

	    $classes[] = 'lf-product-template-original';
	
	} else if ( !is_product() && get_post_meta($post->ID, '_lf_activate_checkout_checkbox', true) == true) {

		$classes[] = 'launchflows lf-checkout';
	}

	    return $classes;
	
	}



/**
	 * Fires admin notice when WooCommerce is not installed and activated.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */

	public function woocommerce_fails_to_load() {

    if (!current_user_can('activate_plugins')) {
        return;
    }

	if ( ! function_exists( '_is_woocommerce_installed' ) ) {

		/**
		 * Is WooCommerce plugin installed.
		 *
		 * @since 1.0.0
		 *
		 * @access public
		 */
		function _is_woocommerce_installed() {

			$path    = 'woocommerce/woocommerce.php';

			$plugins = get_plugins();

			return isset( $plugins[ $path ] );
		}
	}

		$screen = get_current_screen();

		if ( isset( $screen->parent_file ) && 'plugins.php' === $screen->parent_file && 'update' === $screen->id ) {
			return;
		}

		$plugin = 'woocommerce/woocommerce.php';

		if ( _is_woocommerce_installed() ) {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}

			$activation_url = wp_nonce_url( 'plugins.php?action=activate&amp;plugin=' . $plugin . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $plugin );

			$message = '<p>' . __( 'The <strong>LaunchFlows</strong> plugin requires the <strong>WooCommerce</strong> plugin.', 'lf' ) . '</p>';
	
			$message .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', $activation_url, __( 'Activate WooCommerce Now', 'lf' ) ) . '</p>';
	
		} else {
	
			if ( ! current_user_can( 'install_plugins' ) ) {
	
				return;
			}

			$install_url = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=woocommerce' ), 'install-plugin_woocommerce' );

			$message = '<p>' . __( 'The <strong>LaunchFlows</strong> plugin requires the <strong>WooCommerce</strong> plugin.', 'lf' ) . '</p>';
	
			$message .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', $install_url, __( 'Install WooCommerce Now', 'lf' ) ) . '</p>';
		}

		echo '<div class="error launchflows"><p>' . $message . '</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>';
	}



/**
	 * Setup plugin constants
	 *
	 * @since 1.0.16
	 *
	 * @access private
	 * @return void
	 */

	public function setup_constants() {

		if ( ! defined( 'LF_DIR_PATH' ) ) {

			define( 'LF_DIR_PATH', plugin_dir_path( __FILE__ ) );
		
		}

		if ( ! defined( 'LF_PLUGIN_PATH' ) ) {
			
			define( 'LF_PLUGIN_PATH', plugin_basename( __FILE__ ) );
		
		}

		if ( ! defined( 'LF_DIR_URL' ) ) {
		
			define( 'LF_DIR_URL', plugin_dir_url( __FILE__ ) );
		
		}

	}


/**
	 * Load testing environment
	 *
	 * @since 1.1.19
	 *
	 * @access private
	 * @return void
	 */

	public function includes() {

	//require_once 'includes/class-launchflows-experimental.php'; 		// for testing new functions
	}

/**
	 * Adds Admin Page
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */

	public function lf_add_admin_menu( ) { 

	add_menu_page( 'LaunchFlows', 'LaunchFlows', 'manage_options', 'launchflows', array ($this, 'lf_options_page' ), 'dashicons-rest-api');

	}




/**
	 * Adds Admin Page Style
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */

	public function lf_add_script_to_menu_page() {

    $screen = get_current_screen();

	    if (is_object($screen) && $screen->id == 'toplevel_page_launchflows') {
		    
		    // load admin page css
		    
		    wp_register_style( 'launchflows-admin', LF_DIR_URL . 'assets/css/launchflows-admin.css', false, '1.0' );
		    
		    wp_enqueue_style( 'launchflows-admin' );
		     
		 }   
}


/**
	 * Adds LaunchFlows Page Styles & Scripts
	 *
	 * @since 4.1.2
	 *
	 * @return void
	 */

	public function lf_add_public_style() {
	global $post;
	$template_choice = get_post_meta( $post->ID, '_lf_custom_product_template_field', true );       

	// check for proper single product template or metabox value or thank you shortcode before loading lf scripts and styles
  	if ( get_post_meta($post->ID, '_lf_activate_checkout_checkbox', true) == true || is_product() && $template_choice !='original' || has_shortcode( $post->post_content, 'lf-thank-you' ) || has_shortcode( $post->post_content, 'lf-bump' ) || has_shortcode( $post->post_content, 'lf-upsell' ) || has_shortcode( $post->post_content, 'lf-always-in' ) || has_shortcode( $post->post_content, 'lf-scripts' ) || has_shortcode( $post->post_content, 'ifso' ) )  {

		// load public facing css (minified)

	    wp_register_style( 'launchflows-public', LF_DIR_URL . 'assets/css/launchflows-public.min.css', false, '3.2.1' );

	    wp_enqueue_style( 'launchflows-public' );



	    // load checkbox style css
	    wp_register_style( 'launchflows-pretty-checkbox', LF_DIR_URL . 'assets/css/launchflows-pretty-checkbox.min.css', false, '3.1' );

	    wp_enqueue_style( 'launchflows-pretty-checkbox' );


	    // load lightbox style and scripts
	    
	    wp_register_style( 'launchflows-lightbox', LF_DIR_URL . 'lightbox/css/lightbox.css', false, '1.0.5' );
	    
	    wp_enqueue_style( 'launchflows-lightbox' );
	    
	    wp_enqueue_script( 'launchflows-lightbox', LF_DIR_URL . 'lightbox/js/lightbox.js', array('jquery'), '1.0.5', true );
 		

 		// link-to-tabs
 		wp_enqueue_script( 'launchflows-link-to-tabs', LF_DIR_URL . 'elementor/js/link-to-tabbed-content.js', array('jquery'), '1.0.5', true );


		// checkout css
		wp_register_style( 'launchflows-checkout', LF_DIR_URL . 'assets/css/launchflows-checkout.min.css', false, '3.2.0' );

		wp_enqueue_style( 'launchflows-checkout' );

	} 
}	

/**
	 * Adds Admin Page Settings
	 *
	 * @since 1.0.16
	 *
	 * @return void
	 */

	public function lf_settings_init( ) { 

	register_setting( 'pluginPage', 'lf_settings');

	add_settings_section( 
		'lf_pluginPage_section', 
		__( 'Global Options - To Modify Default WooCommerce Behavior<hr>', 'lf' ), 
		array($this, 'lf_settings_section_woocommerce'), 
		'pluginPage'
	);

	add_settings_field( // Change Checkout Button Text (Globally) For WooCommerce 
		'lf_text_field_1', 
		__( '<u>WooCommerce Utility:</u><br/>Change Default WC Checkout Button Text', 'lf' ), 
		array($this, 'lf_text_field_1_render'), 
		'pluginPage', 
		'lf_pluginPage_section' 
	);

	add_settings_field( // Change Checkout Button Text (Globally) For WooCommerce SINGLE product pages
		'lf_text_field_2', 
		__( '<u>WooCommerce Utility:</u><br/>Change Add To Cart Button Text for Single Product Pages', 'lf' ), 
		array($this, 'lf_text_field_2_render'), 
		'pluginPage', 
		'lf_pluginPage_section' 
	);

	add_settings_field( // Change Checkout Button Text (Globally) For WooCommerce SHOP and other pages
		'lf_text_field_3', 
		__( '<u>WooCommerce Utility:</u><br/>Change Add To Cart Button Text other than Single Product Pages', 'lf' ), 
		array($this, 'lf_text_field_3_render'), 
		'pluginPage', 
		'lf_pluginPage_section' 
	);

	add_settings_field( // Change Checkout Button Text (Globally) For WooCommerce 
		'lf_text_field_20', 
		__( '<u>WooCommerce Utility:</u><br>Set LF Container Layout width in px or % (ie: 900px or 80%)', 'lf' ), 
		array($this, 'lf_text_field_20_render'), 
		'pluginPage', 
		'lf_pluginPage_section' 
	);

	add_settings_field( // Force WooCommerce Default Layout Into One Column
		'lf_checkbox_field_11', 
		__( '<u>WooCommerce Utility:</u><br/>Force WooCommerce Default Layout Into One Column', 'lf' ), 
		array($this, 'lf_checkbox_field_11_render'), 
		'pluginPage', 
		'lf_pluginPage_section' 
	);

	add_settings_field( // Redirect To Checkout After Adding Any Product To Cart
		'lf_checkbox_field_12', 
		__( '<u>WooCommerce Utility:</u><br/>Redirect To Checkout After Adding Any Product To Cart', 'lf' ), 
		array($this, 'lf_checkbox_field_12_render'), 
		'pluginPage', 
		'lf_pluginPage_section' 
	);

	add_settings_field( // Disable links to product details pages
		'lf_checkbox_field_4', 
		__( '<u>WooCommerce Utility:</u><br/>Disable All Links Back To Single Product Pages', 'lf' ), 
		array($this, 'lf_checkbox_field_4_render'), 
		'pluginPage', 
		'lf_pluginPage_section' 
	);

	add_settings_field( // Hide View Cart Notice After Adding Any Product To Cart
		'lf_checkbox_field_6', 
		__( '<u>WooCommerce Utility:</u><br/>Hide "View Cart" After Adding Any Product Added To Cart', 'lf' ), 
		array($this, 'lf_checkbox_field_6_render'), 
		'pluginPage', 
		'lf_pluginPage_section' 
	);

	add_settings_field( // Hide Free Orders In My Account and Admin Edit Order
		'lf_checkbox_field_3', 
		__( '<u>Hide All Free Orders From Admin/Buyers</u><br/>Admin can filter to view, buyers see nothing', 'lf' ), 
		array($this, 'lf_checkbox_field_3_render'), 
		'pluginPage', 
		'lf_pluginPage_section' 
	);


	add_settings_field( // Disable Order Emails When Cart Value Is Zero
		'lf_checkbox_field_2', 
		__( '<u>Disable Free Order Emails:</u><br/>Buyers will not receive email for any free orders', 'lf' ), 
		array($this, 'lf_checkbox_field_2_render'), 
		'pluginPage', 
		'lf_pluginPage_section' 
	);

	add_settings_field( // Allow Only One Product In Cart At A Time
		'lf_checkbox_field_1', 
		__( '<u>Solo Checkout For All Products:</u><br/>Only Allow One Product In Checkout At A Time', 'lf' ), 
		array($this, 'lf_checkbox_field_1_render'), 
		'pluginPage', 
		'lf_pluginPage_section' 
	);

	add_settings_field( // Allow Only One Product In Cart At A Time
		'lf_checkbox_field_5', 
		__( '<u>Use Email For Username:</u><br/>When registering new user with WooCommerce.', 'lf' ), 
		array($this, 'lf_checkbox_field_5_render'), 
		'pluginPage', 
		'lf_pluginPage_section' 
	);	

}


/**
	 * Adds Admin Page Fields
	 *
	 * @since 4.0.8
	 *
	 * @return void
	 */


public function lf_checkbox_field_1_render(  ) { // One Proudct In Checkout

	$options = get_option( 'lf_settings' );
	?>
	<input type='checkbox' name='lf_settings[lf_checkbox_field_1]' <?php checked( isset($options['lf_checkbox_field_1']), 1 ); ?> value='1'>
	<?php

}

public function lf_checkbox_field_2_render(  ) { // Disable Order Emails When Cart Value Is Zero
	$options = get_option( 'lf_settings' );
	?>
	<input type='checkbox' name='lf_settings[lf_checkbox_field_2]' <?php checked( isset($options['lf_checkbox_field_2']), 1 ); ?> value='1'>
	<?php

}


public function lf_checkbox_field_3_render(  ) { // Hide Free Orders In My Account and Admin Edit Order
	$options = get_option( 'lf_settings' );
	?>
	<input type='checkbox' name='lf_settings[lf_checkbox_field_3]' <?php checked( isset($options['lf_checkbox_field_3']), 1 ); ?> value='1'>
	<?php

}

public function lf_checkbox_field_4_render(  ) { // Disable links to product details pages
	$options = get_option( 'lf_settings' );
	?>
	<input type='checkbox' name='lf_settings[lf_checkbox_field_4]' <?php checked( isset($options['lf_checkbox_field_4']), 1 ); ?> value='1'>
	<?php

}

public function lf_checkbox_field_5_render(  ) { // User Email For Username When Registering With WooCommerce
	$options = get_option( 'lf_settings' );
	?>
	<input type='checkbox' name='lf_settings[lf_checkbox_field_5]' <?php checked( isset($options['lf_checkbox_field_5']), 1 ); ?> value='1'>
	<?php

}

public function lf_checkbox_field_6_render(  ) { // Hide View Cart Message After Adding Any Product To Cart
	$options = get_option( 'lf_settings' );
	?>
	<input type='checkbox' name='lf_settings[lf_checkbox_field_6]' <?php checked( isset($options['lf_checkbox_field_6']), 1 ); ?> value='1'>
	<?php

}


public function lf_text_field_1_render(  ) {  // Change Checkout Button Text (Global) When Cart Value Is Zero

	$options = get_option( 'lf_settings' );
	?>
	<input type='text' name='lf_settings[lf_text_field_1]' value='<?php echo $options['lf_text_field_1']; ?>'>
	<?php

}

public function lf_text_field_2_render(  ) {  // Change Checkout Button Text (Global) When Cart Value Is Zero

	$options = get_option( 'lf_settings' );
	?>
	<input type='text' name='lf_settings[lf_text_field_2]' value='<?php echo $options['lf_text_field_2']; ?>'>
	<?php

}

public function lf_text_field_3_render(  ) {  // Change Checkout Button Text (Global) When Cart Value Is Zero

	$options = get_option( 'lf_settings' );
	?>
	<input type='text' name='lf_settings[lf_text_field_3]' value='<?php echo $options['lf_text_field_3']; ?>'>
	<?php

}

public function lf_text_field_20_render(  ) {  // Set Default Width in px for LaunchFlows Container Template
	$options = get_option( 'lf_settings' );
	?>
	<input type='text' name='lf_settings[lf_text_field_20]' value='<?php echo $options['lf_text_field_20']; ?>'>
	<?php

}

public function lf_checkbox_field_11_render(  ) { // Force WooCommerce Layout Into One Column
	$options = get_option( 'lf_settings' );
	?>
	<input type='checkbox' name='lf_settings[lf_checkbox_field_11]' <?php checked( isset($options['lf_checkbox_field_11']), 1 ); ?> value='1'>
	<?php

}

public function lf_checkbox_field_12_render(  ) { // Redirect To Checkout After Adding Any Product To Cart
	$options = get_option( 'lf_settings' );
	?>
	<input type='checkbox' name='lf_settings[lf_checkbox_field_12]' <?php checked( isset($options['lf_checkbox_field_12']), 1 ); ?> value='1'>
	<?php

}


public function lf_settings_section_woocommerce (  ) { 
//	echo __( 'WooCommerce Utilities', 'lf' );
}


public function lf_options_page(  ) { //outputs the page contents
		?>
		<form id="launchflows" action='options.php' method='post'>

			<h1>LaunchFlows</h1>

			<?php
			settings_fields( 'pluginPage' );
			do_settings_sections( 'pluginPage' );
			submit_button();
			?>

		</form>
		<?php
}



/**
	 * Adds Admin Page Callback Logic
	 *
	 * @since 1.0.15
	 *
	 * @return void
	 */

public function lf_apply_settings() {
  $options = get_option( 'lf_settings' );


// Only Allow One Prouduct In Cart At A Time
  	if( isset($options['lf_checkbox_field_1']) && $options['lf_checkbox_field_1'] == '1' ) { 

    add_filter( 'woocommerce_add_to_cart_validation', 'lf_only_one_product_in_cart', 99, 2 );

  	} 


// Disable Order Email Notifications (Buyer/Admin) For Free Orders (*Works)
	if( isset($options['lf_checkbox_field_2']) && $options['lf_checkbox_field_2'] == '1' ) { 

	// completed
	add_filter( 'woocommerce_email_recipient_customer_completed_order', 'lf_disable_free_order_email', 10, 2 );

	// processing
	add_filter( 'woocommerce_email_recipient_customer_processing_order', 'lf_disable_free_order_email', 10, 2 );

	// admin new order email
	add_filter( 'woocommerce_email_recipient_new_order', 'lf_disable_free_order_email', 10, 2 );

	}


// Disable Visibility For Free Products To Admin/Buyers
	if( isset($options['lf_checkbox_field_3']) && $options['lf_checkbox_field_3'] == '1' ) { 

	// buyers
	add_filter( 'woocommerce_my_account_my_orders_query', 'lf_hide_free_orders_my_account', 10, 1 ); 

	// admin

    add_action( 'restrict_manage_posts', 'lf_restrict_orders', 50 );

    add_filter( 'request', 'lf_orders_by_restrict_option', 100 );

	}

// Disable Product Links In Cart, Thank You Pages & Emails
	if( isset($options['lf_checkbox_field_4']) && $options['lf_checkbox_field_4'] == '1' ) { 

	// remove the filter 
	add_filter( 'woocommerce_order_item_permalink', '__return_false' ); // thank you pages and emails

	add_filter( 'woocommerce_cart_item_permalink', '__return_null' ); // in the cart

	}

// Use Email For Username When Registering With WooCommerce
	if( isset($options['lf_checkbox_field_5']) && $options['lf_checkbox_field_5'] == '1' ) { 

	add_filter( 'woocommerce_new_customer_data', function( $data ) {
		
		$data['user_login'] = $data['user_email'];

		return $data;

		} );

	}

// Hide View Cart Notice After Product Is Added (useful for shop pages)
  	if( isset($options['lf_checkbox_field_6']) && $options['lf_checkbox_field_6'] == '1' ) { 

    add_filter( 'wc_add_to_cart_message_html', '__return_null' );  	

 	}


// Force WooCommerce Default Layout To One Column
  	if( isset($options['lf_checkbox_field_11']) && $options['lf_checkbox_field_11'] == '1' ) { 

		//apply css if wc checkout page 
  		add_action('lf_content','lf_force_full_width_checkout');
  		function lf_force_full_width_checkout(){
  			$classes = get_body_class();
			if (in_array('woocommerce-checkout',$classes)) {
	?>

		  	<style>
		  	#order_main_wrap,
		  	#order_review_wrap {
		    width: 100%;
		    float: none;
			}

			form.checkout #order_review_heading, 
			form.checkout .woocommerce-checkout-review-order {
			    padding-left: 0;
			}

			</style>
<?php
 			}
		}
 	}


// Add Option To Avoid WC Redirecting Empty Checkouts To Cart Page. Show checkout page even if cart is empty.
// on by default (v1.1.9)

	add_filter( 'woocommerce_checkout_redirect_empty_cart', '__return_false' );

	add_filter( 'woocommerce_checkout_update_order_review_expired', '__return_false' ); // allows showing checkout even with empty cart

// Redirect To Checkout After Adding Any Product To Cart
	if( isset($options['lf_checkbox_field_12']) && $options['lf_checkbox_field_12'] == '1' ) { 

	add_filter( 'woocommerce_add_to_cart_redirect', 'lf_add_to_cart_redirect' );

		function lf_add_to_cart_redirect() {

   			return wc_get_checkout_url();
		}

	}


return;
} // end lf_apply_settings



/**
 * Initialize the appsero plugin tracker
 *
 * @since 2.0.8
 *
 * @return void
 */

public function appsero_init_tracker_launchflows() {

    if ( ! class_exists( 'Appsero\Client' ) ) {
      require_once( 'includes/appsero/src/Client.php' );
    }

   
   $client = new Appsero\Client( '5df4ac48-6395-4729-b1b1-fece6296d84e', 'LaunchFlows (Single Site)', __FILE__ );

   //$client = new Appsero\Client( '7a4ac752-f2a5-4764-afbd-4c34250b2418', 'LaunchFlows (Unlimited Sites)', __FILE__ );

   //$client = new Appsero\Client( '845512e6-5546-4d95-8d26-9c5580fb49c0', 'LaunchFlows (Lifetime)', __FILE__ );


    // Active insights
    $client->insights()->init();

    // Active automatic updater
    $client->updater();

    // Active license page and checker
    $args = array(
            'type'        => 'submenu',
            'menu_title'  => 'License',
            'capability'  => 'manage_options',
            'menu_slug'   => 'launchflows_license',
            'parent_slug' => 'launchflows',
    );

    $client->license()->add_settings_page( $args );

}




} // end of LaunchFlows Class
// Instantiate LaunchFlows Class
new LaunchFlows();