<div class="wrap">
    <div class="eg-header-wrap">
        
    </div>