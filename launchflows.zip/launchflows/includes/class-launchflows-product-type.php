<?php

/**
   * Discover if single product type is set to simple, to hide LF checkout link metabox
   *
   * //ibenic.com/custom-woocommerce-product-type/
   * @since 1.2.2
   *
   * @return void
   */

class LF_Product_Type_Plugin {

    /**
     * Build the instance
     */
    public function __construct() {
        // hook on to admin footer since this runs within a class it wont collide
        add_action( 'admin_footer', array( $this, 'enable_js_on_wc_product' ) );
    }
    
    public function enable_js_on_wc_product() {
      global $post, $product_object;

      if ( ! $post ) { return; }

      if ( 'product' != $post->post_type ) :
	return;
      endif;
      // set variable to the 'simple' type from product_object
      $is_simple = $product_object && 'simple' === $product_object->get_type() ? true : false;

      ?>
      <script type='text/javascript'>
        jQuery(document).ready(function () {
          //for Price tab
          jQuery('#lf-direct-checkout-link').addClass('show_if_simple');

          <?php if ( $is_simple ) { ?>
            jQuery('#lf-direct-checkout-link').show();
          <?php } ?>
         });
       </script>
       <?php
     }
    // ...
}

new LF_Product_Type_Plugin();