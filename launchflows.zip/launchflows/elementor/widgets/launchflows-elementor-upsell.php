<?php
namespace LaunchFlowsElementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * LaunchFlows Elementor
 *
 * Elementor widget for LaunchFlows
 *
 * @since 1.0.0
 */
class LaunchFlowsElementorUpsell extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'lf-upsell';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'LaunchFlows Upsell', 'lf' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-upload-circle-o';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.2.2
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'launchflows'];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'lf' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 3.2.2
	 *
	 * @access protected
	 */

	protected function _register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'lf' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'content',
			[
				'label' => __( 'Select Component To Add:', 'lf' ),
				'type' => Controls_Manager::HIDDEN,
				'default' => '[lf-upsell]',
			]

		);		


		$this->add_control(
			'product',
			[
				'label' => __( 'Accept Product ID:', 'lf' ),
				'type' => Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'eg: 12345', 'lf' ),	
			]
		);
		$this->add_control(
			'accept',
			[
				'label' => __( 'Accept Text:', 'lf' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'eg: YES, I WANT IT!', 'lf' ), 
			]
		);

// only show if WPFusion exists
if (class_exists('WP_Fusion')) {
		$this->add_control(
			'accept_tags',
			[
				'label' => __( 'Accept Tags (WPFusion):', 'lf' ),
				'type' => Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'comma separate', 'lf' ),	
			]
		);
}

		$this->add_control(
			'after_accept_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);	

		$this->add_control(
			'next',
			[
				'label' => __( 'Decline Page ID:', 'lf' ),
				'type' => Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'eg: 12345', 'lf' ),
	
			]
		);

		$this->add_control(
			'decline',
			[
				'label' => __( 'Decline Text:', 'lf' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'eg: No Thanks, I\'ll pass.', 'lf' ),
			]
		);
// only show if WPFusion exists
if (class_exists('WP_Fusion')) {		
		$this->add_control(
			'decline_tags',
			[
				'label' => __( 'Decline Tags (WPFusion):', 'lf' ),
				'type' => Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'comma separate', 'lf' ),	
			]
		);
}

		$this->add_control(
			'after_decline_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);	
		$this->add_control(
			'hide_image',
			[
				'label' => __( 'Hide Image', 'lf' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Hide', 'lf' ),
				'label_off' => __( 'Show', 'lf' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);

		$this->add_control(
			'hide_title',
			[
				'label' => __( 'Hide Title', 'lf' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Hide', 'lf' ),
				'label_off' => __( 'Show', 'lf' ),
				'return_value' => 'yes',
				'default' => 'no',			
			]
		);
		$this->add_control(
			'hide_price',
			[
				'label' => __( 'Hide Price', 'lf' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Hide', 'lf' ),
				'label_off' => __( 'Show', 'lf' ),
				'return_value' => 'yes',
				'default' => 'no',			
			]
		);
		$this->add_control(
			'hide_accept',
			[
				'label' => __( 'Hide Accept Button', 'lf' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Hide', 'lf' ),
				'label_off' => __( 'Show', 'lf' ),
				'return_value' => 'yes',
				'default' => 'no',			
			]
		);
		$this->add_control(
			'hide_decline',
			[
				'label' => __( 'Hide Decline Link', 'lf' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Hide', 'lf' ),
				'label_off' => __( 'Show', 'lf' ),
				'return_value' => 'yes',
				'default' => 'no',			
			]
		);

$this->end_controls_section();
/* start product image */
		$this->start_controls_section(
			'upsell_image',
			[
				'label' => __( 'Upsell Image', 'lf-upsell-widget' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'upsell_product_image_width',
			[
				'label' => __( 'Upsell Image Width', 'lf-upsell-widget' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1400,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 500,
				],
				'selectors' => [
					'{{WRAPPER}} .upsell-image' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);


$this->end_controls_section();


// upsell title
$this->start_controls_section(
			'upsell_product_title',
			[
				'label' => __( 'Upsell Title', 'lf-upsell-widget' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


	$this->start_controls_tabs(
			'style_tabs_title'
		);

		$this->start_controls_tab(
			'style_normal_tab_title',
			[
				'label' => __( 'Normal', 'lf-upsell-widget' ),
			]
		);

				// title - normal tab
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name'					=> 'upsell_title_typography_normal',
						'label'					=> __( 'Typography', 'lf-upsell-widget' ),
						'selector'				=> '{{WRAPPER}} .upsell-title'
					]
				);
				$this->add_control(
					'upsell_title_text_color',
					[
						'label' => __( 'Text Color', 'lf-upsell-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .upsell-title' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'upsell_title_background_color',
					[
						'label' => __( 'Background Color', 'lf-upsell-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .upsell-title' => 'background-color: {{VALUE}};',
							'{{WRAPPER}} .upsell-title::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
						],
					]
				);

				$this->add_responsive_control(
					'upsell_title_margin_normal',
					[
						'label' => __( 'Margin', 'lf-upsell-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'allowed_dimensions' => 'vertical',
						'selectors' => [
							'{{WRAPPER}} .upsell-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'upsell_title_padding_normal',
					[
						'label' => __( 'Padding', 'lf-upsell-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'selectors' => [
							'{{WRAPPER}} .upsell-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_control(
					'hr_title_normal',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);	
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'upsell_title_border_normal',
						'label' => __( 'Border', 'lf-upsell-widget' ),
						'selector' => '{{WRAPPER}} .upsell-title',
					]
				);
				$this->add_responsive_control(
					'upsell_title_border_radius_normal',
					[
						'label' => __( 'Border Radius', 'lf-upsell-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .upsell-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);	

				$this->add_control(
					'hr_title_after_border_normal',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);	

		$this->end_controls_tab();


		// title - hover tab
		$this->start_controls_tab(
			'style_tab_title_hover',
			[
				'label' => __( 'Hover', 'lf-upsell-widget' ),
			]
		);

				$this->add_group_control(
					Group_Control_Typography::get_type(),
					[
						'name'					=> 'upsell_title_typography_hover',
						'label'					=> __( 'Typography', 'lf-upsell-widget' ),
						'selector'				=> '{{WRAPPER}} .upsell-title'
					]
				);
				
				$this->add_control(
					'upsell_title_text_color_hover',
					[
						'label' => __( 'Text Color', 'lf-upsell-widget' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .upsell-title:hover' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'upsell_title_background_color_hover',
					[
						'label' => __( 'Background Color', 'lf-upsell-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .upsell-title:hover' => 'background-color: {{VALUE}};',
							'{{WRAPPER}} .upsell-title:hover::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
						],
					]
				);
				$this->add_control(
					'hr_title_hover',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);					
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'upsell_title_border_hover',
						'label' => __( 'Border', 'lf-upsell-widget' ),
						'selector' => '{{WRAPPER}} .upsell-title:hover',
					]
				);

				$this->add_responsive_control(
					'upsell_title_border_radius_hover',
					[
						'label' => __( 'Border Radius', 'lf-upsell-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .upsell-title:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);	


		$this->end_controls_tab();

	$this->end_controls_tabs();

$this->end_controls_section();
/* title end */


// upsell price
$this->start_controls_section(
			'upsell_product_price_normal',
			[
				'label' => __( 'Upsell Price', 'lf-upsell-widget' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


	$this->start_controls_tabs(
			'style_tabs_pric_normale'
		);

		$this->start_controls_tab(
			'style_normal_tab_price_normal',
			[
				'label' => __( 'Normal', 'lf-upsell-widget' ),
			]
		);

				// price - normal tab
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name'					=> 'upsell_price_typography_normal',
						'label'					=> __( 'Typography', 'lf-upsell-widget' ),
						'selector'				=> '{{WRAPPER}} .upsell-price'
					]
				);
				$this->add_control(
					'upsell_price_text_color_normal',
					[
						'label' => __( 'Text Color', 'lf-upsell-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .upsell-price' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'upsell_price_background_color_normal',
					[
						'label' => __( 'Background Color', 'lf-upsell-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .upsell-price' => 'background-color: {{VALUE}};',
							'{{WRAPPER}} .upsell-price::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
						],
					]
				);

				$this->add_responsive_control(
					'upsell_price_margin_normal',
					[
						'label' => __( 'Margin', 'lf-upsell-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'allowed_dimensions' => 'vertical',
						'selectors' => [
							'{{WRAPPER}} .upsell-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'upsell_price_padding_normal',
					[
						'label' => __( 'Padding', 'lf-upsell-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'selectors' => [
							'{{WRAPPER}} .upsell-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_control(
					'hr_price_normal',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);	
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'upsell_price_border_normal',
						'label' => __( 'Border', 'lf-upsell-widget' ),
						'selector' => '{{WRAPPER}} .upsell-price',
					]
				);
				$this->add_responsive_control(
					'upsell_price_border_radius_normal',
					[
						'label' => __( 'Border Radius', 'lf-upsell-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .upsell-price' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);	

				$this->add_control(
					'hr_upsell_price_border_normal',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);	

		$this->end_controls_tab();


		// price - hover tab
		$this->start_controls_tab(
			'style_tab_price_hover',
			[
				'label' => __( 'Hover', 'lf-upsell-widget' ),
			]
		);

				$this->add_group_control(
					Group_Control_Typography::get_type(),
					[
						'name'					=> 'upsell_price_typography_hover',
						'label'					=> __( 'Typography', 'lf-upsell-widget' ),
						'selector'				=> '{{WRAPPER}} .upsell-price'
					]
				);
				
				$this->add_control(
					'upsell_price_text_color_hover',
					[
						'label' => __( 'Text Color', 'lf-upsell-widget' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .upsell-price:hover' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'upsell_price_background_color_hover',
					[
						'label' => __( 'Background Color', 'lf-upsell-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .upsell-price:hover' => 'background-color: {{VALUE}};',
							'{{WRAPPER}} .upsell-price:hover::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
						],
					]
				);
				$this->add_control(
					'hr_price_hover',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);					
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'upsell_price_border_hover',
						'label' => __( 'Border', 'lf-upsell-widget' ),
						'selector' => '{{WRAPPER}} .upsell-price:hover',
					]
				);

				$this->add_responsive_control(
					'upsell_price_border_radius_hover',
					[
						'label' => __( 'Border Radius', 'lf-upsell-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .upsell-price:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);	


		$this->end_controls_tab();

	$this->end_controls_tabs();

$this->end_controls_section();
/* price end */

// upsell accept
$this->start_controls_section(
			'upsell_product_accept_normal',
			[
				'label' => __( 'Upsell Accept', 'lf-upsell-widget' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


	$this->start_controls_tabs(
			'style_tabs_accept_normal'
		);

		$this->start_controls_tab(
			'style_normal_tab_accept_normal',
			[
				'label' => __( 'Normal', 'lf-upsell-widget' ),
			]
		);

				// accept - normal tab
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name'					=> 'upsell_accept_typography_normal',
						'label'					=> __( 'Typography', 'lf-upsell-widget' ),
						'selector'				=> '{{WRAPPER}} .upsell-accept'
					]
				);
				$this->add_control(
					'upsell_accept_text_color_normal',
					[
						'label' => __( 'Text Color', 'lf-upsell-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .upsell-accept' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'upsell_accept_background_color_normal',
					[
						'label' => __( 'Background Color', 'lf-upsell-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .upsell-accept' => 'background-color: {{VALUE}};',
							'{{WRAPPER}} .upsell-accept::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
						],
					]
				);

				$this->add_responsive_control(
					'upsell_accept_margin_normal',
					[
						'label' => __( 'Margin', 'lf-upsell-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'allowed_dimensions' => 'vertical',
						'selectors' => [
							'{{WRAPPER}} .upsell-accept' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'upsell_accept_padding_normal',
					[
						'label' => __( 'Padding', 'lf-upsell-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'selectors' => [
							'{{WRAPPER}} .upsell-accept' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);

				$this->add_control(
					'upsell_accept_max_width_normal',
					[
						'label' => __( 'Max Width', 'lf-upsell-widget' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => [ 'px', '%' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 1400,
								'step' => 5,
							],
							'%' => [
								'min' => 0,
								'max' => 100,
							],
						],
						'default' => [
							'unit' => 'px',
							'size' => 200,
						],
						'selectors' => [
							'{{WRAPPER}} .upsell-accept' => 'width: {{SIZE}}{{UNIT}};',
						],
					]
				);

				$this->add_control(
					'hr_upsell_accept_max_width_normal',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);	
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'upsell_accept_border_normal',
						'label' => __( 'Border', 'lf-upsell-widget' ),
						'selector' => '{{WRAPPER}} .upsell-accept',
					]
				);
				$this->add_responsive_control(
					'upsell_accept_border_radius_normal',
					[
						'label' => __( 'Border Radius', 'lf-upsell-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .upsell-accept' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);	

				$this->add_control(
					'hr_upsell_accept_border_radius_normal',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);	

		$this->end_controls_tab();


		// accept - hover tab
		$this->start_controls_tab(
			'style_tab_accept_hover',
			[
				'label' => __( 'Hover', 'lf-upsell-widget' ),
			]
		);

				$this->add_group_control(
					Group_Control_Typography::get_type(),
					[
						'name'					=> 'upsell_accept_typography_hover',
						'label'					=> __( 'Typography', 'lf-upsell-widget' ),
						'selector'				=> '{{WRAPPER}} .upsell-accept'
					]
				);
				
				$this->add_control(
					'upsell_accept_text_color_hover',
					[
						'label' => __( 'Text Color', 'lf-upsell-widget' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .upsell-accept:hover' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'upsell_accept_background_color_hover',
					[
						'label' => __( 'Background Color', 'lf-upsell-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .upsell-accept:hover' => 'background-color: {{VALUE}};',
							'{{WRAPPER}} .upsell-accept:hover::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
						],
					]
				);
				$this->add_control(
					'hr_accept_hover',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);					
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'upsell_accept_border_hover',
						'label' => __( 'Border', 'lf-upsell-widget' ),
						'selector' => '{{WRAPPER}} .upsell-accept:hover',
					]
				);

				$this->add_responsive_control(
					'upsell_accept_border_radius_hover',
					[
						'label' => __( 'Border Radius', 'lf-upsell-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .upsell-accept:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);	


		$this->end_controls_tab();

	$this->end_controls_tabs();

$this->end_controls_section();
/* accept end */


// upsell decline
$this->start_controls_section(
			'upsell_product_decline_normal',
			[
				'label' => __( 'Upsell Decline', 'lf-upsell-widget' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


	$this->start_controls_tabs(
			'style_tabs_decline'
		);

		$this->start_controls_tab(
			'style_tab_decline_normal',
			[
				'label' => __( 'Normal', 'lf-upsell-widget' ),
			]
		);

				// decline - normal tab
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name'					=> 'upsell_decline_typography_normal',
						'label'					=> __( 'Typography', 'lf-upsell-widget' ),
						'selector'				=> '{{WRAPPER}} .upsell-decline'
					]
				);
				$this->add_control(
					'upsell_decline_text_color_normal',
					[
						'label' => __( 'Text Color', 'lf-upsell-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .upsell-decline' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'upsell_decline_background_color_normal',
					[
						'label' => __( 'Background Color', 'lf-upsell-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .upsell-decline' => 'background-color: {{VALUE}};',
							'{{WRAPPER}} .upsell-decline::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
						],
					]
				);

				$this->add_responsive_control(
					'upsell_decline_margin_normal',
					[
						'label' => __( 'Margin', 'lf-upsell-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'allowed_dimensions' => 'vertical',
						'selectors' => [
							'{{WRAPPER}} .upsell-decline' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'upsell_decline_padding_normal',
					[
						'label' => __( 'Padding', 'lf-upsell-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'selectors' => [
							'{{WRAPPER}} .upsell-decline' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_control(
					'hr_decline_padding_normal',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);	
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'upsell_decline_border_normal',
						'label' => __( 'Border', 'lf-upsell-widget' ),
						'selector' => '{{WRAPPER}} .upsell-decline',
					]
				);
				$this->add_responsive_control(
					'upsell_decline_border_radius_normal',
					[
						'label' => __( 'Border Radius', 'lf-upsell-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .upsell-decline' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);	

				$this->add_control(
					'hr_decline_border_radius_normal',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);	

		$this->end_controls_tab();


		// decline - hover tab
		$this->start_controls_tab(
			'style_tab_decline_hover',
			[
				'label' => __( 'Hover', 'lf-upsell-widget' ),
			]
		);

				$this->add_group_control(
					Group_Control_Typography::get_type(),
					[
						'name'					=> 'upsell_decline_typography_hover',
						'label'					=> __( 'Typography', 'lf-upsell-widget' ),
						'selector'				=> '{{WRAPPER}} .upsell-decline'
					]
				);
				
				$this->add_control(
					'upsell_decline_text_color_hover',
					[
						'label' => __( 'Text Color', 'lf-upsell-widget' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .upsell-decline:hover' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'upsell_decline_background_color_hover',
					[
						'label' => __( 'Background Color', 'lf-upsell-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .upsell-decline:hover' => 'background-color: {{VALUE}};',
							'{{WRAPPER}} .upsell-decline:hover::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
						],
					]
				);
				$this->add_control(
					'hr_decline_hover',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);					
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'upsell_decline_border_hover',
						'label' => __( 'Border', 'lf-upsell-widget' ),
						'selector' => '{{WRAPPER}} .upsell-decline:hover',
					]
				);

				$this->add_responsive_control(
					'upsell_decline_border_radius_hover',
					[
						'label' => __( 'Border Radius', 'lf-upsell-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .upsell-decline:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);	


		$this->end_controls_tab();

	$this->end_controls_tabs();

$this->end_controls_section();
/* decline end */

// end
	}



/**
	 * Render CSS Style
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */

   public function __construct($data = [], $args = null) {
      parent::__construct($data, $args);
      wp_register_style( 'lf-elementor', LF_DIR_URL . 'elementor/css/launchflows-elementor.css', false, '1.0.0');
   }

  public function get_style_depends() {
     return [ 'lf-elementor' ];
  }

/**
	 * Render shortcode widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */

	protected function render() {

		$settings = $this->get_settings_for_display();

		$content = $this->get_settings( 'content' );
		
		$product = $this->get_settings( 'product' );

		$next = $this->get_settings( 'next' );

		$accept = $this->get_settings( 'accept' );

		$accept_tags = $this->get_settings( 'accept_tags' );

		$decline = $this->get_settings( 'decline' );

		$decline_tags = $this->get_settings( 'decline_tags' );

		$field_text = $this->get_settings( 'field_text' );

		$button_text = $this->get_settings( 'button_text' );

		$hide_image = $this->get_settings( 'hide_image' );
	
		$hide_title = $this->get_settings( 'hide_title' );
	
		$hide_price = $this->get_settings( 'hide_price' );

		$hide_accept = $this->get_settings( 'hide_accept' );

		$hide_decline = $this->get_settings( 'hide_decline' );

		$checkbox_style = $this->get_settings( 'checkbox_style' );

		$css = trim($content, "[]");

		if ( 'yes' === $hide_image ) {
		
			$upsell_image = 'image="no"';
		
		} else {

			$upsell_image = '';
		}	


		if ( 'yes' === $hide_title ) {
		
			$upsell_title = 'title="no"';
		
		} else {

			$upsell_title = '';
		}	

		if ( 'yes' === $hide_price ) {
		
			$upsell_price = 'price="no"';
		
		} else {

			$upsell_price = '';
		}	

		if ( 'yes' === $hide_accept ) {
		
			$hide_accept = 'a.upsell-accept.button{display:none;}';
		
		} else {

			$hide_accept = '';
		}	

		if ( 'yes' === $hide_decline ) {
		
			$hide_decline = 'a.upsell-decline{display:none;}';
		
		} else {

			$hide_decline = '';
		}	

		if ('' === $accept) {

			$accept = __( 'YES, I WANT IT!', 'lf' );
		}

		if ($accept_tags !==''){

			$accept_apply_tags = 'accept_tags="'.$accept_tags.'"';

		} else {

			$accept_apply_tags = '';
		}

		if ('' === $decline) {

			$decline = __( 'No Thanks, I\'ll pass.', 'lf' );
		}

		if ($decline_tags !==''){

			$decline_apply_tags = 'decline_tags="'.$decline_tags.'"';

		} else {

			$decline_apply_tags = '';
		}

		// build shortcode for upsell product
		if ($product !=='') {

			$content = '['.$css .' product="'. $product.'" next="'. $next .'" accept="'.$accept.'" decline="'.$decline.'" '.$upsell_title.' '.$upsell_image.' '.$upsell_price.' '.$accept_apply_tags.' '.$decline_apply_tags.']';

		}

		// output final string as new shortcode
		$shortcode = do_shortcode( shortcode_unautop( $content ) );
	
		// For Testing Shortcode Output
		//echo $content;	


		// displays shortcode syntax only in admin editor, not on front end
		if( is_admin() ) {  
			?>
			<div id="<?php echo $css; ?>" class="admin-only">
				<div></div> 

			</div> 
			<?php 
		} 


		// outputs shortcode to front
		?>
		<div class="lf-shortcode" >
		<style><?php echo $hide_accept; ?><?php echo $hide_decline; ?></style>
		<?php echo $shortcode; ?>
		</div>
		<?php


 		

	}

//end	
}