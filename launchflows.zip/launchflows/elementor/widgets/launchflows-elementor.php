<?php
namespace LaunchFlowsElementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * LaunchFlows Elementor
 *
 * Elementor widget for LaunchFlows
 *
 * @since 1.0.0
 */
class LaunchFlowsElementor extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'lf';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'LaunchFlows Misc.', 'lf' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-share';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.2.2
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'launchflows'];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'lf' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 3.2.2
	 *
	 * @access protected
	 */

	protected function _register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'lf' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'content',
			[
				'label' => __( 'Select Component To Add:', 'lf' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					'    ' 						=> __( '= OTHER CHECKOUT FIELDS =', 'lf' ),
					'     '						=> __( '  ', 'lf'),

					'[lf-cart-discount]' 		=> __( 'Fields - Cart Discount', 'lf'),
					'[lf-subtotal]' 			=> __( 'Fields - Subtotal', 'lf' ),
					'[lf-tax-rate]' 			=> __( 'Fields - Tax Rate', 'lf' ),
					'[lf-total]' 				=> __( 'Fields - Total', 'lf' ),
					'[lf-total-shipping]' 		=> __( 'Fields - Total Shipping', 'lf' ),
					'[lf-user-avatar]' 			=> __( 'Fields - User Avatar' ),
					'[lf-product-add-to-cart]' => __( 'Product - Add To Cart' ),
				],
			]

		);		


		$this->add_control(
			'product',
			[
				'label' => __( 'Product ID:', 'lf' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'eg: 12345', 'lf' ),

				// only show this control if (dropdown) options control is set to 'lf-price-slider'
				// letswp.io/conditional-controls-in-elementor-extensions/
				'conditions' => [
    			    'relation' => 'or',
				    'terms' => [
				        [
				            'name' => 'content',
				            'operator' => '==',
				            'value' => ['[lf-price-slider]']
				        ],
				        [
				            'name' => 'content',
				            'operator' => '==',
				            'value' => ['[lf-bump]']
				        ],
				        [
				            'name' => 'content',
				            'operator' => '==',
				            'value' => ['[lf-always-in]']
				        ],
				        [
				            'name' => 'content',
				            'operator' => '==',
				            'value' => ['[lf-donation]']
				        ],
				    ]
				]
	
			]
		);

		$this->add_control(
			'hide_image',
			[
				'label' => __( 'Hide Image', 'lf' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Hide', 'lf' ),
				'label_off' => __( 'Show', 'lf' ),
				'return_value' => 'yes',
				'default' => 'no',
				// letswp.io/conditional-controls-in-elementor-extensions/
				'conditions' => [
    			    'relation' => 'or',
				    'terms' => [
				        [
				            'name' => 'content',
				            'operator' => '==',
				            'value' => ['[lf-bump]']
				        ],
				    ]
				]				
			]
		);

		$this->add_control(
			'hide_title',
			[
				'label' => __( 'Hide Title', 'lf' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Hide', 'lf' ),
				'label_off' => __( 'Show', 'lf' ),
				'return_value' => 'yes',
				'default' => 'no',
				// letswp.io/conditional-controls-in-elementor-extensions/
				'conditions' => [
    			    'relation' => 'or',
				    'terms' => [
				        [
				            'name' => 'content',
				            'operator' => '==',
				            'value' => ['[lf-bump]']
				        ],
				    ]
				]				
			]
		);

		$this->add_control(
			'checkbox_style',
			[
				'label' => __( 'Checkbox Style: Square or Circle', 'lf' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Circle', 'lf' ),
				'label_off' => __( 'Square', 'lf' ),
				'return_value' => 'p-round',
				'default' => '',
				// letswp.io/conditional-controls-in-elementor-extensions/
				'conditions' => [
    			    'relation' => 'or',
				    'terms' => [
				        [
				            'name' => 'content',
				            'operator' => '==',
				            'value' => ['[lf-bump]']
				        ],
				    ]
				]				
			]
		);

		$this->add_control(
			'button_text',
			[
				'label' => __( 'Button Text:', 'lf' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'eg: Click To Update' ),

				// only show this control if (dropdown) options control is set to 'lf-price-slider'
				// letswp.io/conditional-controls-in-elementor-extensions/
				'conditions' => [
    			    'relation' => 'or',
				    'terms' => [
				        [
				            'name' => 'content',
				            'operator' => '==',
				            'value' => ['[lf-donation]']
				        ],
				    ]
				]
	
			]
		);

		$this->add_control(
			'field_text',
			[
				'label' => __( 'Field Text:', 'lf' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'eg: Donation Amount' ),

				// only show this control if (dropdown) options control is set to 'lf-price-slider'
				// letswp.io/conditional-controls-in-elementor-extensions/
				'conditions' => [
    			    'relation' => 'or',
				    'terms' => [
				        [
				            'name' => 'content',
				            'operator' => '==',
				            'value' => ['[lf-donation]']
				        ],
				    ]
				]
	
			]
		);

		$this->end_controls_section();




// end
	}



/**
	 * Render CSS Style
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */

   public function __construct($data = [], $args = null) {
      parent::__construct($data, $args);
      wp_register_style( 'lf-elementor', LF_DIR_URL . 'elementor/css/launchflows-elementor.css', false, '1.0.0');
   }

  public function get_style_depends() {
     return [ 'lf-elementor' ];
  }

/**
	 * Render shortcode widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */

	protected function render() {

		$settings = $this->get_settings_for_display();

		// full shortcode
		$content = $this->get_settings( 'content' );
		
	    // product id from elementor field
		$product = $this->get_settings( 'product' );

	    // form field text from elementor field
		$field_text = $this->get_settings( 'field_text' );

	    // button text from elementor field
		$button_text = $this->get_settings( 'button_text' );

	    // hide title from elementor field
		$hide_image = $this->get_settings( 'hide_image' );
	
	    // hide title from elementor field
		$hide_title = $this->get_settings( 'hide_title' );
	
	    // checkbox style from elementor field
		$checkbox_style = $this->get_settings( 'checkbox_style' );

		// trim brackets from shortcode for css and string generation
		$css = trim($content, "[]");

		// check if any value in product id to merge with content
		if ($product !=='') {
			$content = '['.$css .' product='. $product.' style='. $checkbox_style.']';
		}

		// lf-bump hide image
		if ( 'yes' === $hide_image ) {
			echo '<style id="lf-bump-image">.lf-bump._'.$product.' .product-image {display: none!important;}</style>';
		}	

		// lf-bump hide title
		if ( 'yes' === $hide_title ) {
			echo '<style id="lf-bump-title">.lf-bump._'.$product.' .product-title {display: none!important;}</style>';
		}	


		// output final string as new shortcode
		$shortcode = do_shortcode( shortcode_unautop( $content ) );

		// displays shortcode syntax only in admin editor, not on front end
		if( is_admin() ) {  
			?>
			<div id="<?php echo $css; ?>" class="admin-only">
				<!--?php echo $content; ?-->
				<div></div> 
			</div> 
			<?php 
		} 

 
    // custom output for donation widget
	if ($button_text !=='' && $field_text !=='') {
	?>
	  <style>#lf-donation.admin-only {display:none;}</style>
	  <div class="lf-all">
      <div id="lf-donation">
      <div class="lf-donation">
      
      <div class="elementor-element elementor-element-lf-donation elementor-button-align-start elementor-widget elementor-widget-form" data-id="lf-donation" data-element_type="widget" id="lf-donate-id" data-widget_type="form.default">
  
  		<input size="1" type="hidden" name="form_fields[product]" id="form-field-product" class="elementor-field elementor-size-md  elementor-field-textual" value="<?php echo $product; ?>">

        <div class="elementor-widget-container">

          <div class="elementor-form-fields-wrapper elementor-labels-">

            <div class="elementor-field-type-number elementor-field-group elementor-column elementor-field-group-donate elementor-col-50">
                        
              <input type="number" name="form_fields[donate]" id="form-field-donate" class="elementor-field elementor-size-md  elementor-field-textual" placeholder="<?php echo $field_text; ?>" min="" max="">       
            
            </div>
            <div class="elementor-field-group elementor-column elementor-field-type-submit elementor-col-50">
            
              <button type="submit" class="elementor-button elementor-size-md" id="lf-donate-button">
                <span>
                  
                  <span class="elementor-button-icon"></span>

                  <span class="elementor-button-text lf-donate-button"><?php echo $button_text; ?></span>

                </span>
              </button>
          
            </div>
          
          </div>

        </div>

      </div>

	  </div>
	  </div>
	  </div>      
	<?php
	
	} else {

		// outputs shortcode to front
		?>
		<div class="lf-shortcode" >
		<?php echo $shortcode; ?>
		</div>
		<?php

	} // end else	

}

//end	
}