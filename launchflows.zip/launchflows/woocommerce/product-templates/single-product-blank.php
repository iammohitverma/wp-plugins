<?php
//echo '<h1>Using Blank Template</h1>';

// Start Logic For Product Templates


			// If Instant Checkout Is Not Selected
			global $product;

			// add scripts required by launchflows
		    do_action('lf_content');

			// wrap that loads immediately to show original product content
			echo'<div id="lf-original-product-blank" style="display:none;">';
			wc_get_template_part( 'content', 'single-product' );
			echo '</div>';
	
				echo '<style>.product{display:none}.woocommerce div.product div.summary {margin-bottom: 0;}</style>';

				//adds product class and hides until after page loads 
	

    			?>
    			<div id="lf-content-block" <?php wc_product_class( '', $product ); ?> style="display:none; width:100%; overflow:hidden;">
    			<?php 

    			// adds content area
    			echo '<div id="lf-the-content">';
     			the_content(); 
				echo '</div><!-- /#lf-the-content -->';

				echo '</div>';			


// End Logic For Product Templates