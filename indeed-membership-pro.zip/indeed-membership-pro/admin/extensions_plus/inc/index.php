<?php 
echo 'Nothing to show here!';