<?php
namespace LaunchFlowsElementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * LaunchFlows Elementor
 *
 * Elementor widget for LaunchFlows
 *
 * @since 1.0.0
 */
class LaunchFlowsElementorAutoclick extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'lf-autoclick';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'LaunchFlows Autoclick Checkout', 'lf' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-redo';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.2.2
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'launchflows'];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'lf' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 3.2.2
	 *
	 * @access protected
	 */

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'lf' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);


			$this->add_control(
				'content',
				[
					'label' => __( 'Select Component To Add:', 'lf' ),
					'type' => Controls_Manager::HIDDEN,
					'default' => '[lf-autoclick]',
				]

			);	

		$this->add_control(
			'important_note',
			[
				'label' =>'<p style="line-height:1.4em">'. __( 'Note:</p>', 'lf' ).'</p>',
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw' =>'<p style="line-height:1.4em">'. __( 'Please be sure you have a visible checkout button on the page!', 'lf' ).'</p>',
			]
		);				

		$this->end_controls_section();


	} // end method



/**
	 * Render CSS Style
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */

   public function __construct($data = [], $args = null) {
      parent::__construct($data, $args);
      wp_register_style( 'lf-elementor', LF_DIR_URL . 'elementor/css/launchflows-elementor.css', false, '1.0.0');
   }

  public function get_style_depends() {
     return [ 'lf-elementor' ];
  }

/**
	 * Render shortcode widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 3.2.2
	 * @access protected
	 */

	protected function render() {

		$settings = $this->get_settings_for_display();

		// full shortcode
		$content = $this->get_settings( 'content' );

	    // hide title from elementor field
		$hide_content = $this->get_settings( 'hide_content' );
	
	    // hide title from elementor field
		$new_title = $this->get_settings( 'new_title' );

		// trim brackets from shortcode for css and string generation
		$css = trim($content, "[]");


		// new title
		if ( $new_title !=='' ) {
		
			$new_title = '<h3 class="new-title">'. $settings['new_title'] . '</h3>';
		
		} else {

			$new_title = '';

		}	

		$content = '['.$css .' ]';

		// output shortcode string
		$shortcode = do_shortcode( shortcode_unautop( $content ) );
	
		// For Testing Shortcode Output
		//echo $content;	


		// hide content
		if ('yes' === $hide_content ) {

			if(is_admin()) {
				
			?>

				<div id="<?php echo $css; ?>" class="admin-only content-hidden">
			   <img src="<?php echo LF_DIR_URL; ?>elementor/images/lf-logo.png" style="width:100px"></img>
    			<style>.elementor-editor-active #<?php echo $css; ?> {background: repeating-linear-gradient( 45deg, #fefefe, #fefefe 10px, #efefef 10px, #efefef 20px )}</style>
				<h3 style="margin:0!important; font-size:21px;"><?php echo __('HIDDEN ON FRONT','lf'); ?></h3>
				<div></div>
				</div>

			<?php


			} // end admin check

			// display then hide on front
			echo '<div class="lf-hide">';
			echo $shortcode;
			echo '</div>';

		} else {

		?>

				<div class="lf-shortcode" >

				<style><?php echo $hide_title; ?></style>

				<?php echo $new_title; ?>
				
				<?php if(is_admin()) { ?>
	
					<div id="<?php echo $css; ?>" class="admin-only">
		
					<div></div>
		
					</div>

				<?php }	?>

				<?php echo $shortcode; ?>

				</div>

		<?php	

		} // end hide content check
	    

	} // end render


} //end	widget