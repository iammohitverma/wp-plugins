(function($, w){
	/**
	 * The object that encapsulates all plugin related data and functions
	 *
	 * @type {{textInputID: string, hiddenInputID: string}}
	 */
	var LFNextStepPage = {
		textInputID: '#_lf_nextstep_field',
		hiddenInputID: '#_lf_nextstep_field_id',

		autoCompleteOptions: {
			autoFocus: true,
			minLength: 2,

			/**
			 * Performs the AJAX request to the WP ajax endpoint to get the hints
			 *
			 * @param request
			 * @param response
			 */
			source: function(request, response){
				$.ajax({
					url: 'admin-ajax.php',
					data: {
						action: 'wc-nextstep-hint',
						search: request.term
					},
					method: "post",
			        dataType: "json",
					success: function(data){
						if(typeof data.success !== "undefined"){
							response(data.data);
						} else {
							response({});
						}
					},
					error: function(){
						response({});
					}
		        });
			},

			/**
			 * Select callback for setting the value into the right input field (the hidden one)
			 *
			 * @param event
			 * @param ui
			 */
			select: function(event, ui){
				var item = ui.item;

				// The display field
				$(LFNextStepPage.textInputID).val(item.label);

				// The hidden field
				$(LFNextStepPage.hiddenInputID).val(item.value);

				event.preventDefault();
			},

			/**
			 * Select callback for setting the value into the right input field (the hidden one)
			 *
			 * @param event
			 * @param ui
			 */
			focus: function(event, ui){
				event.preventDefault();
			}
		}
	};

	/**
	 * Empties the value of the hidden input field (that is only filled when used with autocomplete)
	 */
	LFNextStepPage.emptyHiddenOnChange = function(){
		var trimmedLabelFieldValue = $(LFNextStepPage.textInputID).val().trim();

		if(trimmedLabelFieldValue.indexOf('http') === 0 || trimmedLabelFieldValue === ""){
			$(LFNextStepPage.hiddenInputID).val('');
		}
	};

	/**
	 * Function that sets up all necessary hooks
	 */
	LFNextStepPage.init = function(){
		$(LFNextStepPage.textInputID)
			.change(LFNextStepPage.emptyHiddenOnChange)
			.autocomplete(LFNextStepPage.autoCompleteOptions);
	};

	// Init onload
	$(function(){
		LFNextStepPage.init();
	});
})(window.jQuery, window);