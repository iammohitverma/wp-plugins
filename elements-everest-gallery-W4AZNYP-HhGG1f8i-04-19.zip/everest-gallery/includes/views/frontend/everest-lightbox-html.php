<div class="eg-everest-lightbox-overlay">
    <div class="eg-everest-lightbox-controls">
        <span class="eg-everest-lightbox-previous"><?php _e('Previous', 'everest-gallery'); ?></span>
        <span class="eg-everest-lightbox-next"><?php _e('Next', 'everest-gallery'); ?></span>
    </div>
    <div class="eg-close-pop-up">
        <span class="eg-everest-lightbox-close"><?php _e('Close', 'everest-gallery'); ?></span>
    </div>
    <div class="eg-everest-lightbox-inner-overlay"></div>
    <div class="eg-everest-lightbox-wrap">
        <div class="eg-everest-lightbox-source-holder">
            <img src=""/>
        </div>
        <div class="eg-everest-lightbox-details-wrap">
            <div class="eg-everest-lightbox-caption">Test Caption</div>
            <div class="eg-everest-lightbox-description">Test Description goes like this</div>
        </div>
    </div>
</div>
