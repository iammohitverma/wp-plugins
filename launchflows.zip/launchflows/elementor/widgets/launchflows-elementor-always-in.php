<?php
namespace LaunchFlowsElementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * LaunchFlows Elementor
 *
 * Elementor widget for LaunchFlows
 *
 * @since 1.0.0
 */
class LaunchFlowsElementorAlwaysIn extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'lf-always-in';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'LaunchFlows Always In Checkout', 'lf-always-in-widget' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-single-product';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.2.2
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'launchflows'];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'lf-always-in-widget' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 3.2.2
	 *
	 * @access protected
	 */

	protected function _register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'lf-always-in-widget' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'content',
			[
				'label' => __( 'Select Component To Add:', 'lf-always-in-widget' ),
				'type' => Controls_Manager::HIDDEN,
				'default' => '[lf-always-in]',
			]

		);		
		$this->add_control(
			'product',
			[
				'label' => __( 'Product ID:', 'lf-always-in-widget' ),
				'type' => Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'eg: 12345', 'lf-always-in-widget' ),	
			]
		);
		$this->add_control(
			'hr_after_product',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);			


		$this->add_control(
			'new_title',
			[
				'label' => __( 'Add New Component Title:', 'lf-always-in-widget' ),
				'type' => Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'My Custom Title', 'lf-always-in-widget' ),
				'condition' => [ 'hide_content!' => 'yes' ],	
			]
		);
	
		$this->add_control(
			'hide_icon',
			[
				'label' => __( 'Hide Cart Icon', 'lf-always-in-widget' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Hide', 'lf-always-in-widget' ),
				'label_off' => __( 'Show', 'lf-always-in-widget' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition' => [ 'hide_content!' => 'yes' ],
			]
		);
		$this->add_control(
			'hide_image',
			[
				'label' => __( 'Hide Product Image', 'lf-always-in-widget' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Hide', 'lf-always-in-widget' ),
				'label_off' => __( 'Show', 'lf-always-in-widget' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition' => [ 'hide_content!' => 'yes' ],
			]
		);

		$this->add_control(
			'hide_title',
			[
				'label' => __( 'Hide Product Title', 'lf-always-in-widget' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Hide', 'lf-always-in-widget' ),
				'label_off' => __( 'Show', 'lf-always-in-widget' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition' => [ 'hide_content!' => 'yes' ],	
			]
		);
		$this->add_control(
			'hide_price',
			[
				'label' => __( 'Hide Product Price', 'lf-always-in-widget' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Hide', 'lf-always-in-widget' ),
				'label_off' => __( 'Show', 'lf-always-in-widget' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition' => [ 'hide_content!' => 'yes' ],			
			]
		);
		$this->add_control(
			'hide_shortdesc',
			[
				'label' => __( 'Hide Short Description', 'lf-always-in-widget' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Hide', 'lf-always-in-widget' ),
				'label_off' => __( 'Show', 'lf-always-in-widget' ),
				'return_value' => 'yes',
				'default' => 'no',		
				'condition' => [ 'hide_content!' => 'yes' ],					
			]
		);

$this->end_controls_section();


// title style
$this->start_controls_section(
		'title',
		[
			'label' => __( 'New Title', 'lf-always-in-widget' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		]
	);


	$this->start_controls_tabs(
			'style_tabs_title'
		);

		// normal tab
		$this->start_controls_tab(
				'style_normal_tab_title',
				[
					'label' => __( 'Normal', 'lf-always-in-widget' ),
				]
			);

			// title - normal tab
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name'					=> 'title_typography',
					'label'					=> __( 'Typography', 'lf-always-in-widget' ),
					'selector'				=> '{{WRAPPER}} .new-title'
				]
			);
			$this->add_control(
				'title_text_color',
				[
					'label' => __( 'Text Color', 'lf-always-in-widget' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .new-title' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'title_background_color',
				[
					'label' => __( 'Background Color', 'lf-always-in-widget' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .new-title' => 'background-color: {{VALUE}};',
						'{{WRAPPER}} .new-title::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
					],
				]
			);

			$this->add_responsive_control(
				'title_margin',
				[
					'label' => __( 'Margin', 'lf-always-in-widget' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'allowed_dimensions' => 'vertical',
					'selectors' => [
						'{{WRAPPER}} .new-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'title_padding',
				[
					'label' => __( 'Padding', 'lf-always-in-widget' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .new-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_control(
				'hr_title_padding',
				[
					'type' => \Elementor\Controls_Manager::DIVIDER,
				]
			);	
			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'title_border',
					'label' => __( 'Border', 'lf-always-in-widget' ),
					'selector' => '{{WRAPPER}} .new-title',
				]
			);
			$this->add_responsive_control(
				'title_border_radius',
				[
					'label' => __( 'Border Radius', 'lf-always-in-widget' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%' ],
					'selectors' => [
						'{{WRAPPER}} .new-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);	

			$this->add_control(
				'hr_title_border_radius',
				[
					'type' => \Elementor\Controls_Manager::DIVIDER,
				]
			);	

			$this->add_control(
				'title_alignment',
				[
					'label' => __( 'Alignment', 'lf-always-in-widget' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'lf-always-in-widget' ),
							'icon' => 'fa fa-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'lf-always-in-widget' ),
							'icon' => 'fa fa-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'lf-always-in-widget' ),
							'icon' => 'fa fa-align-right',
						],
					],
					'default' => 'left',
				]
			);

		// end normal
		$this->end_controls_tab();


		// hover tab
		$this->start_controls_tab(
			'title_style_hover_tab_title',
			[
				'label' => __( 'Hover', 'lf-always-in-widget' ),
			]
		);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name'					=> 'title_typography_hover',
					'label'					=> __( 'Typography', 'lf-always-in-widget' ),
					'selector'				=> '{{WRAPPER}} .lf-always-in h3.new-title'
				]
			);
			
			$this->add_control(
				'title_text_color_hover',
				[
					'label' => __( 'Text Color', 'lf-always-in-widget' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .new-title:hover' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'title_background_color_hover',
				[
					'label' => __( 'Background Color', 'lf-always-in-widget' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .new-title:hover' => 'background-color: {{VALUE}};',
						'{{WRAPPER}} .new-title:hover::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
					],
				]
			);
			$this->add_control(
				'hr_title_background_color_hover',
				[
					'type' => \Elementor\Controls_Manager::DIVIDER,
				]
			);					
			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'title_border_hover',
					'label' => __( 'Border', 'lf-always-in-widget' ),
					'selector' => '{{WRAPPER}} .new-title:hover',
				]
			);

			$this->add_responsive_control(
				'title_border_radius_hover',
				[
					'label' => __( 'Border Radius', 'lf-always-in-widget' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%' ],
					'selectors' => [
						'{{WRAPPER}} .new-title:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);	

		// end hover
		$this->end_controls_tab();

	// end tabs
	$this->end_controls_tabs();

// end title section
$this->end_controls_section();

$this->start_controls_section(
			'alwaysin_select',
			[
				'label' => __( 'Cart Icon', 'lf-always-in-widget' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_control(
			'alwaysin_select_scale',
			[
				'label' => __( 'Selector Size', 'lf-always-in-widget' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 5,
				'step' => .1,
				'default' => 1,
				'selectors' => [
					'{{WRAPPER}} .lf-always-in .pretty' => 'transform: scale({{VALUE}})!important;',
				],
			]
		);
		$this->add_control(
			'alwaysin_select_color',
			[
				'label' => __( 'Cart Icon Color', 'lf-always-in-widget' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .lf-always-in .pretty' => 'color: {{VALUE}}',
				],
			]
		);

$this->end_controls_section();

/* start product image */
		$this->start_controls_section(
			'alwaysin_image',
			[
				'label' => __( 'Image', 'lf-always-in-widget' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'alwaysin_product_image_width',
			[
				'label' => __( 'Image Width', 'lf-always-in-widget' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1400,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .always-in-image' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);


$this->end_controls_section();

// alwaysin title
$this->start_controls_section(
			'alwaysin_product_title',
			[
				'label' => __( 'Title', 'lf-always-in-widget' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


	$this->start_controls_tabs(
			'style_tabs_title_existing'
		);

		$this->start_controls_tab(
			'style_normal_tab_title_existing',
			[
				'label' => __( 'Normal', 'lf-always-in-widget' ),
			]
		);

				// title - normal tab
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name'					=> 'alwaysin_title_typography_style_normal_tab_title_existing',
						'label'					=> __( 'Typography', 'lf-always-in-widget' ),
						'selector'				=> '{{WRAPPER}} .always-in-title'
					]
				);
				$this->add_control(
					'alwaysin_title_text_color',
					[
						'label' => __( 'Text Color', 'lf-always-in-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .always-in-title' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'alwaysin_title_background_color',
					[
						'label' => __( 'Background Color', 'lf-always-in-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .always-in-title' => 'background-color: {{VALUE}};',
							'{{WRAPPER}} .always-in-title::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
						],
					]
				);

				$this->add_responsive_control(
					'alwaysin_title_margin',
					[
						'label' => __( 'Margin', 'lf-always-in-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'selectors' => [
							'{{WRAPPER}} .always-in-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'alwaysin_title_padding',
					[
						'label' => __( 'Padding', 'lf-always-in-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'selectors' => [
							'{{WRAPPER}} .always-in-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_control(
					'hr_alwaysin_title_padding',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);	
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'alwaysin_title_border',
						'label' => __( 'Border', 'lf-always-in-widget' ),
						'selector' => '{{WRAPPER}} .alwaysin-title',
					]
				);
				$this->add_responsive_control(
					'alwaysin_title_border_radius',
					[
						'label' => __( 'Border Radius', 'lf-always-in-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .always-in-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);	

				$this->add_control(
					'hr_alwaysin_title_border_radius',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);	

		$this->end_controls_tab();


		// title - hover tab
		$this->start_controls_tab(
			'style_hover_tab_title',
			[
				'label' => __( 'Hover', 'lf-always-in-widget' ),
			]
		);

				$this->add_group_control(
					Group_Control_Typography::get_type(),
					[
						'name'					=> 'alwaysin_title_typography_style_hover_tab_title',
						'label'					=> __( 'Typography', 'lf-always-in-widget' ),
						'selector'				=> '{{WRAPPER}} .alwaysin-title'
					]
				);
				
				$this->add_control(
					'alwaysin_title_text_color_hover',
					[
						'label' => __( 'Text Color', 'lf-always-in-widget' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .always-in-title:hover' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'alwaysin_title_background_color_hover',
					[
						'label' => __( 'Background Color', 'lf-always-in-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .always-in-title:hover' => 'background-color: {{VALUE}};',
							'{{WRAPPER}} .always-in-title:hover::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
						],
					]
				);
				$this->add_control(
					'hr_alwaysin_title_background_color_hover',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);					
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'alwaysin_title_border_hover',
						'label' => __( 'Border', 'lf-always-in-widget' ),
						'selector' => '{{WRAPPER}} .always-in-title:hover',
					]
				);

				$this->add_responsive_control(
					'alwaysin_title_border_radius_hover',
					[
						'label' => __( 'Border Radius', 'lf-always-in-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .always-in-title:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);	


		$this->end_controls_tab();

	$this->end_controls_tabs();

$this->end_controls_section();
/* title end */

// alwaysin price
$this->start_controls_section(
			'alwaysin_product_price',
			[
				'label' => __( 'Price', 'lf-always-in-widget' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


	$this->start_controls_tabs(
			'style_tabs_price'
		);

		$this->start_controls_tab(
			'style_normal_tab_price',
			[
				'label' => __( 'Normal', 'lf-always-in-widget' ),
			]
		);

				// price - normal tab
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name'					=> 'alwaysin_price_typography_style_normal_tab_price',
						'label'					=> __( 'Typography', 'lf-always-in-widget' ),
						'selector'				=> '{{WRAPPER}} .alwaysin-price'
					]
				);
				$this->add_control(
					'alwaysin_price_text_color',
					[
						'label' => __( 'Text Color', 'lf-always-in-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .always-in-price' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'alwaysin_price_background_color',
					[
						'label' => __( 'Background Color', 'lf-always-in-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .always-in-price' => 'background-color: {{VALUE}};',
							'{{WRAPPER}} .always-in-price::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
						],
					]
				);

				$this->add_responsive_control(
					'alwaysin_price_margin',
					[
						'label' => __( 'Margin', 'lf-always-in-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'selectors' => [
							'{{WRAPPER}} .always-in-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'alwaysin_price_padding',
					[
						'label' => __( 'Padding', 'lf-always-in-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'selectors' => [
							'{{WRAPPER}} .always-in-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_control(
					'hr_alwaysin_price_padding',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);	
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'alwaysin_price_border',
						'label' => __( 'Border', 'lf-always-in-widget' ),
						'selector' => '{{WRAPPER}} .alwaysin-price',
					]
				);
				$this->add_responsive_control(
					'alwaysin_price_border_radius',
					[
						'label' => __( 'Border Radius', 'lf-always-in-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .always-in-price' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);	

				$this->add_control(
					'hr_alwaysin_price_border_radius',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);	

		$this->end_controls_tab();


		// price - hover tab
		$this->start_controls_tab(
			'style_hover_tab_price',
			[
				'label' => __( 'Hover', 'lf-always-in-widget' ),
			]
		);

				$this->add_group_control(
					Group_Control_Typography::get_type(),
					[
						'name'					=> 'alwaysin_price_typography_style_hover_tab_price',
						'label'					=> __( 'Typography', 'lf-always-in-widget' ),
						'selector'				=> '{{WRAPPER}} .alwaysin-price'
					]
				);
				
				$this->add_control(
					'alwaysin_price_text_color_hover',
					[
						'label' => __( 'Text Color', 'lf-always-in-widget' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .always-in-price:hover' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'alwaysin_price_background_color_hover',
					[
						'label' => __( 'Background Color', 'lf-always-in-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .always-in-price:hover' => 'background-color: {{VALUE}};',
							'{{WRAPPER}} .always-in-price:hover::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
						],
					]
				);
				$this->add_control(
					'hr_alwaysin_price_background_color_hover',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);					
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'alwaysin_price_border_hover',
						'label' => __( 'Border', 'lf-always-in-widget' ),
						'selector' => '{{WRAPPER}} .always-in-price:hover',
					]
				);

				$this->add_responsive_control(
					'alwaysin_price_border_radius_hover',
					[
						'label' => __( 'Border Radius', 'lf-always-in-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .always-in-price:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);	


		$this->end_controls_tab();

	$this->end_controls_tabs();

$this->end_controls_section();
/* price end */

// always_in shortdesc
$this->start_controls_section(
			'always_in_product_short_desc',
			[
				'label' => __( 'Short Description', 'lf-always-in-widget' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


	$this->start_controls_tabs(
			'style_tabs_short_desc'
		);

		$this->start_controls_tab(
			'style_normal_tab_short_desc',
			[
				'label' => __( 'Normal', 'lf-always-in-widget' ),
			]
		);

				// short desc - normal tab
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name'					=> 'always_in_short_desc_normal_typography',
						'label'					=> __( 'Typography', 'lf-always-in-widget' ),
						'selector'				=> '{{WRAPPER}} .always-in-short-description'
					]
				);
				$this->add_control(
					'always_in_short_desc_normal_text_color',
					[
						'label' => __( 'Text Color', 'lf-always-in-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .always-in-short-description' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'always_in_short_desc_normal_background_color',
					[
						'label' => __( 'Background Color', 'lf-always-in-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .always-in-short-description' => 'background-color: {{VALUE}};',
							'{{WRAPPER}} .always-in-short-description::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
						],
					]
				);

				$this->add_responsive_control(
					'always_in_short_desc_normal_margin',
					[
						'label' => __( 'Margin', 'lf-always-in-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'selectors' => [
							'{{WRAPPER}} .always-in-short-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'always_in_short_desc_normal_padding',
					[
						'label' => __( 'Padding', 'lf-always-in-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'selectors' => [
							'{{WRAPPER}} .always-in-short-description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_control(
					'hr_always_in_short_desc_normal_padding',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);	
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'always_in_short_desc_normal_border',
						'label' => __( 'Border', 'lf-always-in-widget' ),
						'selector' => '{{WRAPPER}} .always-in-short-description',
					]
				);
				$this->add_responsive_control(
					'always_in_short_desc_normal_border_radius',
					[
						'label' => __( 'Border Radius', 'lf-always-in-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .always-in-short-description' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);	

				$this->add_control(
					'hr_short_desc_normal_border_radius',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);	

		$this->end_controls_tab();


		// short desc - hover tab
		$this->start_controls_tab(
			'style_short_desc_hover_tab_price',
			[
				'label' => __( 'Hover', 'lf-always-in-widget' ),
			]
		);

				$this->add_group_control(
					Group_Control_Typography::get_type(),
					[
						'name'					=> 'always_in_short_desc_hover_typography',
						'label'					=> __( 'Typography', 'lf-always-in-widget' ),
						'selector'				=> '{{WRAPPER}} .always-in-short-description'
					]
				);
				
				$this->add_control(
					'always_in_short_desc_hover_text_color',
					[
						'label' => __( 'Text Color', 'lf-always-in-widget' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .always-in-short-description:hover' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'always_in_short_desc_hover_background_color',
					[
						'label' => __( 'Background Color', 'lf-always-in-widget' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .always-in-short-description:hover' => 'background-color: {{VALUE}};',
							'{{WRAPPER}} .always-in-short-description:hover::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
						],
					]
				);
				$this->add_control(
					'hr_short_desc_hover',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);					
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'always_in_short_desc_hover_border',
						'label' => __( 'Border', 'lf-always-in-widget' ),
						'selector' => '{{WRAPPER}} .always-in-short-description:hover',
					]
				);

				$this->add_responsive_control(
					'always_in_short_desc_hover_border_radius',
					[
						'label' => __( 'Border Radius', 'lf-always-in-widget' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .always-in-short-description:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);	


		$this->end_controls_tab();

	$this->end_controls_tabs();

$this->end_controls_section();

/* always in shortdesc end */


// end
	}



/**
	 * Render CSS Style
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */

   public function __construct($data = [], $args = null) {
      parent::__construct($data, $args);
      wp_register_style( 'lf-elementor', LF_DIR_URL . 'elementor/css/launchflows-elementor.css', false, '1.0.0');
   }

  public function get_style_depends() {
     return [ 'lf-elementor' ];
  }

/**
	 * Render shortcode widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 3.2.2
	 * @access protected
	 */

	protected function render() {

		$settings = $this->get_settings_for_display();


		$content = $this->get_settings( 'content' );
		

		$product = $this->get_settings( 'product' );

		
		$hide_content = $this->get_settings( 'hide_content' );

		
		$hide_icon = $this->get_settings( 'hide_icon' );


		$hide_image = $this->get_settings( 'hide_image' );


		$hide_title = $this->get_settings( 'hide_title' );


		$hide_price = $this->get_settings( 'hide_price' );


		$hide_shortdesc = $this->get_settings( 'hide_shortdesc' );


		$new_title = $this->get_settings( 'new_title' );


		$title_alignment = $this->get_settings( 'title_alignment');


		$css = trim($content, "[]");

		// new title
		if ( $new_title !=='' ) {
		
			$new_title = '<h3 class="new-title" style="text-align:'. $settings['title_alignment'].'">'. $settings['new_title'] . '</h3>';
		
		} else {

			$new_title = '';

		}	

		if ( 'yes' === $hide_icon ) {
		
			$alwaysin_icon = 'icon="no"';
		
		} else {

			$alwaysin_icon = '';
		}	

		if ( 'yes' === $hide_image ) {
		
			$alwaysin_image = 'image="no"';
		
		} else {

			$alwaysin_image = '';
		}	

		if ( 'yes' === $hide_title ) {
		
			$alwaysin_title = 'title="no"';
		
		} else {

			$alwaysin_title = '';
		}	

		if ( 'yes' === $hide_price ) {
		
			$alwaysin_price = 'price="no"';
		
		} else {

			$alwaysin_price = '';
		}	

		if ( 'yes' === $hide_shortdesc ) {
		
			$alwaysin_short_desc = 'shortdesc="no"';
		
		} else {

			$alwaysin_short_desc = '';
		}

		// check if any value in product id to merge with content
		if ($product !=='') {

			$content = '['.$css .' product='. $product.'  '.$alwaysin_icon.' '.$alwaysin_image.' '.$alwaysin_title.' '.$alwaysin_price.' '.$alwaysin_short_desc.']';
		
		}

		// For Testing Shortcode Output
		//echo $content;	

		// hide content on front
		if ('yes' === $hide_content ) {

			// but still display on admin side
		//	if(is_admin()) {

				?>
				<div id="<?php echo $css; ?>" class="admin-only content-hidden">
			   <img src="<?php echo LF_DIR_URL; ?>elementor/images/lf-logo.png" style="width:100px"></img>
    			<style>.elementor-editor-active #<?php echo $css; ?>.content-hidden {background: repeating-linear-gradient( 45deg, #fefefe, #fefefe 10px, #efefef 10px, #efefef 20px )}</style>
				<h3 style="margin:0!important; font-size:21px;"><?php echo __('HIDDEN ON FRONT','lf'); ?></h3>
				<div></div>
				</div>
				<?php


				// output final string as new shortcode
				$shortcode = do_shortcode( shortcode_unautop( $content ) );

				echo $shortcode;


		//	} // end admin check



		} else {

		// show content on front
		?>

				<div class="lf-shortcode" >

				<style><?php echo $hide_title; ?></style>

				<?php echo $new_title; ?>
				
				<?php if(is_admin()) { ?>
	
					<div id="<?php echo $css; ?>" class="admin-only">
		
					<div></div>
		
					</div>

				<?php }	?>

				<?php
				// output final string as new shortcode
				$shortcode = do_shortcode( shortcode_unautop( $content ) );

				echo $shortcode; 

				?>

				</div>

		<?php	

		} // end hide content check
	    

	} // end render


} //end	widget