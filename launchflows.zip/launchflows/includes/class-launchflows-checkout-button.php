<?php

class CheckoutButtonClass {

/**
	 * Constructor
	 *
	 * @since 4.1.2
	 *
	 * @return void
	 */

public function __construct() {

// for custom shortcode metabox
    add_action( 'add_meta_boxes', array ($this, 'lf_add_metabox') );              
    add_action( 'save_post', array ($this, 'save') );
	  add_filter( 'woocommerce_order_button_text', array ($this, 'custom_message'), 9999 ); // higher priority to override other plugins using same filter
//    add_action( 'woocommerce_after_checkout_form', array ($this, 'add_checkout_script' ) ); dep 3.5.3 to allow product post type to work

    add_action( 'get_footer', array ($this, 'add_checkout_script' ) );
 
  }


/**
	 * Adds Custom Checkout Button Text Capability
	 *
	 * @since 3.5.3
	 *
	 * @return void
	 */

public function lf_add_metabox($post_type) { 
      
      // post types to exclude
      $post_types = array('wccc');

      // limit meta box to certain post types
      if(!in_array($post_type, $post_types)) {
      $label = __( 'LaunchFlows Button Text', 'lf' );
        add_meta_box(
          'lf-meta-checkout', 
          $label, 
          array($this, 'lf_meta_box_function'), // triggers output function
          $post_type,
          'side', 
          'high');

      }
    }

/**
	 * Adds Metabox Output
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */

// Output For Metabox
public function lf_meta_box_function( $post ) {

	?>
	<label style="font-size:12px; color:#ababab;" for="lf-meta-button"><?php _e('This Will Replace "Place Order" Button Text','lf'); ?></label>
	<style>textarea#lf_custom_button_message {padding: 5px;}div#wp-lf_custom_button_message-editor-container {border-radius: 4px; border: 1px solid #8c8f94;}</style>
  <?php

    // Add an nonce field so we can check for it later.
    wp_nonce_field('lf_nonce_check', 'lf_nonce_check_value');

    // Use get_post_meta to retrieve an existing value from the database.
    $data =  get_post_meta($post -> ID, '_lf_custom_button_message' , true ) ;

    // Display the form, using the current value.
    wp_editor( $data, 'lf_custom_button_message', 
      $settings = array(
        'quicktags' => false,
        'tinymce' => false, 
        'media_buttons'=> false, 
        'textarea_rows'=>'1'
      ));
    }


/**
	 * Save Content In Metabox
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */

public function save( $post_id ) { 


/*
     * We need to verify this came from the our screen and with 
     * proper authorization,
     * because save_post can be triggered at other times.
     */

    // Check if our nonce is set.
    if (!isset($_POST['lf_nonce_check_value']))
      return $post_id;

    $nonce = $_POST['lf_nonce_check_value'];

    // Verify that the nonce is valid.
    if (!wp_verify_nonce($nonce, 'lf_nonce_check'))
      return $post_id;

    // If this is an autosave, our form has not been submitted,
    //     so we don't want to do anything.
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
      return $post_id;

    // Check the user's permissions.
    if ('page' == $_POST['post_type']) {

      if (!current_user_can('edit_page', $post_id))
        return $post_id;

    } else {

      if (!current_user_can('edit_post', $post_id))
        return $post_id;
    }

    /* OK, its safe for us to save the data now. */

    // Sanitize the user input.
    $data = sanitize_text_field($_POST['lf_custom_button_message']);

    // Update the meta field.
    update_post_meta($post_id, '_lf_custom_button_message', $data);
  }


/**
   * Retrieves the value of the LaunchFlows settings menu global checkout button option
   *
   * @since 1.0.16
   *
   * @return void
   */

  public function custom_message($content) {
      // if no custom button text per page, use global, and if no global, default to "Place Order"
      $options = get_option( 'lf_settings' );
      if( isset($options['lf_text_field_1']) && !empty($options['lf_text_field_1']) ) {     
      return $options['lf_text_field_1']; // applies new text from plugin admin panel
      } // else
      return __( 'Place Order', 'woocommerce' ); // default button text to use on all other product
      }


/**
   * Retrieves the value of any value in the LF - Custom Checkout Button metabox. *This will override any other button text!
   *
   * @since 1.0.16
   *
   * @return void
   */ 
// WooCommerce Checkout Button Ajax Handler Fix 
// stackoverflow.com/questions/37454383/add-a-custom-script-on-place-order-button-on-woocommerce-checkout-page
public function add_checkout_script() { 

    global $post; 
  
   // retrieve the metadata value from LF-Custom Checkout Button Metabox and overrides any other button text per post
    $wc_button_text = get_post_meta($post -> ID, '_lf_custom_button_message', true);
  
    $wc_button_text = htmlentities($wc_button_text);
  
    if (isset($wc_button_text) && !empty($wc_button_text)) {
    ?>
  
      <style>#place_order{display: none;}</style>
  
        <script type="text/javascript">
    
        jQuery( document ).ready(function() {
    
          jQuery(document).on( "updated_checkout", function(){ // after WC ajax reloads checkout!
      
              jQuery("#place_order").hide().text("<?php echo $wc_button_text; ?>").fadeIn(0);
      
          });         
    
        });
    
        </script>
  
    <?php       
  
  }

} 



} // leave in place
/**
 * Finally, instantiate the class
 */

new CheckoutButtonClass;