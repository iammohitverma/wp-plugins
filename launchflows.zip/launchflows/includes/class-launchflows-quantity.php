<?php
/**
	 * Adds Quantity On Checkout
	 *
	 * @since 2.1.7    
	 *
	 * @return void
	 */

if (!class_exists('LF_Change_Quantity_On_Checkout')) {

	class LF_Change_Quantity_On_Checkout {

		public $plugin_version = '1.0';

		public function __construct() {

          add_filter ('woocommerce_cart_item_name',              array( $this, 'lf_cqoc_add_items'), 10, 3 );
    	  add_filter ('woocommerce_checkout_cart_item_quantity', array( $this, 'lf_cqoc_add_quantity'), 10, 2 );
    	  add_action( 'wp_footer',                               array( $this, 'lf_cqoc_add_js' ), 10 );
     	  add_action( 'init',                                    array( $this, 'lf_cqoc_load_ajax' ) );

    }


/**
	 * Adds Delete Button and Quantity Field To Checkout Table for launchflows only
	 *
	 * @since 4.1.2
	 *
	 * @return void
	 */

    public static function lf_cqoc_add_items( $product_title, $cart_item, $cart_item_key ) {

   		    if (  is_checkout() ) {

  		        $cart = WC()->cart->get_cart();

                  foreach ( $cart as $cart_key => $cart_value ){
                     if ( $cart_key == $cart_item_key ){
                          $product_id = $cart_item['product_id'];
                          $_product   = $cart_item['data'] ;
                          /* Get product thumbnail */
                          $thumbnail = $_product->get_image(); 
                          /* Add wrapper to image and add some css */
                          $image = '<span class="lf-product-image">'. $thumbnail . '</span>'; 

                          $default_wc = '&nbsp;<strong class="default-product-quantity"> ×&nbsp;'.$cart_item['quantity'].'</strong>';
   
                          $return_value = sprintf(
                            '<a href="%s" class="remove" title="%s" data-product_id="%s" data-product_sku="%s">×</a> ',
                            esc_url( wc_get_cart_remove_url( $cart_key ) ),
                            __( 'Remove this item', 'woocommerce' ),
                            esc_attr( $product_id ),
                            esc_attr( $_product->get_sku() )
                          );
                          $return_value_test = '';

                          $return_value .=  $image . '<span class="lf_cqoc_product_name">' . $product_title . '</span>' . $default_wc ;

                          if ( $_product->is_sold_individually() ) {
                         
                            $return_value .= sprintf( '<input type="hidden" name="cart[%s][qty]" value="1" />', $cart_key );
                         
                          } else {
                          
                          $return_value .= woocommerce_quantity_input( array(
                              'input_name'  => "cart[{$cart_key}][qty]",
                              'input_value' => $cart_item['quantity'],
                              'max_value'   => apply_filters( 'woocommerce_quantity_input_max', $_product->backorders_allowed() ? '' : $_product->get_stock_quantity(), $product ),
                              'min_value'   => apply_filters( 'woocommerce_quantity_input_min', 1, $product ),
                              'pattern'     => '[0-9]*'
                              ), $_product );
                        }
                          return $return_value;
                      }
                  }

          } else {
              /*
               * It will return the product name on the cart page.
               * As the filter used on checkout and cart are same.
               */
              $_product   = $cart_item['data'] ;

              $product_permalink = $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '';

              if ( ! $product_permalink ) {

                  $return_value = $_product->get_title() . '&nbsp;';

              } else {

                  $return_value = sprintf( '<a href="%s">%s</a>', esc_url( $product_permalink ), $_product->get_title());

              }

              return $return_value;
          }
		}   

		/*
		 * Removes the selected quantity count from checkout page table.
		 */
    	public static function lf_cqoc_add_quantity( $cart_item, $cart_item_key ) {

    	   $product_quantity= '';
    	  
         return $product_quantity;
    	
      }
    	
    	function lf_cqoc_add_js(){
    	

        if (  is_checkout() ) {
		
                ?>
                
                <script type="text/javascript">
					
                    <?php  $admin_url = get_admin_url(); ?>
					jQuery("form.checkout").on("change", "input.qty", function(){
                        
                        var data = {
                    		action: 'lf_cqoc_update_order_review',
                    		security: wc_checkout_params.update_order_review_nonce,
                    		post_data: jQuery( 'form.checkout' ).serialize()
                    	};
						
                    	jQuery.post( '<?php echo $admin_url; ?>' + 'admin-ajax.php', data, function( response )
                		{
                            jQuery( 'body' ).trigger( 'update_checkout' );
                            var uri = window.location.toString(); // gets the root of the page to prepare for removing string
                            // cleanup the add-to-cart= to be sure it won't add another product if that was in url string
                            // itsolutionstuff.com/post/how-to-remove-query-string-from-urlexample.html
              								if (uri.indexOf("?") > 0) {
              								    var clean_uri = uri.substring(0, uri.indexOf("?"));
              								    window.history.replaceState({}, document.title, clean_uri);
              								}
//(3.1 disabled reload)    location.reload(); //useful to update cart fragments/totals without use of ajax
						});
                    });
                </script>
             <?php  
             }
        }
        
        function lf_cqoc_load_ajax() {

   
            if ( !is_user_logged_in() ){
                add_action( 'wp_ajax_nopriv_lf_cqoc_update_order_review', array( &$this, 'lf_cqoc_update_order_review' ) );
            } else {
                add_action( 'wp_ajax_lf_cqoc_update_order_review', array( &$this, 'lf_cqoc_update_order_review' ) );
            }
        
        }
        
        function lf_cqoc_update_order_review() {

            $values = array();
            parse_str($_POST['post_data'], $values);
            $cart = $values['cart'];
            foreach ( $cart as $cart_key => $cart_value ){
                WC()->cart->set_quantity( $cart_key, $cart_value['qty'], false );
                WC()->cart->calculate_totals();
                woocommerce_cart_totals();
            }
            exit;
        }


	}
}
$lf_change_quantity_on_checkout = new LF_Change_Quantity_On_Checkout();