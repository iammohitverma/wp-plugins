<?php

class LFNextStep {

	/**
	 * Method to kickstart the code.
	 *
	 * @return void
	 */
	public static function start(){
		new LFNextStep;
	}

	/**
	 * Adds all necessary action hooks
	 */
	private function __construct(){
		// The field
		add_action('woocommerce_process_product_meta', array($this, 'saveProductGeneralTabField'));

		// auto hinting functions
		add_action( 'admin_enqueue_scripts', array( $this, 'include_javascript' ) );
		add_action( 'wp_ajax_wc-nextstep-hint', array( $this, 'hint_nextstep_pages' ) );

		// add shortcode
        add_shortcode( 'lf-next-step-link', array ($this, 'lf_next_step_link' ) );    

	}


	/**
	 * Includes the checkout hinting JS file on single edit pages.
	 *
	 * @access public
	 * @param  string $hook Page hook.
	 */

	public function include_javascript( $hook ) {

		// bail if not on admin or our function doesnt exist.
		if ( ! is_admin() || ! function_exists( 'get_current_screen' ) ) {
			return;
		}

		// get my current screen.
		$screen = get_current_screen();

		// bail without.
		if ( empty( $screen ) || ! is_object( $screen ) ) {
			return;
		}

		// make sure we are on the wc single product editor
		if ( 'post' !== $screen->base || 'product' !== $screen->post_type ) {
			return;
		}

		// load the js file
		wp_enqueue_script( 'lf_wc_nextstep_redirect-hinting', LF_DIR_URL . "assets/js/nextstep-hint.js", array( 'jquery', 'jquery-ui-autocomplete' ), '1.05', true );
	}


	/**
	 * Prints out the page hints in JSON format.
	 */

	public function hint_nextstep_pages() {

		// Set our search param.
		$search = isset( $_REQUEST['search'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['search'] ) ) : '';

		// Set our query args.
		$query = new \WP_Query(
			array(
//				'post_type'      => array('page', 'post', 'sfwd-courses', 'sfwd-lessons', 'course', 'lesson'),
				'post_Type'      => 'any', // any post type
				'posts_per_page' => 15,
				's'              => $search,
			)
		);

		// bail if we have no posts
		if ( is_wp_error( $query ) || empty( $query->posts ) ) {
			return false;
		}

		// set an empty for the result array.
		$result = array();

		// loop the results
		foreach ( $query->posts as $post ) {
			$result[] = array(
				'label' => $post->post_title,
				'value' => $post->ID,
			);
		}

		// return the results, JSON encoded
		echo wp_json_encode(
			array(
				'success' => true,
				'data'    => $result,
			)
		);

		// And die.
		die();
	}


	/**
	 * Saves the contents from the checkout page field
	 *
	 * @since 1.1.9
	 * @param int $id Post ID.
	 */

	public function saveProductGeneralTabField($post_id) {

		// Throw an error if the data wasn't saved.
		if ( ! isset( $_REQUEST['_lf_nextstep_field_id'] ) || ! isset( $_REQUEST['_lf_nextstep_field'] ) ) {
			new \WP_Error( 'Necessary field values are not present' );
			return;
		}

		// Set our page and label.
		$nextstep_page       = sanitize_text_field( wp_unslash( $_REQUEST['_lf_nextstep_field_id'] ) );
		$nextstep_page_label = trim( sanitize_text_field( wp_unslash( $_REQUEST['_lf_nextstep_field'] ) ) );

		if ( 0 === strpos( $nextstep_page_label, 'http' ) ) {
			update_post_meta( $post_id, '_lf_nextstep_field', $nextstep_page_label );
		} elseif ( ! empty( $nextstep_page ) ) {
			update_post_meta( $post_id, '_lf_nextstep_field', $nextstep_page );
		} else {
			update_post_meta( $post_id, '_lf_nextstep_field', '' );
		}
	}


/**
	 *	Gets the appropriate redirect URL
	 *
	 *  @since 1.1.4
	 *	@param (int) $product_id - Product ID
	 *	@return (string) - Redirect URL if one is set, else empty string
	 */

	public function get_redirect_url( $product_id ) {

		// Determine a post redirect
		$meta = get_post_meta( $product_id, '_lf_nextstep_field', true );
	
		$post_redirect = get_permalink( (int) $meta ); // gets url that matches this product_id

		if ( $post_redirect ) {
			$redirect_url = $post_redirect;
		}


		// Return final redirect URL
		return isset( $redirect_url ) ? esc_url_raw( $redirect_url ) : '';
	}



 /**
   * Add Next Step ShortCode To Be Used For Creating Button Links Per Product
   *
   * @since 1.2.1
   * @access public
   */
	
	public function lf_next_step_link( $url, $order_id, $product_id ) { // outputs the url saved in the field
	
		ob_start();
        // logged in users only
        if ( is_user_logged_in()) {

            $user_id         = get_current_user_id(); // The current user ID

            // get the WC_Customer instance Object for the current user
            $customer        = new WC_Customer( $user_id );

            // get customer last order
            $last_order      = $customer->get_last_order();

			// check if there is a last order, otherwise post notice and stop
            if ( ! $last_order ) { 
              echo '<ul class="woocommerce-error" role="alert"><li>';
              esc_html_e( 'There are no last orders for this user.', 'lf' );
              echo '</li></ul>';
              return false;
            }

            // loop through order and get items
            foreach ( $last_order->get_items() as $order_item ) {
            
            // get the product from each item  
            
			      $product = $order_item->get_product();
            
			// get the product id from product object
                  $product_id = $product->get_id();

			// output the url

		   		  $url = $this->get_redirect_url( $product_id );
    	          echo $url;

            }


        } //end if
		 
	
		$output = ob_get_contents();   
		ob_end_clean();   
		return $output;   
	
	} 

} // end class wrapper

/**
 * Finally, start the class
 */

LFNextStep::start();