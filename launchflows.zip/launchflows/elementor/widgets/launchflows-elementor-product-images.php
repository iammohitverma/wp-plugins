<?php
namespace LaunchFlowsElementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * LaunchFlows Elementor
 *
 * Elementor widget for LaunchFlows
 *
 * @since 1.0.0
 */
class LaunchFlowsElementorProductImages extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'lf-product-images';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'LaunchFlows Product Images', 'lf-product-images-widget' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-cart';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.2.2
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'launchflows'];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'lf' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 3.2.2
	 *
	 * @access protected
	 */

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'lf-product-images-widget' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);


			$this->add_control(
				'content',
				[
					'label' => __( 'Select Component To Add:', 'lf-product-images-widget' ),
					'type' => Controls_Manager::HIDDEN,
					'default' => '[lf-product-images]',
				]

			);		

			$this->add_control(
				'hide_content',
				[
					'label' => __( 'Hide Product Images', 'lf-product-images-widget' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Hide', 'lf' ),
					'label_off' => __( 'Show', 'lf' ),
					'return_value' => 'yes',
					'default' => 'no',
				]
			);

			$this->add_control(
				'hr_hide_content',
				[
					'type' => \Elementor\Controls_Manager::DIVIDER,
				]
			);	

			$this->add_control(
				'new_title',
				[
					'label' => __( 'Add New Title:', 'lf-product-images-widget' ),
					'type' => Controls_Manager::TEXT,
					'input_type' => 'text',
					'placeholder' => __( 'My Custom Title', 'lf-product-images-widget' ),	
				]
			);

		$this->end_controls_section();


		// title style
		$this->start_controls_section(
				'title',
				[
					'label' => __( 'New Title', 'lf-product-images-widget' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				]
			);


			$this->start_controls_tabs(
					'style_tabs_title'
				);

				// normal tab
				$this->start_controls_tab(
						'style_normal_tab_title',
						[
							'label' => __( 'Normal', 'lf-product-images-widget' ),
						]
					);

					// title - normal tab
					$this->add_group_control(
						\Elementor\Group_Control_Typography::get_type(),
						[
							'name'					=> 'title_typography',
							'label'					=> __( 'Typography', 'lf-product-images-widget' ),
							'selector'				=> '{{WRAPPER}} .new-title'
						]
					);
					$this->add_control(
						'title_text_color',
						[
							'label' => __( 'Text Color', 'lf-product-images-widget' ),
							'type' => Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .new-title' => 'color: {{VALUE}}',
							],
						]
					);
					$this->add_control(
						'title_background_color',
						[
							'label' => __( 'Background Color', 'lf-product-images-widget' ),
							'type' => Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .new-title' => 'background-color: {{VALUE}};',
								'{{WRAPPER}} .new-title::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
							],
						]
					);

					$this->add_responsive_control(
						'title_margin',
						[
							'label' => __( 'Margin', 'lf-product-images-widget' ),
							'type' => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'allowed_dimensions' => 'vertical',
							'selectors' => [
								'{{WRAPPER}} .new-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_responsive_control(
						'title_padding',
						[
							'label' => __( 'Padding', 'lf-product-images-widget' ),
							'type' => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors' => [
								'{{WRAPPER}} .new-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_control(
						'hr_title_normal',
						[
							'type' => \Elementor\Controls_Manager::DIVIDER,
						]
					);	
					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'title_border',
							'label' => __( 'Border', 'lf-product-images-widget' ),
							'selector' => '{{WRAPPER}} .new-title',
						]
					);
					$this->add_responsive_control(
						'title_border_radius',
						[
							'label' => __( 'Border Radius', 'lf-product-images-widget' ),
							'type' => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%' ],
							'selectors' => [
								'{{WRAPPER}} .new-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);	

					$this->add_control(
						'hr_title_normal_after_border',
						[
							'type' => \Elementor\Controls_Manager::DIVIDER,
						]
					);	

				// end normal
				$this->end_controls_tab();


				// hover tab
				$this->start_controls_tab(
					'style_hover_tab_title',
					[
						'label' => __( 'Hover', 'lf-product-images-widget' ),
					]
				);

					$this->add_group_control(
						Group_Control_Typography::get_type(),
						[
							'name'					=> 'title_typography_hover',
							'label'					=> __( 'Typography', 'lf-product-images-widget' ),
							'selector'				=> '{{WRAPPER}} .lf-product-images h3.new-title'
						]
					);
					
					$this->add_control(
						'title_text_color_hover',
						[
							'label' => __( 'Text Color', 'lf-product-images-widget' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .new-title:hover' => 'color: {{VALUE}}',
							],
						]
					);
					$this->add_control(
						'title_background_color_hover',
						[
							'label' => __( 'Background Color', 'lf-product-images-widget' ),
							'type' => Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .new-title:hover' => 'background-color: {{VALUE}};',
								'{{WRAPPER}} .new-title:hover::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
							],
						]
					);
					$this->add_control(
						'hr_title_hover',
						[
							'type' => \Elementor\Controls_Manager::DIVIDER,
						]
					);					
					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'title_border_hover',
							'label' => __( 'Border', 'lf-product-images-widget' ),
							'selector' => '{{WRAPPER}} .new-title:hover',
						]
					);

					$this->add_responsive_control(
						'title_border_radius_hover',
						[
							'label' => __( 'Border Radius', 'lf-product-images-widget' ),
							'type' => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%' ],
							'selectors' => [
								'{{WRAPPER}} .new-title:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);	
		
				// end hover
				$this->end_controls_tab();

			// end tabs
			$this->end_controls_tabs();

		// end title section
		$this->end_controls_section();


	} // end method



/**
	 * Render CSS Style
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */

   public function __construct($data = [], $args = null) {
      parent::__construct($data, $args);
      wp_register_style( 'lf-elementor', LF_DIR_URL . 'elementor/css/launchflows-elementor.css', false, '1.0.0');
   }

  public function get_style_depends() {
     return [ 'lf-elementor' ];
  }

/**
	 * Render shortcode widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 3.2.2
	 * @access protected
	 */

	protected function render() {

		$settings = $this->get_settings_for_display();

		// full shortcode
		$content = $this->get_settings( 'content' );

	    // hide title from elementor field
		$hide_content = $this->get_settings( 'hide_content' );
	
	    // hide title from elementor field
		$new_title = $this->get_settings( 'new_title' );

		// trim brackets from shortcode for css and string generation
		$css = trim($content, "[]");


		// new title
		if ( $new_title !=='' ) {
		
			$new_title = '<h3 class="new-title">'. $settings['new_title'] . '</h3>';
		
		} else {

			$new_title = '';

		}	

		$content = '['.$css .' ]';

		// output shortcode string
		$shortcode = do_shortcode( shortcode_unautop( $content ) );
	
		// For Testing Shortcode Output
		//echo $content;	


		// hide content
		if ('yes' === $hide_content ) {

			if(is_admin()) {
				
			?>

				<div id="<?php echo $css; ?>" class="admin-only content-hidden">
			   <img src="<?php echo LF_DIR_URL; ?>elementor/images/lf-logo.png" style="width:100px"></img>
    			<style>.elementor-editor-active #<?php echo $css; ?> {background: repeating-linear-gradient( 45deg, #fefefe, #fefefe 10px, #efefef 10px, #efefef 20px )}</style>
				<h3 style="margin:0!important; font-size:21px;"><?php echo __('HIDDEN ON FRONT','lf'); ?></h3>
				<div></div>
				</div>

			<?php


			} // end admin check

			// display then hide on front
			echo '<div class="lf-hide">';
			echo $shortcode;
			echo '</div>';

		} else {

		?>

				<div class="lf-shortcode" >

				<?php echo $new_title; ?>
				
				<?php if(is_admin()) { ?>
	
					<div id="<?php echo $css; ?>" class="admin-only">
		
					<div></div>
		
					</div>

				<?php }	?>

				<?php echo $shortcode; ?>

				</div>

		<?php	

		} // end hide content check
	    

	} // end render


} //end	widget