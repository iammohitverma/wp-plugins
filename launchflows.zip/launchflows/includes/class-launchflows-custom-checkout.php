<?php
class LFCustomCheckout
{

    /**
     * Method to kickstart the code.
     *
     * @return void
     */
    public static function start()
    {
        new LFCustomCheckout;
    }

    /**
     * Adds all necessary action hooks
     */
    private function __construct()
    {
        // The field
        add_action('woocommerce_process_product_meta', array(
            $this,
            'saveProductGeneralTabField'
        ));
        add_filter('woocommerce_add_to_cart_redirect', array(
            $this,
            'redirects'
        ));

        // auto hinting functions
        add_action('admin_enqueue_scripts', array(
            $this,
            'include_javascript'
        ));
        add_action('wp_ajax_wc-checkout-hint', array(
            $this,
            'hint_checkout_pages'
        ));
    }

    /**
     * Includes the checkout hinting JS file on single edit pages.
     *
     * @access public
     * @param  string $hook Page hook.
     */

    public function include_javascript($hook)
    {

        // bail if not on admin or our function doesnt exist.
        if (!is_admin() || !function_exists('get_current_screen'))
        {
            return;
        }

        // get my current screen.
        $screen = get_current_screen();

        // bail without.
        if (empty($screen) || !is_object($screen))
        {
            return;
        }

        // make sure we are on the wc single product editor
        if ('post' !== $screen->base || 'product' !== $screen->post_type)
        {
            return;
        }

        // load the js file
        wp_enqueue_script('lf_wc_checkout_redirect-hinting', LF_DIR_URL . "assets/js/checkout-hint.js", array(
            'jquery',
            'jquery-ui-autocomplete'
        ) , '1.05', true);
    }

    /**
     * Prints out the page hints in JSON format.
     */

    public function hint_checkout_pages()
    {

        // Set our search param.
        $search = isset($_REQUEST['search']) ? sanitize_text_field(wp_unslash($_REQUEST['search'])) : '';

        // Set our query args.
        $query = new \WP_Query(array(
            //              'post_type'      => array('page'),
            'post_Type' => 'any', // any post type
            'posts_per_page' => 15,
            's' => $search,
        ));

        // bail if we have no posts
        if (is_wp_error($query) || empty($query->posts))
        {
            return false;
        }

        // set an empty for the result array.
        $result = array();

        // loop the results
        foreach ($query->posts as $post)
        {
            $result[] = array(
                'label' => $post->post_title,
                'value' => $post->ID,
            );
        }

        // return the results, JSON encoded
        echo wp_json_encode(array(
            'success' => true,
            'data' => $result,
        ));

        // And die.
        die();
    }

    /**
     * Saves the contents from the checkout page field
     *
     * @since 1.1.9
     * @param int $id Post ID.
     */

    public function saveProductGeneralTabField($post_id)
    {

        // Throw an error if the data wasn't saved.
        if (!isset($_REQUEST['_lf_checkout_field_id']) || !isset($_REQUEST['_lf_checkout_field']))
        {
            new \WP_Error('Necessary field values are not present');
            return;
        }

        // Set our page and label.
        $checkout_page = sanitize_text_field(wp_unslash($_REQUEST['_lf_checkout_field_id']));
        $checkout_page_label = trim(sanitize_text_field(wp_unslash($_REQUEST['_lf_checkout_field'])));

        if (0 === strpos($checkout_page_label, 'http'))
        {
            update_post_meta($post_id, '_lf_checkout_field', $checkout_page_label);
        }
        elseif (!empty($checkout_page))
        {
            update_post_meta($post_id, '_lf_checkout_field', $checkout_page);
        }
        else
        {
            update_post_meta($post_id, '_lf_checkout_field', '');
        }
    }

    /**
     *  Gets the appropriate redirect URL
     *
     *  @since 1.1.4
     *  @param (int) $product_id - Product ID
     *  @return (string) - Redirect URL if one is set, else empty string
     */

    public function get_redirect_url($product_id)
    {

        // Determine a post redirect
        $meta = get_post_meta($product_id, '_lf_checkout_field', true);

        $post_redirect = get_permalink((int)$meta); // gets url that matches this product_id
        if ($post_redirect)
        {
            $redirect_url = $post_redirect;
        }

        // Return final redirect URL
        return isset($redirect_url) ? esc_url_raw($redirect_url) : '';
    }

    /**
     *  Handle the appropriate redirects (no Ajax)
     */

    public function redirects($url)
    {

        $product_id = isset($_REQUEST['add-to-cart']) ? absint($_REQUEST['add-to-cart']) : false;

        if (!$product_id)
        {
            return $url;
        }

        $product_id = apply_filters('woocommerce_add_to_cart_product_id', $product_id);

        $redirect_url = $this->get_redirect_url($product_id);

        // Do the redirect
        if ($redirect_url)
        {
            wp_safe_redirect($redirect_url);
            exit;
        }
    }

} // end class wrapper

/**
 * Finally, start the class
 */

LFCustomCheckout::start();