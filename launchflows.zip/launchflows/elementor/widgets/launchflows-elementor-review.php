<?php
namespace LaunchFlowsElementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * LaunchFlows Elementor
 *
 * Elementor widget for LaunchFlows
 *
 * @since 1.0.0
 */
class LaunchFlowsElementorReview extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'lf-review';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'LaunchFlows Review', 'lf' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-purchase-summary';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.2.2
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'launchflows'];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'lf' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 3.2.2
	 *
	 * @access protected
	 */

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'lf' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);


			$this->add_control(
				'content',
				[
					'label' => __( 'Select Component To Add:', 'lf' ),
					'type' => Controls_Manager::HIDDEN,
					'default' => '[lf-review]',
				]

			);		

			$this->add_control(
				'hide_content',
				[
					'label' => __( 'Hide Order Review', 'lf' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Hide', 'lf' ),
					'label_off' => __( 'Show', 'lf' ),
					'return_value' => 'yes',
					'default' => 'no',
				]
			);

			$this->add_control(
				'hr_hide_content',
				[
					'type' => \Elementor\Controls_Manager::DIVIDER,
				]
			);	

			$this->add_control(
				'hide_title',
				[
					'label' => __( 'Hide Default Title', 'lf' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Hide', 'lf' ),
					'label_off' => __( 'Show', 'lf' ),
					'return_value' => 'yes',
					'default' => 'no',			
				]
			);

			$this->add_control(
				'new_title',
				[
					'label' => __( 'Add New Title:', 'lf' ),
					'type' => Controls_Manager::TEXT,
					'input_type' => 'text',
					'placeholder' => __( 'My Custom Title', 'lf' ),	
				]
			);
			$this->add_control(
				'hr_new_title',
				[
					'type' => \Elementor\Controls_Manager::DIVIDER,
				]
			);	
			$this->add_control(
				'hide_header',
				[
					'label' => __( 'Hide Order Review Header', 'lf' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Hide', 'lf' ),
					'label_off' => __( 'Show', 'lf' ),
					'return_value' => 'yes',
					'default' => 'no',			
				]
			);
			$this->add_control(
				'hr_after_header',
				[
					'type' => \Elementor\Controls_Manager::DIVIDER,
				]
			);	
			$this->add_control(
				'hide_remove_link',
				[
					'label' => __( 'Hide Product Remove Links', 'lf' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Hide', 'lf' ),
					'label_off' => __( 'Show', 'lf' ),
					'return_value' => 'yes',
					'default' => 'no',			
				]
			);
			$this->add_control(
				'hide_product_image',
				[
					'label' => __( 'Hide Product Images', 'lf' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Hide', 'lf' ),
					'label_off' => __( 'Show', 'lf' ),
					'return_value' => 'yes',
					'default' => 'no',			
				]
			);
			$this->add_control(
				'hide_product_quantity',
				[
					'label' => __( 'Hide Product Quantities', 'lf' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Hide', 'lf' ),
					'label_off' => __( 'Show', 'lf' ),
					'return_value' => 'yes',
					'default' => 'no',			
				]
			);
			$this->add_control(
				'hr_product_image',
				[
					'type' => \Elementor\Controls_Manager::DIVIDER,
				]
			);	



			$this->add_control(
				'hide_discount',
				[
					'label' => __( 'Hide Discount', 'lf' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Hide', 'lf' ),
					'label_off' => __( 'Show', 'lf' ),
					'return_value' => 'yes',
					'default' => 'no',			
				]
			);
			$this->add_control(
				'hide_shipping',
				[
					'label' => __( 'Hide Shipping', 'lf' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Hide', 'lf' ),
					'label_off' => __( 'Show', 'lf' ),
					'return_value' => 'yes',
					'default' => 'no',			
				]
			);
			$this->add_control(
				'hide_fee',
				[
					'label' => __( 'Hide Fee', 'lf' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Hide', 'lf' ),
					'label_off' => __( 'Show', 'lf' ),
					'return_value' => 'yes',
					'default' => 'no',			
				]
			);				
			$this->add_control(
				'hr_before_cart_subtotal',
				[
					'type' => \Elementor\Controls_Manager::DIVIDER,
				]
			);	
			$this->add_control(
				'hide_cart_subtotal',
				[
					'label' => __( 'Hide Cart Subtotal', 'lf' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Hide', 'lf' ),
					'label_off' => __( 'Show', 'lf' ),
					'return_value' => 'yes',
					'default' => 'no',			
				]
			);	
			$this->add_control(
				'hr_before_total',
				[
					'type' => \Elementor\Controls_Manager::DIVIDER,
				]
			);	
			$this->add_control(
				'hide_tax',
				[
					'label' => __( 'Hide Tax', 'lf' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Hide', 'lf' ),
					'label_off' => __( 'Show', 'lf' ),
					'return_value' => 'yes',
					'default' => 'no',			
				]
			);	
			$this->add_control(
				'hr_before_hide_total',
				[
					'type' => \Elementor\Controls_Manager::DIVIDER,
				]
			);	
			$this->add_control(
				'hide_total',
				[
					'label' => __( 'Hide Total', 'lf' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Hide', 'lf' ),
					'label_off' => __( 'Show', 'lf' ),
					'return_value' => 'yes',
					'default' => 'no',			
				]
			);	
			$this->add_control(
				'hr_before_recurring_totals_header',
				[
					'type' => \Elementor\Controls_Manager::DIVIDER,
				]
			);	
			$this->add_control(
				'hide_recurring_totals_header',
				[
					'label' => __( 'Hide Recurring Totals Header', 'lf' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Hide', 'lf' ),
					'label_off' => __( 'Show', 'lf' ),
					'return_value' => 'yes',
					'default' => 'no',			
				]
			);

			$this->add_control(
				'hr_before_subtotal',
				[
					'type' => \Elementor\Controls_Manager::DIVIDER,
				]
			);								
			$this->add_control(
				'hide_cart_subtotal_recurring_total',
				[
					'label' => __( 'Hide Recurring Subtotal', 'lf' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Hide', 'lf' ),
					'label_off' => __( 'Show', 'lf' ),
					'return_value' => 'yes',
					'default' => 'no',			
				]
			);
			$this->add_control(
				'hr_before_tax',
				[
					'type' => \Elementor\Controls_Manager::DIVIDER,
				]
			);								
			$this->add_control(
				'hide_recurring_tax',
				[
					'label' => __( 'Hide Recurring Tax', 'lf' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Hide', 'lf' ),
					'label_off' => __( 'Show', 'lf' ),
					'return_value' => 'yes',
					'default' => 'no',			
				]
			);
			$this->add_control(
				'hr_before_recurring_total',
				[
					'type' => \Elementor\Controls_Manager::DIVIDER,
				]
			);								
			$this->add_control(
				'hide_recurring_total',
				[
					'label' => __( 'Hide Recurring Total', 'lf' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Hide', 'lf' ),
					'label_off' => __( 'Show', 'lf' ),
					'return_value' => 'yes',
					'default' => 'no',			
				]
			);

					
		$this->end_controls_section();


		// title style
		$this->start_controls_section(
				'title',
				[
					'label' => __( 'New Title', 'lf' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				]
			);


			$this->start_controls_tabs(
					'style_tabs_title'
				);

				// normal tab
				$this->start_controls_tab(
						'style_normal_tab_title',
						[
							'label' => __( 'Normal', 'lf' ),
						]
					);

					// title - normal tab
					$this->add_group_control(
						\Elementor\Group_Control_Typography::get_type(),
						[
							'name'					=> 'title_typography',
							'label'					=> __( 'Typography', 'lf' ),
							'selector'				=> '{{WRAPPER}} .new-title'
						]
					);
					$this->add_control(
						'title_text_color',
						[
							'label' => __( 'Text Color', 'lf' ),
							'type' => Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .new-title' => 'color: {{VALUE}}',
							],
						]
					);
					$this->add_control(
						'title_background_color',
						[
							'label' => __( 'Background Color', 'lf' ),
							'type' => Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .new-title' => 'background-color: {{VALUE}};',
								'{{WRAPPER}} .new-title::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
							],
						]
					);

					$this->add_responsive_control(
						'title_margin',
						[
							'label' => __( 'Margin', 'lf' ),
							'type' => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'allowed_dimensions' => 'vertical',
							'selectors' => [
								'{{WRAPPER}} .new-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_responsive_control(
						'title_padding',
						[
							'label' => __( 'Padding', 'lf' ),
							'type' => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors' => [
								'{{WRAPPER}} .new-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_control(
						'hr_title_normal',
						[
							'type' => \Elementor\Controls_Manager::DIVIDER,
						]
					);	
					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'title_border',
							'label' => __( 'Border', 'lf' ),
							'selector' => '{{WRAPPER}} .new-title',
						]
					);
					$this->add_responsive_control(
						'title_border_radius',
						[
							'label' => __( 'Border Radius', 'lf' ),
							'type' => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%' ],
							'selectors' => [
								'{{WRAPPER}} .new-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);	
				// end normal
				$this->end_controls_tab();


				// hover tab
				$this->start_controls_tab(
					'style_hover_tab_title',
					[
						'label' => __( 'Hover', 'lf' ),
					]
				);

					$this->add_group_control(
						Group_Control_Typography::get_type(),
						[
							'name'					=> 'title_typography_hover',
							'label'					=> __( 'Typography', 'lf' ),
							'selector'				=> '{{WRAPPER}} .lf-review h3.new-title'
						]
					);
					
					$this->add_control(
						'title_text_color_hover',
						[
							'label' => __( 'Text Color', 'lf' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .new-title:hover' => 'color: {{VALUE}}',
							],
						]
					);
					$this->add_control(
						'title_background_color_hover',
						[
							'label' => __( 'Background Color', 'lf' ),
							'type' => Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .new-title:hover' => 'background-color: {{VALUE}};',
								'{{WRAPPER}} .new-title:hover::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
							],
						]
					);
					$this->add_control(
						'hr_title_hover',
						[
							'type' => \Elementor\Controls_Manager::DIVIDER,
						]
					);					
					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'title_border_hover',
							'label' => __( 'Border', 'lf' ),
							'selector' => '{{WRAPPER}} .new-title:hover',
						]
					);

					$this->add_responsive_control(
						'title_border_radius_hover',
						[
							'label' => __( 'Border Radius', 'lf' ),
							'type' => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%' ],
							'selectors' => [
								'{{WRAPPER}} .new-title:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);	
		
				// end hover
				$this->end_controls_tab();

			// end tabs
			$this->end_controls_tabs();

		// end title section
		$this->end_controls_section();


	} // end method



/**
	 * Render CSS Style
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */

   public function __construct($data = [], $args = null) {
      parent::__construct($data, $args);
      wp_register_style( 'lf-elementor', LF_DIR_URL . 'elementor/css/launchflows-elementor.css', false, '1.0.0');
   }

  public function get_style_depends() {
     return [ 'lf-elementor' ];
  }

/**
	 * Render shortcode widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 3.3.4
	 * @access protected
	 */

	protected function render() {

		$settings = $this->get_settings_for_display();

		$content = $this->get_settings( 'content' );

		$hide_content = $this->get_settings( 'hide_content' );
	
		$hide_title = $this->get_settings( 'hide_title' );

		$hide_remove_link = $this->get_settings( 'hide_remove_link' );

		$hide_product_image = $this->get_settings( 'hide_product_image' );

		$hide_product_quantity = $this->get_settings( 'hide_product_quantity' );

		$hide_header = $this->get_settings( 'hide_header' );

		$hide_discount = $this->get_settings( 'hide_discount' );

		$hide_shipping = $this->get_settings( 'hide_shipping' );

		$hide_fee = $this->get_settings( 'hide_fee' );

		$hide_tax = $this->get_settings( 'hide_tax' );

		$hide_recurring_tax = $this->get_settings( 'hide_recurring_tax' );

		$hide_recurring_totals_header = $this->get_settings( 'hide_recurring_totals_header' );

		$hide_total = $this->get_settings( 'hide_total' );

		$hide_cart_subtotal = $this->get_settings( 'hide_cart_subtotal' );

		$hide_cart_subtotal_recurring_total = $this->get_settings( 'hide_cart_subtotal_recurring_total' );

		$hide_recurring_totals = $this->get_settings( 'hide_recurring_totals' );

		$hide_recurring_total = $this->get_settings( 'hide_recurring_total' );

		$new_title = $this->get_settings( 'new_title' );

		$css = trim($content, "[]");

		// hide title
		if ( 'yes' === $hide_title ) {
		
			$hide_title = 'h3#order_review_heading {display:none;}';
		
		} else {

			$hide_title = '';
		}	

		if ( 'yes' === $hide_remove_link ) {
		
			$hide_remove_link = 'a.remove {display: none!important;}';
		
		} else {

			$hide_remove_link = '';
		}

		if ( 'yes' === $hide_product_image ) {
		
			$hide_product_image = '.lf-product-image {display: none!important;}';
		
		} else {

			$hide_product_image = '';
		}

		if ( 'yes' === $hide_product_quantity ) {
		
			$hide_product_quantity = '.lf-review .quantity {display: none!important;}';
		
		} else {

			$hide_product_quantity = '';
		}

		if ( 'yes' === $hide_header ) {
		
			$hide_header = '#order_review thead {display: none;}';
		
		} else {

			$hide_header = '';
		}	

		if ( 'yes' === $hide_discount ) {
		
			$hide_discount = '.cart-discount {display: none;}';
		
		} else {

			$hide_discount = '';
		}	


		if ( 'yes' === $hide_shipping ) {
		
			$hide_shipping = '.woocommerce-shipping-totals.shipping {display: none;}';
		
		} else {

			$hide_shipping = '';
		}	



		// fee
		if ( 'yes' === $hide_fee ) {
		
			$hide_fee = '.fee {display: none;}';
		
		} else {

			$hide_fee = '';
		}	


		// tax
		if ( 'yes' === $hide_cart_subtotal ) {
		
			$hide_cart_subtotal = 'tr.cart-subtotal:first-child {display: none!important;}';
		
		} else {

			$hide_cart_subtotal = '';
		}	

		// tax
		if ( 'yes' === $hide_tax ) {
		
			$hide_tax = 'tr.tax-rate {display: none!important;}';
		
		} else {

			$hide_tax = '';
		}	

		// order total
		if ( 'yes' === $hide_total ) {
		
			$hide_total = 'tr.order-total:not(.recurring-total) {display: none!important;}';
		
		} else {

			$hide_total = '';
		}	

		// recurring totals header
		if ( 'yes' === $hide_recurring_totals_header ) {
		
			$hide_recurring_totals_header = 'tr.recurring-totals {display: none!important;}';
		
		} else {

			$hide_recurring_totals_header = '';
		}	

		// recurring cart subtotal
		if ( 'yes' === $hide_cart_subtotal_recurring_total ) {
		
			$hide_cart_subtotal_recurring_total = 'tr.cart-subtotal.recurring-total {display: none!important;}';
		
		} else {

			$hide_cart_subtotal_recurring_total = '';
		}	

		// recurring tax
		if ( 'yes' === $hide_recurring_tax ) {
		
			$hide_recurring_tax = 'tr.tax-rate.recurring-total {display: none!important;}';
		
		} else {

			$hide_recurring_tax = '';
		}	

		// recurring total
		if ( 'yes' === $hide_recurring_total ) {
		
			$hide_recurring_total = 'tr.order-total.recurring-total {display: none!important;}';
		
		} else {

			$hide_recurring_total = '';
		}	

		// title
		if ( $new_title !=='' ) {
		
			$new_title = '<h3 class="new-title">'. $settings['new_title'] . '</h3>';
		
		} else {

			$new_title = '';

		}	

		$content = '['.$css .' ]';

		// output shortcode string
		$shortcode = do_shortcode( shortcode_unautop( $content ) );
	
		// For Testing Shortcode Output
		//echo $content;	


		// hide content
		if ('yes' === $hide_content ) {

			if(is_admin()) {
				
			?>

				<div id="<?php echo $css; ?>" class="admin-only content-hidden">
			   <img src="<?php echo LF_DIR_URL; ?>elementor/images/lf-logo.png" style="width:100px"></img>
    			<style>.elementor-editor-active #<?php echo $css; ?> {background: repeating-linear-gradient( 45deg, #fefefe, #fefefe 10px, #efefef 10px, #efefef 20px )}</style>
				<h3 style="margin:0!important; font-size:21px;"><?php echo __('HIDDEN ON FRONT','lf'); ?></h3>
				<div></div>
				</div>

			<?php


			} // end admin check

			// display then hide on front
			echo '<div class="lf-hide">';
			echo $shortcode;
			echo '</div>';

		} else {

		?>

				<div class="lf-shortcode" >

				<style>
				<?php echo $hide_title; ?>

				<?php echo $hide_header; ?>

				<?php echo $hide_remove_link; ?>

				<?php echo $hide_product_image; ?>

				<?php echo $hide_product_quantity; ?>

				<?php echo $hide_discount; ?>

				<?php echo $hide_shipping; ?>

				<?php echo $hide_fee; ?>

				<?php echo $hide_cart_subtotal; ?>

				<?php echo $hide_tax; ?>

				<?php echo $hide_total; ?>

				<?php echo $hide_recurring_totals_header; ?>

				<?php echo $hide_cart_subtotal_recurring_total; ?>

				<?php echo $hide_recurring_tax; ?>

				<?php echo $hide_recurring_total; ?>				
				</style>

				<?php echo $new_title; ?>
				
				<?php if(is_admin()) { ?>

					<?php if ($hide_title === '') { ?>
	
						<h3><?php esc_html_e( 'Your Order', 'woocommerce' ); ?></h3>
	
					<?php } ?>
	
					<div id="<?php echo $css; ?>" class="admin-only">
		
					<div></div>
		
					</div>

				<?php }	?>

				<?php echo $shortcode; ?>

				</div>

		<?php	

		} // end hide content check
	    

	} // end render


} //end	widget