<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

/**
 * LaunchFlowsWPFusion Class
 *
 *
 * @since 3.4.8
 */

class LaunchFlowsWPF {


  /**
   * Constructor
   *
   * @since 3.3.2
   * @access public
   */

  public function __construct() {

    add_shortcode( 'lf-apply-tags',       array ($this, 'lf_layout_apply_tags' ), 10 );
    add_shortcode( 'lf-remove-tags',      array ($this, 'lf_layout_remove_tags' ), 11 );
  
  } // end construct





/**
   * Apply WPFusion Tag When Viewing Widget
   *
   * @since 3.4.8
   * @access public
   */

public function lf_layout_apply_tags($atts, $tags) {

if(!is_admin()) {

    $a = shortcode_atts( array(

     'tags'   => false,
     'debug'  => false,

    ), $atts, 'lf-apply-tags' );


    if ( $a['tags'] ) {

        // parse type into an array, whitespace will be stripped
        $tags = array_map( 'trim', str_getcsv( $a['tags'], ',' ) );
    
    }

    // apply tags
    wp_fusion()->user->apply_tags( $tags ); 

  
    // optional for debug: show on front end
    if($a['debug']=='yes') {

ob_start();

        echo '<span id="lf-apply-tags" class="tags-wrapper">';

          // confirm
          if (wp_fusion()->user->apply_tags( $tags )) {

            echo '<img class="wpf-logo" src="'.LF_DIR_URL.'/elementor/images/wpfusion.png"></img><br/>';

            echo '<strong>'.__('Applied: ','lf').'</strong><br/><span class="wpf-tags">'. $a['tags'].'</span>';

          } else {

            echo '<strong>'.__('Not Applied: ','lf').'</strong><br/><span class="wpf-tags">'. $a['tags'].'</span>';

          }

        echo '<br/>';
        echo '<strong>'.__('User Has: ', 'lf').'</strong><br/>';
        $tags = wp_fusion()->user->get_tags();
          foreach ($tags as $tag) {
             echo $tag; 
             echo ",";
          } 

        echo '</span>';

$output = ob_get_contents();   
ob_end_clean();   
return $output;

    } // end debug



  }//end admin

}

/**
   * Remove WPFusion Tag When Viewing Widget
   *
   * @since 3.3.2
   * @access public
   */

public function lf_layout_remove_tags($atts, $tags) {

if(!is_admin()) {

    $a = shortcode_atts( array(

     'tags'   => false,
     'debug'  => false,

    ), $atts, 'lf-remove-tags' );


    if ( $a['tags'] ) {

        // parse type into an array, whitespace will be stripped
        $tags = array_map( 'trim', str_getcsv( $a['tags'], ',' ) );
    
    }

    // apply tags
    wp_fusion()->user->remove_tags( $tags ); 

  
    // optional for debug: show on front end
    if($a['debug']=='yes') {
      
ob_start();

        echo '<span id="lf-remove-tags" class="tags-wrapper">';

          // confirm
          if (wp_fusion()->user->remove_tags( $tags )) {

            echo '<img class="wpf-logo" src="'.LF_DIR_URL.'/elementor/images/wpfusion.png"></img><br/>';

            echo '<strong>'.__('Removed: ','lf').'</strong><br/><span class="wpf-tags">'. $a['tags'].'</span>';

          } else {

            echo '<strong>'.__('Not Removed: ','lf').'</strong><br/><span class="wpf-tags">'. $a['tags'].'</span>';

          }

        echo '<br/>';
        echo '<strong>'.__('User Has: ', 'lf').'</strong><br/>';
        $tags = wp_fusion()->user->get_tags();
          foreach ($tags as $tag) {
             echo $tag; 
             echo ",";
          } 

        echo '</span>';

$output = ob_get_contents();   
ob_end_clean();   
return $output;

    } // end debug

  }//end admin

}


// save
} // instantiates class
new LaunchFlowsWPF;