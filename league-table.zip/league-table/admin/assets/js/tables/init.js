(function($) {

  //This object is used to save all the variable states of the menu
  window.DALT.states = {

    dalt_hot: false,
    synthetic_clipboard: null,
    cell_properties_message_timeout_handler: null,
    table_message_timeout_handler: null,
    tableToDelete: null,

  };

  bindEventListeners();

  /**
   * Bind the event listeners.
   */
  function bindEventListeners() {

    $(document).ready(function() {

      window.DALT.utility.initialize_handsontable();
      window.DALT.utility.initialize_chosen();
      window.DALT.utility.remove_border_last_element_daext_form_table();
      window.DALT.utility.responsive_sidebar_container();
      window.DALT.utility.disable_specific_keyboard_shortcuts();
      window.DALT.utility.refresh_cell_properties_highlight();

      $('#save').click(function() {

        var reload_menu = parseInt($(this).data('reload-menu'), 10) == 1 ? true : false;
        var validation_result = window.DALT.utility.save_table(reload_menu);

        //show error message
        if (validation_result === true) {

          if (reload_menu === false) {

            //hide error message
            $('#table-error p').html('');
            $('#table-error').hide();

            //display temporary success message
            $('#table-success p').text(objectL10n.table_success);
            $('#table-success').show();
            clearTimeout(window.DALT.states.table_message_timeout_handler);
            window.DALT.states.table_message_timeout_handler = setTimeout(function() { $('#table-success').hide(); },
                3000);

          }

        } else {

          //display error message
          $('#table-error p').
              html(objectL10n.table_error_partial_message + ' <strong>' + validation_result.join(', ') + '</strong>');
          $('#table-error').show();

        }

      });

      $('#close').click(function() {

        //reload the dashboard menu
        window.location.replace(dalt_admin_url + 'admin.php?page=dalt-tables');

      });

      $('#rows').change(function() {

        window.DALT.utility.update_rows();

      });

      $('#columns').change(function() {

        window.DALT.utility.update_columns();
        window.DALT.utility.update_order_by();

      });

      $('.update-reset-cell-properties').click(function(event) {

        var element_id = $(this).attr('id');

        window.DALT.utility.update_reset_cell_properties(element_id);

      });

      $('.group-trigger').click(function() {

        //open and close the various sections of the tables area
        var target = $(this).attr('data-trigger-target');
        $('.' + target).toggle();
        $(this).find('.expand-icon').toggleClass('arrow-down');

        window.DALT.utility.remove_border_last_element_daext_form_table();

      });

      jQuery(window).resize(function() {

        window.DALT.utility.responsive_sidebar_container();

      });

      $(function() {
        $('.dialog-alert').dialog({
          autoOpen: false,
          resizable: false,
          height: 'auto',
          width: 340,
          modal: true,
          buttons: [
            {
              tabIndex: -1,
              text: 'Close',
              click: function() {
                $(this).dialog('close');
              },
            },
          ],
        });
      });

      //Dialog Confirm ---------------------------------------------------------------------------------------------------

      /**
       * Original Version (not compatible with pre-ES5 browser)
       */
      // $(function() {
      //   $('#dialog-confirm').dialog({
      //     autoOpen: false,
      //     resizable: false,
      //     height: 'auto',
      //     width: 340,
      //     modal: true,
      //     buttons: {
      //       [objectL10n.delete]: function() {
      //         $('#form-delete-' + window.DALT.states.tableToDelete).submit();
      //       },
      //       [objectL10n.cancel]: function() {
      //         $(this).dialog('close');
      //       },
      //     },
      //   });
      // });

      /**
       *
       * Compiled Version (compatible with pre-ES5 browser and ES5 browsers)
       *
       * Version compiled with Babel (https://babeljs.io).
       *
       * The reason is that dynamic property names (in this case [objectL10n.deleteText] and [objectL10n.cancelText] are not
       * supported with pre-ES5 JavaScript engines.
       */
      "use strict";

      function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

      $(function () {
        var _buttons;

        $('#dialog-confirm').dialog({
          autoOpen: false,
          resizable: false,
          height: 'auto',
          width: 340,
          modal: true,
          buttons: (_buttons = {}, _defineProperty(_buttons, objectL10n.delete, function () {
            $('#form-delete-' + window.DALT.states.tableToDelete).submit();
          }), _defineProperty(_buttons, objectL10n.cancel, function () {
            $(this).dialog('close');
          }), _buttons)
        });
      });

      //Click event handler on the delete button
      $('.menu-icon.delete').click(function(event) {
        event.preventDefault();
        window.DALT.states.tableToDelete = $(this).prev().val();
        $('#dialog-confirm').dialog('open');
      });

    });

  }

}(window.jQuery));