<?php

class FeaturedProductClass {

/**
     * Constructor
     *
     * @since 3.5.3
     *
     * @return void
     */

public function __construct() {

// for custom shortcode metabox
add_action( 'add_meta_boxes', array ($this, 'lf_checkout_link_meta_box'), 10, 2  );
  }


public function lf_checkout_link_meta_box( $post_id, $data ) {
  $label = __('LaunchFlows Checkout Link','lf');
  add_meta_box( 
    'lf-direct-checkout-link', 
    $label, 
    array($this, 'lf_direct_checkout_metabox_callback'), // triggers output function
    'product', 
    'side', 
    'high' 
    );
}


public function lf_direct_checkout_metabox_callback( $post ) {
        global $post;

        // check for the meta key for the checkout page field
        $meta = get_post_meta( $post->ID, '_lf_checkout_field', true );

        // if no meta, bail to default wc behavior
        if ( empty( $meta ) ) {
        
        // use default wc checkout url instead of custom 
        $checkout_url = get_permalink( wc_get_page_id( 'checkout' ) ); 

        } else {

        // otherwise, get the meta permalink
        $checkout_url = get_permalink( (int) $meta );
        }
    ?>
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.0/clipboard.min.js"></script>

        <script type="text/javascript">
        var clipboard = new ClipboardJS('.checkoutLinkBtn');
        clipboard.on('success', function(e) {
            console.log(e);
        });
        clipboard.on('error', function(e) {
            console.log(e);
        });
        </script>

        <label class="screen-reader-text" for="direct-checkout-link"><?php _e('Use With Any Button Or Clickable Element','lf'); ?></label>
        <label style="font-size:12px; color: #ababab;" for="direct-checkout-link"><?php _e('Use With Any Button Or Clickable Element','lf'); ?></label>
         <p>
      <?php if ( ! empty ( $checkout_url ) ) { 
      // output link to custom checkout page
      ?>
        <input type="text" id="checkoutLink" size="30" aria-describedby="direct-checkout-link" value="<?php echo $checkout_url . '?add-to-cart=' . $post->ID; ?>">
      <?php
      }       
      ?>
        <input style="margin-top: 3px;" type="button" class="button checkoutLinkBtn" data-clipboard-target="#checkoutLink" value="Copy">
        </p>
    <?php 
    } 


} // leave in place
/**
 * Finally, instantiate the class
 */

new FeaturedProductClass;