<?php
namespace LaunchFlowsElementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * LaunchFlows Elementor
 *
 * Elementor widget for LaunchFlows
 *
 * @since 1.0.0
 */
class LaunchFlowsElementorStyleManager extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'lf2';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'LaunchFlows Style Manager', 'lf' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-animated-headline';
	}


	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.2.2
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {

		return [ 'launchflows'];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'lf' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 2.0.0
	 *
	 * @access protected
	 */

	protected function _register_controls() {
	
	// Typography Section
	$this->start_controls_section(
		'style_section',
		[
			'label' => __( 'Typography (Unless Overriden Below)', 'lf' ),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
		]
	);

			// font family
			$this->add_control(
				'font_family',
				[
					'label' => __( 'Font Family', 'lf' ),
					'type' => \Elementor\Controls_Manager::FONT,
					'default' => 'Default',
					'selectors' => [
						'{{WRAPPER}} ' => 'font-family: {{VALUE}}',
					],
				]
			);

			// font size
			$this->add_control(
				'font_size',
				[
					'label' => __( 'Font Size', 'lf' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px', 'em', 'rem', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 150,
							'step' => .5,
						],
						'em' => [
							'min' => 0,
							'max' => 10,
							'step' => .1,
						],									
						'rem' => [
							'min' => 0,
							'max' => 10,
							'step' => .1,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => '%',
						'size' => 100,
					],
					'selectors' => [
						'{{WRAPPER}} ' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
			'text_color',
				[
					'label' => __( 'Text Color', 'lf' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'scheme' => [
						'type' => \Elementor\Scheme_Color::get_type(),
						'value' => \Elementor\Scheme_Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} ' => 'color: {{VALUE}}',
						'{{WRAPPER}}  p' => 'color: {{VALUE}}',

					],
				]
			);

			$this->add_control(
			'link_color',
				[
					'label' => __( 'Link Color', 'lf' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'scheme' => [
						'type' => \Elementor\Scheme_Color::get_type(),
						'value' => \Elementor\Scheme_Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} a' => 'color: {{VALUE}}',
					],
				]
			);

// end Typography Section
	$this->end_controls_section();


// Fields Section
	$this->start_controls_section(
		'colors_section',
		[
			'label' => __( 'Fields', 'lf' ),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
		]
	);

			// label font size
			$this->add_control(
				'label_font_size',
				[
					'label' => __( 'Label Size', 'lf' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px', 'em', 'rem', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 150,
							'step' => .5,
						],
						'em' => [
							'min' => 0,
							'max' => 10,
							'step' => .1,
						],									
						'rem' => [
							'min' => 0,
							'max' => 10,
							'step' => .1,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => '%',
						'size' => 100,
					],
					'selectors' => [
						'{{WRAPPER}} label' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);

			// field font size
			$this->add_control(
				'field_font_size',
				[
					'label' => __( 'Field Size', 'lf' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px', 'em', 'rem', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 150,
							'step' => .5,
						],
						'em' => [
							'min' => 0,
							'max' => 10,
							'step' => .1,
						],									
						'rem' => [
							'min' => 0,
							'max' => 10,
							'step' => .1,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => '%',
						'size' => 100,
					],
					'selectors' => [
						'{{WRAPPER}} .input-text' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);
		

		$this->add_control(
		'label_color',
			[
				'label' => __( 'Label Color', 'lf' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .label' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'input_text_color',
			[
				'label' => __( 'Field Color', 'lf' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .input-text' => 'color: {{VALUE}}',
				],
			]
		);

		// placeholder
		$this->add_control(
			'placeholder_text_color',
			[
				'label' => __( 'Placeholder Color', 'lf' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} ' => 'color: {{VALUE}}',
				],
			]
		);


	// End Fields Section   
	$this->end_controls_section();


	// Buttons Section
	$this->start_controls_section(
		'buttons_section',
		[
			'label' => __( 'Buttons', 'lf' ),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
		]
	);

		// Place Order Button Size
		$this->add_control(
			'place_order_button_font_size',
			[
				'label' => __( 'Checkout Button Font Size', 'lf' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 150,
						'step' => .5,
					],
					'em' => [
						'min' => 0,
						'max' => 10,
						'step' => .1,
					],									
					'rem' => [
						'min' => 0,
						'max' => 10,
						'step' => .1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} #place_order' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// Donate Button Size
		$this->add_control(
			'donate_button_font_size',
			[
				'label' => __( 'Donate Button Font Size', 'lf' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 150,
						'step' => .5,
					],
					'em' => [
						'min' => 0,
						'max' => 10,
						'step' => .1,
					],									
					'rem' => [
						'min' => 0,
						'max' => 10,
						'step' => .1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} #lf-donate-button' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'emptycart_button_font_size',
			[
				'label' => __( 'Empty Cart Button Font Size', 'lf' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 150,
						'step' => .5,
					],
					'em' => [
						'min' => 0,
						'max' => 10,
						'step' => .1,
					],									
					'rem' => [
						'min' => 0,
						'max' => 10,
						'step' => .1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} #lf-emptycart a.button' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'coupon_button_font_size',
			[
				'label' => __( 'Coupon Button Font Size', 'lf' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 150,
						'step' => .5,
					],
					'em' => [
						'min' => 0,
						'max' => 10,
						'step' => .1,
					],									
					'rem' => [
						'min' => 0,
						'max' => 10,
						'step' => .1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .lf-wccoupon button' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

// Start Controls Tabs For Normal / Hover
$this->start_controls_tabs(
		'style_tabs'
	);

		$this->start_controls_tab(
			'style_normal_tab',
			[
				'label' => __( 'Normal', 'lf' ),
			]
		);

			// Order Button
			$this->add_control(
				'place_order_button_bg',
				[
					'label' => __( 'Checkout Button Background', 'lf' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'scheme' => [
						'type' => \Elementor\Scheme_Color::get_type(),
						'value' => \Elementor\Scheme_Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} #place_order' => 'background-color: {{VALUE}}',
					],
				]
			);				

			$this->add_control(
				'place_order_button_text',
				[
					'label' => __( 'Checkout Button Text', 'lf' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'scheme' => [
						'type' => \Elementor\Scheme_Color::get_type(),
						'value' => \Elementor\Scheme_Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} #place_order' => 'color: {{VALUE}}',
					],
				]
			);				

			// Donate Button
			$this->add_control(
				'donate_button_bg',
				[
					'label' => __( 'Donate Button Background', 'lf' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'scheme' => [
						'type' => \Elementor\Scheme_Color::get_type(),
						'value' => \Elementor\Scheme_Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} #lf-donate-button' => 'background-color: {{VALUE}}',
					],
				]
			);				

			$this->add_control(
				'donate_button_text',
				[
					'label' => __( 'Donate Button Text', 'lf' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'scheme' => [
						'type' => \Elementor\Scheme_Color::get_type(),
						'value' => \Elementor\Scheme_Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} #lf-donate-button' => 'color: {{VALUE}}',
					],
				]
			);				


			// Empty Cart Button
			$this->add_control(
				'emptycart_button_bg',
				[
					'label' => __( 'Empty Cart Button Background', 'lf' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'scheme' => [
						'type' => \Elementor\Scheme_Color::get_type(),
						'value' => \Elementor\Scheme_Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} #lf-emptycart a.button' => 'background-color: {{VALUE}}',
					],
				]
			);				

			$this->add_control(
				'emptycart_button_text',
				[
					'label' => __( 'Empty Cart Button Text', 'lf' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'scheme' => [
						'type' => \Elementor\Scheme_Color::get_type(),
						'value' => \Elementor\Scheme_Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} #lf-emptycart a.button' => 'color: {{VALUE}}',
					],
				]
			);

			// Coupon Button
			$this->add_control(
				'coupon_button_bg',
				[
					'label' => __( 'Coupon Button Background', 'lf' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'scheme' => [
						'type' => \Elementor\Scheme_Color::get_type(),
						'value' => \Elementor\Scheme_Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} #lf-wccoupon a.button' => 'background-color: {{VALUE}}',
					],
				]
			);				

			$this->add_control(
				'coupon_button_text',
				[
					'label' => __( 'Coupon Button Text', 'lf' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'scheme' => [
						'type' => \Elementor\Scheme_Color::get_type(),
						'value' => \Elementor\Scheme_Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} #lf-wccoupon a.button' => 'color: {{VALUE}}',
					],
				]
			);

		// End Normal Tab
		$this->end_controls_tab();

		// Start Hover Tab
		$this->start_controls_tab(
			'style_hover_tab',
			[
				'label' => __( 'Hover', 'lf' ),
			]
		);

			// Order Button
			$this->add_control(
				'place_order_button_bg_hover',
				[
					'label' => __( 'Order Button Background', 'lf' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'scheme' => [
						'type' => \Elementor\Scheme_Color::get_type(),
						'value' => \Elementor\Scheme_Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} #place_order:hover' => 'background-color: {{VALUE}}',
					],
				]
			);				

			$this->add_control(
				'place_order_button_text_hover',
				[
					'label' => __( 'Order Button Text', 'lf' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'scheme' => [
						'type' => \Elementor\Scheme_Color::get_type(),
						'value' => \Elementor\Scheme_Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} #place_order:hover' => 'color: {{VALUE}}',
					],
				]
			);				

			// Donate Button
			$this->add_control(
				'donate_button_bg_hover',
				[
					'label' => __( 'Donate Button Background', 'lf' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'scheme' => [
						'type' => \Elementor\Scheme_Color::get_type(),
						'value' => \Elementor\Scheme_Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} #lf-donate-button:hover' => 'background-color: {{VALUE}}',
					],
				]
			);				

			$this->add_control(
				'donate_button_text_hover',
				[
					'label' => __( 'Donate Button Text', 'lf' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'scheme' => [
						'type' => \Elementor\Scheme_Color::get_type(),
						'value' => \Elementor\Scheme_Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} #lf-donate-button:hover' => 'color: {{VALUE}}',
					],
				]
			);		

			// Empty Cart Button
			$this->add_control(
				'emptycart_button_bg_hover',
				[
					'label' => __( 'Empty Cart Button Background', 'lf' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'scheme' => [
						'type' => \Elementor\Scheme_Color::get_type(),
						'value' => \Elementor\Scheme_Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} #lf-emptycart a.button:hover' => 'background-color: {{VALUE}}',
					],
				]
			);				

			$this->add_control(
				'emptycart_button_text_hover',
				[
					'label' => __( 'Empty Cart Button Text', 'lf' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'scheme' => [
						'type' => \Elementor\Scheme_Color::get_type(),
						'value' => \Elementor\Scheme_Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} #lf-emptycart a.button:hover' => 'color: {{VALUE}}',
					],
				]
			);	

		$this->end_controls_tab();

$this->end_controls_tabs();

	// End Buttons Section
	$this->end_controls_section();


	// Images Widget Section
	$this->start_controls_section(
		'product_image_widget_section',
		[
			'label' => __( 'Images', 'lf' ),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
		]
	);

		// Product Image Width
		$this->add_control(
			'product_image_width',
			[
				'label' => __( 'Product Image Width', 'lf' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}}  .lf-shortcode > .lf-product-image img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// Product Image Align
		$this->add_control(
					'product_image_align',
					[
						'label' => __( 'Product Image Alignment', 'lf' ),
						'type' => \Elementor\Controls_Manager::CHOOSE,
						'options' => [
							'left' => [
								'title' => __( 'Left', 'plugin-name' ),
								'icon' => 'fa fa-align-left',
							],
							'center' => [
								'title' => __( 'Center', 'plugin-name' ),
								'icon' => 'fa fa-align-center',
							],
							'right' => [
								'title' => __( 'Right', 'plugin-name' ),
								'icon' => 'fa fa-align-right',
							],
						],
						'default' => 'left',
					]
		);

	// End Images Widget Section
	$this->end_controls_section();


	// Order Review Widget Section
	$this->start_controls_section(
		'order_review_widget_section',
		[
			'label' => __( 'Order Review', 'lf' ),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
		]
	);


		$this->add_control(
		'remove_product_link_color',
			[
				'label' => __( 'Remove Product Link Color', 'lf' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .lf-review a.remove' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'display_remove_product_link',
			[
				'label' => __( 'Display Remove Product Link (x)', 'lf' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'yes', 'lf' ),
				'label_off' => __( 'no', 'lf' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'display_featured_product_images',
			[
				'label' => __( 'Display Featured Product Images', 'lf' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'yes', 'lf' ),
				'label_off' => __( 'no', 'lf' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'display_featured_product_quantities',
			[
				'label' => __( 'Display Featured Product Quantities', 'lf' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'yes', 'lf' ),
				'label_off' => __( 'no', 'lf' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

	// End Order Review Widget Section
	$this->end_controls_section();

	// Bump Widget Section
	$this->start_controls_section(
		'dynamic_bump_widget_section',
		[
			'label' => __( 'Dynamic Bump', 'lf' ),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
		]
	);

		$this->add_control(
			'lf_bump_img_width',
			[
				'label' => __( 'Image Width (px)', 'lf' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 50,
				'max' => 1500,
				'step' => 10,
				'default' => 50,
			]
		);

		$this->add_control(
			'lf_bump_input_scale',
			[
				'label' => __( 'Checkbox Scale', 'lf' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 5,
				'step' => .5,
				'default' => 1.5,
			]
		);

		$this->add_control(
			'lf_bump_margin_right',
			[
				'label' => __( 'Checkbox Right Margin', 'lf' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 10,
				'max' => 50,
				'step' => 1,
				'default' => 10,
			]
		);


		$this->add_control(
			'lf_bump_product_title_left',
			[
				'label' => __( 'Product Title Left Margin ', 'lf' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 10,
				'max' => 50,
				'step' => 1,
				'default' => 10,
			]
		);

	// End Bump Widget Section
	$this->end_controls_section();

	// Payment Gateway Section
	$this->start_controls_section(
		'payment_gateway_section',
		[
			'label' => __( 'Gateways', 'lf' ),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
		]
	);

		$this->add_control(
			'hide_cc_icons',
			[
				'label' => __( 'Hide/Show Credit Cart Icons', 'lf' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_off' => __( 'Show', 'lf' ),
				'label_on' => __( 'Hide', 'lf' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);

		$this->add_control(
			'hide_pp_icons',
			[
				'label' => __( 'Hide/Show PayPal Icons', 'lf' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_off' => __( 'Show', 'lf' ),
				'label_on' => __( 'Hide', 'lf' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);

		$this->add_control(
		'payment_box_stripe_bg',
			[
				'label' => __( 'Stripe Payment Box Background', 'lf' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .payment_box' => 'background-color: {{VALUE}}',
				],
			]
		);						

		// WooCommerce Login (info)
		$this->add_control(
			'woocommerce_login',
			[
				'label' => __( 'Login Notice Border & Icon', 'lf' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .woocommerce-info' => 'border-top-color: {{VALUE}}',
				],
			]
		);	

		// WooCommerce Error 
		$this->add_control(
			'woocommerce_error',
			[
				'label' => __( 'Error Notice Border & Icon', 'lf' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .woocommerce-error' => 'border-top-color: {{VALUE}}',
				],
			]
		);	

	// End Gateway Components Section
	$this->end_controls_section();

// end Register Controls
}



/**
	 * Render CSS Style
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 2.0.0
	 * @access protected
	 */

   public function __construct($data = [], $args = null) {
      parent::__construct($data, $args);
      
      // adds general style sheet for elementor widgets
      wp_register_style( 'lf-elementor', 'LF_DIR_URL' . 'elementor/css/launchflows-elementor.css', false, '1.0.0');
   }

  public function get_style_depends() {

     return [ 'lf-elementor' ];
  
  }

/**
	 * Render styles to the hook in form-checkout.php footer
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 2.0.0
	 * 
	 */

	public function render() {

		$settings = $this->get_settings_for_display();

			if( is_admin() ) {  // displays shortcode syntax only in admin editor, not on front end

				?>

				<div id="lf-stylemanager" class="admin-only">
					<div></div>
				</div> 

				<?php 

			} 

 		// outputs inline css *Note  to restrict to front end vs. admin side
				echo '<style id="lf-shortcode-style">';
				// credit card icons
				if ( 'yes' === $settings['hide_cc_icons'] ) {
					echo '
					 .wc_payment_method.payment_method_stripe label img{display:none;
					}';
				}
				// paypal icons
				if ( 'yes' === $settings['hide_pp_icons'] ) {
					echo '
					.wc_payment_method.payment_method_paypal label img, 
					.wc_payment_method.payment_method_paypal label a{display:none;
					}';
				}

					// all text
					echo '
					 {
						font-family:'.$settings['font_family'].';
						color:'.$settings['text_color'].';
						font-size:'.$settings['font_size']['size'].$settings['font_size']['unit'].';
					}';


					// all text p
					echo '
					 p{
						font-family:'.$settings['font_family'].';
						color:'.$settings['text_color'].';
						font-size:'.$settings['font_size']['size'].$settings['font_size']['unit'].';
					}';


					// input form labels
					echo '
					 label {
						color:'.$settings['label_color'].'!important;
						font-size:'.$settings['label_font_size']['size'].$settings['label_font_size']['unit'].'!important;
					}';

					// input form text color & placeholder
					echo '
					
					 .input-text {
						color:'.$settings['input_text_color'].'!important;
						font-size:'.$settings['field_font_size']['size'].$settings['field_font_size']['unit'].'!important;
					}

					 a {
						color:'.$settings['link_color'].'!important;
					}

					input::placeholder { 
					  color: '.$settings['placeholder_text_color'].'!important;
					}

					input::-webkit-input-placeholder { 
					  color: '.$settings['placeholder_text_color'].'!important;
					}

					input:-moz-placeholder { 
					  color: '.$settings['placeholder_text_color'].'!important;
					  opacity: 1;
					}

					input::-moz-placeholder { 
					  color: '.$settings['placeholder_text_color'].'!important;
					  opacity: 1;
					}

					input:-ms-input-placeholder { 
					  color: '.$settings['placeholder_text_color'].'!important;
					}

					input::-ms-input-placeholder {
					  color: '.$settings['placeholder_text_color'].'!important;
					}

					';


					// stripe payment box background color
					echo '
					 .payment_box {
						background-color:'.$settings['payment_box_stripe_bg'].'!important;
					}';

					echo '
					 .payment_box:before {
						border-bottom-color: '.$settings['payment_box_stripe_bg'].'!important;
					}';

					// place order 
					echo '
					 #place_order {
						background-color:'.$settings['place_order_button_bg'].'!important;
						color:'.$settings['place_order_button_text'].'!important;
						font-size:'.$settings['place_order_button_font_size']['size'].$settings['place_order_button_font_size']['unit'].'!important;						
					}';

					// lf-donate-button background color (donate button)
					echo '
					 #lf-donate-button {
						border-color:'.$settings['donate_button_bg'].'!important;
						background-color:'.$settings['donate_button_bg'].'!important;			
						color:'.$settings['donate_button_text'].'!important;
						font-size:'.$settings['donate_button_font_size']['size'].$settings['donate_button_font_size']['unit'].'!important;						
					}';


					// place order background color hover (donate button)
					echo '
					 #place_order:hover {
						background-color:'.$settings['place_order_button_bg_hover'].'!important;
						color:'.$settings['place_order_button_text_hover'].'!important;
					}';

					// lf-donate-button background color hover(donate button)
					echo '
					 #lf-donate-button:hover {
						border-color:'.$settings['donate_button_bg_hover'].'!important;
						background-color:'.$settings['donate_button_bg_hover'].'!important;
						color:'.$settings['donate_button_text_hover'].'!important;
					}';


					// product-image img size
					echo '
					 .lf-shortcode > .product-image img {
						width:'.$settings['product_image_width']['size'].$settings['product_image_width']['unit'].'!important;
					}';

					// product-image align
					echo '
					 .lf-shortcode > .product-image {
						text-align:'.$settings['product_image_align'].'!important;
					}';

					// lf-bump resize image
					echo '
					.lf-bump img {
						width:'.$settings['lf_bump_img_width'].'px!important;
					}';

					// lf-bump checkbox size
					echo '
					.lf-bump .pretty {
						transform: scale('.$settings['lf_bump_input_scale'].')!important;
					}';

					// lf-bump checkbox margin right
					echo '
					.lf-bump input {
						margin-right:'.$settings['lf_bump_margin_right'].'px!important;
					}';

					// lf-bump product title left
					echo '
					.lf-bump .product-title {
						margin-left:'.$settings['lf_bump_product_title_left'].'px!important;
					}';

					// lf-emptycart.button
					echo '
					 #lf-emptycart a.button {
						background-color:'.$settings['emptycart_button_bg'].'!important	;			
						color:'.$settings['emptycart_button_text'].'!important;
						font-size:'.$settings['emptycart_button_font_size']['size'].$settings['emptycart_button_font_size']['unit'].'!important;						
					}';

					// lf-wccoupon.button
					echo '
					 .lf-wccoupon button {
						background-color:'.$settings['coupon_button_bg'].'!important	;			
						color:'.$settings['coupon_button_text'].'!important;
						font-size:'.$settings['coupon_button_font_size']['size'].$settings['coupon_button_font_size']['unit'].'!important;						
					}';

					// woocommerce login
					echo '
					 .woocommerce-info {
						border-top-color:'.$settings['woocommerce_login'].'!important;
					}';

					// woocommerce login icon
					echo '
					 .woocommerce-info::before {
						color:'.$settings['woocommerce_login'].'!important;
					}';

					// woocommerce error top border
					echo '
					 .woocommerce-error {
						border-top-color:'.$settings['woocommerce_error'].'!important;
					}';

					// woocommerce error icon
					echo '
					 .woocommerce-error::before {
						color:'.$settings['woocommerce_error'].'!important;
					}';

					// remove product link color
					echo '
					.lf-review .shop_table a.remove {
						color:'.$settings['remove_product_link_color'].'!important;
						border-color:'.$settings['remove_product_link_color'].'!important;
					}';					

					// display remove product link
				    if ( 'yes' != $settings['display_remove_product_link'] ) {
					echo '
					.lf-review a.remove{display:none!important;}';
					};

					// display featured product images
				    if ( 'yes' != $settings['display_featured_product_images'] ) {
					echo '
					.lf_cqoc_product_name .lf-product-image {display:none!important;}';
					};					

					// display featured product quantitiess
				    if ( 'yes' != $settings['display_featured_product_quantities'] ) {
					echo '
					body.launchflows .quantity input.qty {display:none!important;}';
					};	

					// add any custom css (always at end)
					echo $settings['custom_css'];

					echo '</style>';

	// end
	}



	/**
	 * Render shortcode widget as plain content.
	 *
	 * Override the default behavior by printing the shortcode insted of rendering it.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	
	public function render_plain_content() {
		// In plain mode, render without shortcode
	}

// end class	
}