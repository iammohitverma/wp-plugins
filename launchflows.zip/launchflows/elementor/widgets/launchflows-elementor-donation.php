<?php
namespace LaunchFlowsElementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * LaunchFlows Elementor
 *
 * Elementor widget for LaunchFlows
 *
 * @since 1.0.0
 */
class LaunchFlowsElementorDonation extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'lf-donation';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'LaunchFlows Donation', 'lf' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-plus-square-o';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.2.2
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'launchflows'];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'lf' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 3.2.2
	 *
	 * @access protected
	 */

	protected function _register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'lf' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'content',
			[
				'label' => __( 'Select Component To Add:', 'lf' ),
				'type' => Controls_Manager::HIDDEN,
				'default' => '[lf-donation]',
			]

		);		


		$this->add_control(
			'product',
			[
				'label' => __( 'Product ID:', 'lf' ),
				'type' => Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'eg: 12345', 'lf' ),	
			]
		);
		$this->add_control(
			'button_text',
			[
				'label' => __( 'Button Text:', 'lf' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'eg: Click To Update' ),
			]
		);

		$this->add_control(
			'field_text',
			[
				'label' => __( 'Field Text:', 'lf' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'eg: Donation Amount' ),	
			]
		);

$this->end_controls_section();


// donation title
$this->start_controls_section(
			'donation_product_title',
			[
				'label' => __( 'Field', 'lf' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


	$this->start_controls_tabs(
			'style_tabs_title'
		);

		$this->start_controls_tab(
			'style_normal_tab_title',
			[
				'label' => __( 'Normal', 'lf' ),
			]
		);

				// title - normal tab
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name'					=> 'donation_title_typography',
						'label'					=> __( 'Typography', 'lf' ),
						'selector'				=> '{{WRAPPER}} .donation-title'
					]
				);
				$this->add_control(
					'donation_title_text_color',
					[
						'label' => __( 'Text Color', 'lf' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .donation-title' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'donation_title_background_color',
					[
						'label' => __( 'Background Color', 'lf' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .donation-title' => 'background-color: {{VALUE}};',
							'{{WRAPPER}} .donation-title::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
						],
					]
				);

				$this->add_responsive_control(
					'donation_title_margin',
					[
						'label' => __( 'Margin', 'lf' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'allowed_dimensions' => 'vertical',
						'selectors' => [
							'{{WRAPPER}} .donation-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'donation_title_padding',
					[
						'label' => __( 'Padding', 'lf' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'selectors' => [
							'{{WRAPPER}} .donation-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_control(
					'hr_title_normal',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);	
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'donation_title_border',
						'label' => __( 'Border', 'lf' ),
						'selector' => '{{WRAPPER}} .donation-title',
					]
				);
				$this->add_responsive_control(
					'donation_title_border_radius',
					[
						'label' => __( 'Border Radius', 'lf' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .donation-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);	

				$this->add_control(
					'hr_title_normal_after_border',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);	

		$this->end_controls_tab();


		// title - hover tab
		$this->start_controls_tab(
			'style_hover_tab_title',
			[
				'label' => __( 'Hover', 'lf' ),
			]
		);

				$this->add_group_control(
					Group_Control_Typography::get_type(),
					[
						'name'					=> 'donation_title_typography_hover',
						'label'					=> __( 'Typography', 'lf' ),
						'selector'				=> '{{WRAPPER}} .donation-title'
					]
				);
				
				$this->add_control(
					'donation_title_text_color_hover',
					[
						'label' => __( 'Text Color', 'lf' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .donation-title:hover' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'donation_title_background_color_hover',
					[
						'label' => __( 'Background Color', 'lf' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .donation-title:hover' => 'background-color: {{VALUE}};',
							'{{WRAPPER}} .donation-title:hover::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
						],
					]
				);
				$this->add_control(
					'hr_title_hover',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);					
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'donation_title_border_hover',
						'label' => __( 'Border', 'lf' ),
						'selector' => '{{WRAPPER}} .donation-title:hover',
					]
				);

				$this->add_responsive_control(
					'donation_title_border_radius_hover',
					[
						'label' => __( 'Border Radius', 'lf' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .donation-title:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);	


		$this->end_controls_tab();

	$this->end_controls_tabs();

$this->end_controls_section();
/* title end */


// donation button
$this->start_controls_section(
			'donation_product_button',
			[
				'label' => __( 'Button', 'lf' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


	$this->start_controls_tabs(
			'style_tabs_button'
		);

		$this->start_controls_tab(
			'style_normal_tab_button',
			[
				'label' => __( 'Normal', 'lf' ),
			]
		);

				// button - normal tab
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name'					=> 'donation_button_typography',
						'label'					=> __( 'Typography', 'lf' ),
						'selector'				=> '{{WRAPPER}} .donation-button-text'
					]
				);
				$this->add_control(
					'icon',
					[
						'label' => __( 'Icon', 'lf' ),
						'type' => \Elementor\Controls_Manager::ICONS,
					]
				);

		$this->add_responsive_control(
			'align',
			[
				'label' => __( 'Alignment', 'lf' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left'    => [
						'title' => __( 'Left', 'lf' ),
						'icon' => 'eicon-text-align-left',
					],

					'justify' => [
						'title' => __( 'Justified', 'lf' ),
						'icon' => 'eicon-text-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'default' => '',
			]
		);

		$this->add_control(
			'icon_align',
			[
				'label' => __( 'Icon Position', 'lf' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'left' => __( 'Before', 'elementor' ),
					'right' => __( 'After', 'elementor' ),
				],
			]
		);
		$this->add_control(
			'icon_indent',
			[
				'label' => __( 'Icon Spacing', 'lf' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 50,
					],
				],
				'condition' => ['icon!' => ''],
				'selectors' => [
					'{{WRAPPER}} .elementor-button .elementor-align-icon-right' => 'margin-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .elementor-button .elementor-align-icon-left' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

				$this->add_control(
					'donation_button_text_color',
					[
						'label' => __( 'Text Color', 'lf' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .donation-button-text' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'donation_button_background_color',
					[
						'label' => __( 'Background Color', 'lf' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .donation-button' => 'background-color: {{VALUE}};',
							'{{WRAPPER}} .donation-button::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
						],
					]
				);
				$this->add_responsive_control(
					'donation_button_margin',
					[
						'label' => __( 'Margin', 'lf' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'allowed_dimensions' => 'vertical',
						'selectors' => [
							'{{WRAPPER}} .donation-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'donation_button_padding',
					[
						'label' => __( 'Padding', 'lf' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'selectors' => [
							'{{WRAPPER}} .donation-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_control(
					'hr_button_normal',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);	
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'donation_button_border',
						'label' => __( 'Border', 'lf' ),
						'selector' => '{{WRAPPER}} .donation-button',
					]
				);
				$this->add_responsive_control(
					'donation_button_border_radius',
					[
						'label' => __( 'Border Radius', 'lf' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .donation-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);	

				$this->add_control(
					'hr_button_normal_after_radius',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);	

		$this->end_controls_tab();


		// button - hover tab
		$this->start_controls_tab(
			'style_hover_tab_button',
			[
				'label' => __( 'Hover', 'lf' ),
			]
		);

				$this->add_group_control(
					Group_Control_Typography::get_type(),
					[
						'name'					=> 'donation_button_typography_hover',
						'label'					=> __( 'Typography', 'lf' ),
						'selector'				=> '{{WRAPPER}} .donation-button-text'
					]
				);
				
				$this->add_control(
					'donation_button_text_color_hover',
					[
						'label' => __( 'Text Color', 'lf' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .donation-button-text:hover' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'donation_button_background_color_hover',
					[
						'label' => __( 'Background Color', 'lf' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .donation-button:hover' => 'background-color: {{VALUE}};',
							'{{WRAPPER}} .donation-button:hover::before' => 'border: 1em solid {{VALUE}};border-right-color: transparent;border-left-color: transparent;border-top-color: transparent;',
						],
					]
				);
	
				$this->add_control(
					'hr_button_hover',
					[
						'type' => \Elementor\Controls_Manager::DIVIDER,
					]
				);					
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'donation_button_border_hover',
						'label' => __( 'Border', 'lf' ),
						'selector' => '{{WRAPPER}} .donation-button:hover',
					]
				);

				$this->add_responsive_control(
					'donation_button_border_radius_hover',
					[
						'label' => __( 'Border Radius', 'lf' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .donation-button:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);	


		$this->end_controls_tab();

	$this->end_controls_tabs();

$this->end_controls_section();
/* button end */


// end
	}



/**
	 * Render CSS Style
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */

   public function __construct($data = [], $args = null) {
      parent::__construct($data, $args);
      wp_register_style( 'lf-elementor', LF_DIR_URL . 'elementor/css/launchflows-elementor.css', false, '1.0.0');
   }

  public function get_style_depends() {
     return [ 'lf-elementor' ];
  }

/**
	 * Render shortcode widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */

	protected function render() {

		$settings = $this->get_settings_for_display();


		$content = $this->get_settings( 'content' );
		

		$product = $this->get_settings( 'product' );


		$field_text = $this->get_settings( 'field_text' );


		$button_text = $this->get_settings( 'button_text' );


		$css = trim($content, "[]");


		$shortcode = do_shortcode( shortcode_unautop( $content ) );
	

		// For Testing Shortcode Output
		//echo $content;	

		// displays shortcode syntax only in admin editor, not on front end
		if( is_admin() ) {  
			?>
			<div id="<?php echo $css; ?>" class="admin-only">
				<!--?php echo $content; ?-->
				<div></div> 
			</div> 
			<!--- disable button click on admin --->
			<script>jQuery('#lf-donate-button').prop('disabled', true);</script>
			<?php 
		} 
 
    // custom output for donation widget
	if ($button_text !=='' && $field_text !=='') {
	?>
	  <style>#lf-donation.admin-only {display:none;}</style>
	  <div class="lf-all">
      <div id="lf-donation">
      <div class="lf-donation">
      
      <div class="elementor-element elementor-element-lf-donation elementor-button-align-start elementor-widget elementor-widget-form" data-id="lf-donation" data-element_type="widget" id="lf-donate-id" data-widget_type="form.default">
  
  		<input size="1" type="hidden" name="form_fields[product]" id="form-field-product" class="elementor-field elementor-size-md  elementor-field-textual" value="<?php echo $product; ?>">

        <div class="elementor-widget-container">

          <div class="elementor-form-fields-wrapper elementor-labels-">

            <div class="elementor-field-type-number elementor-field-group elementor-column elementor-field-group-donate elementor-col-50">
                        
              <input type="number" name="form_fields[donate]" id="form-field-donate" class="donation-title elementor-field elementor-size-md  elementor-field-textual" placeholder="<?php echo $field_text; ?>" min="" max="">       
            
            </div>

            <div class=" elementor-field-group elementor-column elementor-field-type-submit elementor-col-50">
            
              <button type="submit" class="donation-button elementor-button elementor-size-md" id="lf-donate-button">
 				
 				<span class="elementor-button-content-wrapper">
                 
                  <span class="donation-button-icon elementor-button-icon elementor-align-icon-<?php echo $settings['icon_align']; ?>">

                  	<?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                  		
                  	</span>

                  <span class="donation-button-text elementor-button-text lf-donate-button"><?php echo $button_text; ?></span>

                </span>
              </button>
          
            </div>
          
          </div>

        </div>

      </div>

	  </div>
	  </div>
	  </div>      

	<?php

	} else {

		// outputs shortcode to front
		?>
		<div class="lf-shortcode" >
		<?php echo $shortcode; ?>
		</div>
		<?php

	} // end else	
	?>
			<script type="text/javascript">
			  // custom donation form creation
			jQuery("#lf-donate-button").click(function(){ // click button with id #lf-donate-button
			event.preventDefault(); // stop regular form
			jQuery("#lf-donate-id").val(function() { // get product attribute for value inside form #lf-donate-id
			var product = jQuery("#form-field-product").val(); // use hidden form field for product id
			var amount = jQuery("#form-field-donate").val(); // number inside form field with id #donate
			window.location = "?add-to-cart=" + product + "&donation=" + amount;  // build url string and send to browser
			});
			});
			</script>
	<?php
}

//end	
}