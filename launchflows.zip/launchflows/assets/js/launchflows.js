/**
   * Rules Engine For Checkout Step Content Replacement And Positioning
   *
   * @since 3.5.3
   *
   * @return void
   */

jQuery(window).on('load', function() {
    
  // fade in certain compoments (optional delay value default is "0")
     jQuery(".required").fadeIn(0); // asterisk over required fields
     jQuery(".optional").fadeIn(0); // over optional fields

     // checkout
     jQuery("#lf-form").css('display','block'); // original checkout components hiddent until page loads

     // product
     jQuery("#lf-content-block").css('display','block'); // product page new layout elements will show only after this loads
  
     // for default template
     jQuery("#lf-original-product-default").delay(1000).css('visibility','visible').css('height','auto'); // reveals original product division after page loads (if no custom product layout)

     jQuery("#lf-content-block").css('display','block'); // reveals original product block content after page loads

     // shipping checkbox (display shipping fields if checked)
     jQuery("#ship-to-different-address-checkbox").on("change",function(e) {

          if (jQuery(this).prop("checked")) {
        
              jQuery(".shipping_address").css("display", "block");
        
          } else {
        
              jQuery(".shipping_address").css("display", "none");
        
          };
      
      });

  // wc product payments - kadence theme
      var productpayments = jQuery('.single-product-payments');
      jQuery("#lf-product-payments").replaceWith( productpayments );
    
  // wc product extras - kadence theme
      var productextras = jQuery('.single-product-extras');
      jQuery("#lf-product-extras").replaceWith( productextras );

  // wc product breadcrumbs - kadence theme
      var productbreadcrumbs = jQuery('.kadence-breadcrumbs');
      jQuery("#lf-product-breadcrumbs").replaceWith( productbreadcrumbs);

  // wc product first payment date
      var productfirstpayment = jQuery('p.first-payment-date');
      jQuery("#lf-product-firstpayment").replaceWith( productfirstpayment );

  // wc related products
      var productrelated = jQuery('section.related.products');
      jQuery("#lf-product-related").replaceWith( productrelated );

  // wc product price      
      var productprice = jQuery('p.price'); 
      jQuery("#lf-product-price").replaceWith( productprice );
     
  // wc product title
      var producttitle = jQuery('.entry-title');
      jQuery("#lf-product-title").replaceWith( producttitle );
     
  // wc product meta
      var productmeta = document.getElementsByClassName('product_meta');
      jQuery("#lf-product-meta" ).wrap( "<span class='lf-product-meta'>" ); // custom wrapper class for css
      jQuery("#lf-product-meta").replaceWith( productmeta );

  // wc product short description
      var productdescription = document.getElementsByClassName('woocommerce-product-details__short-description');
      jQuery("#lf-product-description" ).wrap( "<span class='lf-product-description'>" ); // custom wrapper class for css
      jQuery("#lf-product-description").replaceWith( productdescription );

  // wc breadcrumb
      var productbreadcrumb = document.getElementsByClassName('woocommerce-breadcrumb');
      jQuery("#lf-product-breadcrumb" ).wrap( "<span class='lf-product-breadcrumb'>" ); // custom wrapper class for css
      jQuery("#lf-product-breadcrumb").replaceWith( productbreadcrumb );    

  // wc product tabs
      var producttabs = document.getElementsByClassName('woocommerce-tabs');
      jQuery("#lf-product-tabs" ).wrap( "<span class='lf-product-tabs div.product'>" ); // custom wrapper class for css
      jQuery("#lf-product-tabs").replaceWith( producttabs );
  
  // wc product images
      var productimages = jQuery('.woocommerce-product-gallery');
      jQuery("#lf-product-images" ).wrap( "<span class='lf-product-images'>" ); // custom wrapper class for css
      jQuery("#lf-product-images").replaceWith( productimages);

  // wc product cart
      var productcart = document.getElementsByClassName('cart');
      jQuery("#lf-product-add-to-cart" ).wrap( "<span class='lf-product-add-to-cart-wrapper'><span class='lf-product-add-to-cart'>" ); // custom wrapper class for css
      jQuery("#lf-product-add-to-cart").replaceWith( productcart );


  // account
      var account = document.getElementsByClassName('woocommerce-account-fields');
      jQuery("#lf-account" ).wrap( "<span class='lf-account'>" ); // custom wrapper class for css
      jQuery("#lf-account").replaceWith( account );

  // billing
      var billing = document.getElementsByClassName('woocommerce-billing-fields');
      jQuery("#lf-billing" ).wrap( "<span class='lf-billing'>" ); // custom wrapper class for css
      jQuery("#lf-billing").replaceWith( billing );
       
  // shipping
      var shipping = document.getElementsByClassName('woocommerce-shipping-fields');
      jQuery("#lf-shipping" ).wrap( "<span class='lf-shipping'>" ); // custom wrapper class for css
      jQuery("#lf-shipping").replaceWith( shipping );

  // additional 
      var additional = document.getElementsByClassName('woocommerce-additional-fields');
      jQuery("#lf-additional" ).wrap( "<span class='lf-additional'>" ); // custom wrapper class for css
      jQuery("#lf-additional").replaceWith( additional );
      

  // cart-discount (1.1.15)
      var cartdiscount = document.getElementsByClassName('cart-discount');
      jQuery( "#lf-cart-discount" ).wrap( "<span class='lf-cart-discount'>" ); // custom wrapper class for css
      jQuery( "#lf-cart-discount").replaceWith( cartdiscount );      

  // review order (3.0.2)
      var revieworder = document.getElementById('order_review_wrap');
      jQuery( "#lf-review" ).wrap( "<span class='lf-review'>" ); // custom wrapper class for css
      jQuery( "#lf-review").replaceWith( revieworder );

  // subtotal (1.0.20)
      var subtotal = document.getElementsByClassName('cart-subtotal');
      jQuery( "#lf-subtotal" ).wrap( "<div class='lf-subtotal'>" ); // custom wrapper class for css
      jQuery( "#lf-subtotal").replaceWith( subtotal );

  // tax-total (3.1)
      var taxtotal = document.getElementsByClassName('tax-total');
      jQuery( "#lf-tax-total" ).wrap( "<span class='lf-tax-total'>" ); // custom wrapper class for css
      jQuery( "#lf-tax-total").replaceWith( taxtotal );


  // total (1.0.20)
      var total = document.getElementsByClassName('order-total');
      jQuery( "#lf-total" ).wrap( "<span class='lf-total'>" ); // custom wrapper class for css
      jQuery( "#lf-total").replaceWith( total );

  // total shipping 
      var totalshipping = document.getElementsByClassName('woocommerce-shipping-totals');
      jQuery( "#lf-total-shipping" ).wrap( "<span class='lf-total-shipping'>" ); // custom wrapper class for css
      jQuery( "#lf-total-shipping").replaceWith( totalshipping );

  // payment
      var payment = document.getElementById('payment');
      jQuery("#lf-payment" ).wrap( "<span class='lf-payment woocommerce-checkout'>" ); // custom wrapper class for css
      jQuery("#lf-payment").replaceWith( payment );

  // wc coupon (1.0.15)
      var wccoupon = document.getElementsByClassName('woocommerce-form-coupon-toggle');
      var wccouponform = document.getElementsByClassName('checkout_coupon');
      jQuery("#lf-wccoupon" ).wrap( "<span class='lf-wccoupon'>" ); // custom wrapper class for css
      jQuery("#lf-wccoupon").replaceWith( wccoupon );
      jQuery( wccouponform ).appendTo ( wccoupon);

  // wc login form (2.0.1)
      var logintoggle = document.getElementsByClassName('woocommerce-form-login-toggle');
      var loginform = document.getElementsByClassName('woocommerce-form-login');
      jQuery("#lf-login" ).wrap( "<span class='lf-login'>" ); // custom wrapper class for css
      jQuery("#lf-login").replaceWith( logintoggle);
      jQuery( loginform ).appendTo ( logintoggle);


  // smooth scroll to any section #id within .launchflows body class
      (function($) {
        $("a[href^='#']").click(function(e) {
          e.preventDefault(); // Now link won't go anywhere
          var position = $($(this).attr("href")).offset();
            $(".launchflows").animate({ // works only for .launchflows body class
              scrollTop: position
            }, 3000 );
        });
      })( jQuery ); 

  // smooth scroll with specific scroll to checkout button (for use inside checkout form)
  // usefulangle.com/post/156/javascript-scroll-to-element
  (function($) {
          $(".lf-scroll-to-checkout").click(function(e) {
            e.preventDefault(); // Now link won't go anywhere
            var element = document.querySelector("#lf-form");
            // smooth scroll to element and align it at the bottom
            element.scrollIntoView({ behavior: 'smooth', block: 'end'});
          });
        })( jQuery ); 

  // hide extra "remove" button from standard wc_cart shortcode if used in an lf layout
      jQuery("tr.woocommerce-cart-form__cart-item.cart_item .product-name a.remove").remove();

  
  // switch function for lf-bump
    jQuery(document).ready(function(){
      jQuery(".lf-bump input.switch").change(function(){   // set change function to the input checkbox
           var item=jQuery(this);
           window.location.href=item.data("target");      // sends add/remove link to the browser
      });  
  });

}); // end of all
